#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HEX 16
#define WORD 8
#define H_WORD 4

enum FEATURE {
	IDLE_CHK = 1,
	GRC_DUMP = 2,
	MCP_TRACE = 3,
	REG_FIFO = 4,
	PROTECTION_OVERRIDE = 5,
	IGU_FIFO = 6,
	PHY = 7,
	FW_ASSERTS = 8,
} feature;

int engine;
int omit_engine;
int old_mode_vect_idx;
int idle_chk_files_num;
int grc_dump_files_num;
int mcp_trace_files_num;
int reg_fifo_files_num;
int igu_fifo_files_num;
int protection_override_files_num;
int fw_asserts_files_num;
int phy_files_num;

FILE *idle_chk_files[20];
FILE *grc_dump_files[20];
FILE *mcp_trace_files[20];
FILE *reg_fifo_files[20];
FILE *igu_fifo_files[20];
FILE *protection_override_files[20];
FILE *fw_asserts_files[20];
FILE *phy_files[20];

void open_new_file(char *file_path);
void calculate_feature_and_engine(short input);

void main (int argc, char *argv[])
{
	int i;
	char *token;
	char buffer[4];
	size_t len = 0;
	FILE *source_file;
	char *line = NULL;
	long current_read_idx = 0;
	long next_item_start_idx = 0;

	/* open the source file for reading */
	source_file = fopen(argv[1],"r");
	if (source_file == NULL) {
	    printf("ERROR OPENING FILE %s\n", argv[1]);
	    exit (0);
	}

	/* parse the file */
	while (getline(&line, &len, source_file) != -1) {
		token = strtok(line," \n");
		while (token != NULL) {

			/* get file size - adding H_WORD because of the 4 bytes that represent the header of the feature */
			if (current_read_idx < 3) {
				next_item_start_idx += strtol(token, NULL, HEX) << (WORD * current_read_idx);
				if (current_read_idx == 2)
					next_item_start_idx += H_WORD;
			} else if (current_read_idx == 3) {
				/* get the feature of the parsed part of the file and open file for writing */
				calculate_feature_and_engine(strtol(token, NULL, HEX));
				open_new_file(argv[2]);
			} else {

				switch (feature) {
				case IDLE_CHK:
					fputc(strtol(token, NULL, HEX), idle_chk_files[idle_chk_files_num]);
					break;
				case MCP_TRACE:
					fputc(strtol(token, NULL, HEX), mcp_trace_files[mcp_trace_files_num]);
					break;
				case REG_FIFO:
					fputc(strtol(token, NULL, HEX), reg_fifo_files[reg_fifo_files_num]);
					break;
				case PROTECTION_OVERRIDE:
					fputc(strtol(token, NULL, HEX), protection_override_files[protection_override_files_num]);
					break;
				case IGU_FIFO:
					fputc(strtol(token, NULL, HEX), igu_fifo_files[igu_fifo_files_num]);
					break;
				case FW_ASSERTS:
					fputc(strtol(token, NULL, HEX), fw_asserts_files[fw_asserts_files_num]);
					break;
				case PHY:
					fputc(strtol(token, NULL, HEX), phy_files[phy_files_num]);
					break;
				case GRC_DUMP:
					sprintf(buffer, "%c", strtol(token, NULL, HEX));
					fwrite(buffer, sizeof(char), 1, grc_dump_files[grc_dump_files_num]);
					break;
				}
			}

			current_read_idx++;

			/* get next token */
			token = strtok(NULL, " \n");

			/* Move to the next state when buffer is complete
			* Must make sure loop counter is after the part of buffer containing the size.
			*/
			if (current_read_idx == next_item_start_idx && current_read_idx > 3) {
				current_read_idx = 0;
				next_item_start_idx = 0;
				/* advance the counter of the freature that created */
				switch (feature) {
				case GRC_DUMP:
					grc_dump_files_num++;
					break;
				case IDLE_CHK:
					idle_chk_files_num++;
					break;
				case MCP_TRACE:
					mcp_trace_files_num++;
					break;
				case REG_FIFO:
					reg_fifo_files_num++;
					break;
				case PROTECTION_OVERRIDE:
					protection_override_files_num++;
					break;
				case IGU_FIFO:
					igu_fifo_files_num++;
					break;
				case FW_ASSERTS:
					fw_asserts_files_num++;
					break;
				case PHY:
					phy_files_num++;
					break;
				}
			}
		}
	}

	printf("Success! %d grc_dump files, %d idle_chk, %d mcp_trace, %d reg_fifo, %d protection_override, %d igu_fifo, %d fw_asserts and %d phy files were created\n",
	       grc_dump_files_num, idle_chk_files_num, mcp_trace_files_num, reg_fifo_files_num, protection_override_files_num, igu_fifo_files_num, fw_asserts_files_num, phy_files_num);

	/* close file handles */
	fclose(source_file);
	for (i = 0; i < idle_chk_files_num; i++)
		fclose(idle_chk_files[i]);
	for (i = 0; i < grc_dump_files_num; i++)
		fclose(grc_dump_files[i]);
	for (i = 0; i < mcp_trace_files_num; i++)
		fclose(mcp_trace_files[i]);
	for (i = 0; i < reg_fifo_files_num; i++)
		fclose(reg_fifo_files[i]);
	for (i = 0; i < protection_override_files_num; i++)
		fclose(protection_override_files[i]);
	for (i = 0; i < igu_fifo_files_num; i++)
		fclose(igu_fifo_files[i]);
	for (i = 0; i < fw_asserts_files_num; i++)
		fclose(fw_asserts_files[i]);
	for (i = 0; i < phy_files_num; i++)
		fclose(phy_files[i]);
}

void open_new_file(char *file_path)
{
	char path[200];

	/* open files for writing according to the feature */
	switch (feature) {
	case IDLE_CHK:
		/* omit_engine = 1 means not in 100G mode, omit the engine number in the output files */
		if (omit_engine)
			sprintf(path, "%s/IdleChk%d.txt", file_path, idle_chk_files_num);
		else
			sprintf(path, "%s/IdleChk%d-engine%d.txt", file_path, idle_chk_files_num, engine);
		idle_chk_files[idle_chk_files_num] = fopen(path, "w");
		break;
	case REG_FIFO:
		/* omit_engine = 1 means not in 100G mode, omit the engine number in the output files */
		if (omit_engine)
			sprintf(path, "%s/RegFifo%d.txt", file_path, reg_fifo_files_num);
		else
			sprintf(path, "%s/RegFifo%d-engine%d.txt", file_path, reg_fifo_files_num, engine);
		reg_fifo_files[reg_fifo_files_num] = fopen(path, "w");
		break;
	case IGU_FIFO:
		/* omit_engine = 1 means not in 100G mode, omit the engine number in the output files */
		if (omit_engine)
			sprintf(path, "%s/IguFifo%d.txt", file_path, igu_fifo_files_num);
		else
			sprintf(path, "%s/IguFifo%d-engine%d.txt", file_path, igu_fifo_files_num, engine);
		igu_fifo_files[igu_fifo_files_num] = fopen(path, "w");
		break;
	case PROTECTION_OVERRIDE:
		/* omit_engine = 1 means not in 100G mode, omit the engine number in the output files */
		if (omit_engine)
			sprintf(path, "%s/ProtectionOverride%d.txt", file_path, protection_override_files_num);
		else
			sprintf(path, "%s/ProtectionOverride%d-engine%d.txt", file_path, protection_override_files_num, engine);
		protection_override_files[protection_override_files_num] = fopen(path, "w");
		break;
	case FW_ASSERTS:
		/* omit_engine = 1 means not in 100G mode, omit the engine number in the output files */
		if (omit_engine)
			sprintf(path, "%s/FwAsserts%d.txt", file_path, fw_asserts_files_num);
		else
			sprintf(path, "%s/FwAsserts%d-engine%d.txt", file_path, fw_asserts_files_num, engine);
		fw_asserts_files[fw_asserts_files_num] = fopen(path, "w");
		break;
	case GRC_DUMP:
		if (omit_engine)
			sprintf(path, "%s/GrcDump%d.bin", file_path, grc_dump_files_num);
		else
			sprintf(path, "%s/GrcDump%d-engine%d.bin", file_path, grc_dump_files_num, engine);
		grc_dump_files[grc_dump_files_num] = fopen(path, "wb");
		break;
	case PHY:
		sprintf(path, "%s/Phy%d.txt", file_path, phy_files_num);
		phy_files[phy_files_num] = fopen(path, "w");
		break;
	case MCP_TRACE:
		sprintf(path, "%s/McpTrace%d.txt", file_path, mcp_trace_files_num);
		mcp_trace_files[mcp_trace_files_num] = fopen(path, "w");
		break;
	default:
		if (feature != 0)
			printf("%d feature doesn't exist!\n",feature);
	}
}

void calculate_feature_and_engine(short input)
{
	/* from received feature learn which engine is it and remove it from the feature */
	engine = input >> 7;
	feature = input & 0x1f;
	omit_engine = (input >> 6) & 0x01;
}
