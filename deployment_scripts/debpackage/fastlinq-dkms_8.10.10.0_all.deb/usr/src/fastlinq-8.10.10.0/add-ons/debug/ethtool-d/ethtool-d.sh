#!/bin/bash

parser_location=`cat $(dirname $0)/../data/location.txt | grep grc_parser | cut -f 2`

parse_and_check(){
	$parser_location $1
	if [ "$?" != 0 ]; then
		echo "Parsing $1 failed"
	fi
}

create_parsed_file()
{
	#run dos2unix on the file
	dos2unix  $1 2>/dev/null
	if [ "$?" != "0" ]; then
		echo "dos2unix not found. Assuming output has linux line ending."
		echo "If the parse fails please install dos2unix."
	fi

	# remove first two lines from ethtool and the address column
	cat $1 | sed -e "s/:[ \t]*/:/" | cut -d":" -f 2- | tail -n +3 2> /dev/null > $3/temp

	# call the parsing tool
	output=`$2/internal/ethtool-d $3/temp $3`

	#remove the temp file
	rm -rf $3/temp
}

# check if filename was entered
if [ "$1" == "" ]
then
	echo "Usage example:"
	echo "./ethtool-d.sh <filename> [-p (for parsing grcDump files)]"
	exit
fi

# check if the file exist
if [ -f $1 ]; then

	# check if the file is given in relative path or full path
	if [ `echo "$1" | grep -c "/"` -gt 0 ] ; then
		path=${1%/*}
	else
		path=`pwd`
	fi

	# create file
	create_parsed_file $1 $(dirname $0) $path

	echo "$output"
      	result=`echo $output | cut -d " " -f1`
	if [ "$result" != 'Success!' ]; then
		echo "Parsing failed!"
		exit
    	else
       	# get the number of grc_dump files that were created for parsing
       	num_of_grc_files=`echo $output | cut -d " " -f2`
	fi
	echo "The files were created in $path"
else
	echo "Failed to create parsed file, check the filename or path"
	
fi

#check if user wants to parse GrcDump
if [ "$2" == "-p" ] ; then
	if [ "$num_of_grc_files" == "1" ]; then
		parse_and_check $path/GrcDump0.bin
		parse_and_check $path/IdleChk0.txt
		parse_and_check $path/IdleChk1.txt
		parse_and_check $path/FwAsserts0.txt
	else		 
		for i in `seq 0 $((num_of_grc_files - 1))`
        	do
			parse_and_check $path/GrcDump$i-engine$i.bin
			parse_and_check $path/IdleChk$((2*i))-engine$i.txt
			parse_and_check $path/IdleChk$((2*i+1))-engine$i.txt
			parse_and_check $path/FwAsserts$i-engine$i.txt
	        done
    	fi
fi

exit 0
