#!/bin/bash
nics()
{
chk=`lsmod | grep $1 | wc --lines`
if [ "$chk" -eq 0 ]
then
        echo "Module" $1 "not present";
	return
fi
echo $1 "nics"
echo "=========="
dev=-1
(echo -e "dev\tnic\tboard\tbdf\tdriver\tmfw\tmac-address\tip-address\tstate\tlink"
echo "--- --- ----- --- ------ --- ------------ ---------- ----- ----"
for nic in `for i in \`ls /sys/bus/pci/drivers/$1/\`; do ls /sys/bus/pci/devices/$i/net 2> /dev/null; done`;
do
	dev=$[$dev + 1]
        bdf=`ethtool -i $nic | grep bus | grep "[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]\.[0-9a-f]" -o`
        if [ -z $bdf ]
        then
               bdf="-"
        fi
        board=`lspci -s $bdf | grep -P 'BCM.*?\s' -o`
        if [ -z $board ]
        then
                board="-"
        fi
        drv_ver=`ethtool -i $nic | grep ^version | cut -d" " -f2`
        if [ -z $drv_ver ]
        then
                drv_ver="-"
        fi
        bc_ver=`ethtool -i $nic | grep firmware | sed -e 's/[^0-9]*\([^ $]*\).*$/\1/g'`
        if [ -z $bc_ver ]
        then
                bc_ver="-"
        fi
        mac=`ip -o link show $nic | grep -o ..:..:..:..:..:.. | head -n 1`
        if [ -z $mac ]
        then
                mac="-"
        fi

        state=`ip -o link show $nic | grep ',UP' -o | grep 'UP' -o`
        if [ -z $state ]
        then
                state="-"
        fi

        vf="-(PF`ethtool -i $nic | grep bus | grep .$ -o`)\t"
        if [ -z $vf ]
        then
                vf="-"
        fi
        if [ `lspci -s $bdf | grep Virtual -o` ]
        then
                physfn=/sys/bus/pci/devices/0000:$bdf/physfn
                for virtfn in `ls $physfn | grep virtfn`
                do
                        ls $physfn/$virtfn/net/$nic &> /dev/null && vf="-(VF`echo $virtfn | grep "[0-9]*" -o` of PF`ethtool -i \`ls $physfn/net\` | grep bus | grep .$ -o`)"
                done
        fi
        link=`ethtool $nic | grep "Link detected" | grep "yes\|no" -o`
        if [ -z $link ]
        then
                link="-"
        fi

        ip="`ip -o -4 a s $nic | grep -o '[0-9]*.[0-9]*.[0-9]*.[0-9]*/[0-9]*' | head -n 1`  "
        if [ "$ip" == "  " ]; then ip=" - \t\t"; fi

        echo -e "$dev\t$nic$vf\t$board\t$bdf\t\t$drv_ver\t$bc_ver\t\t$mac\t$ip\t$state\t$link"
done
) |column -t
}
          
if [ -z $1 ]
then
	nics bnx2x
	echo ""
	nics qede
else  
	nics $1
fi
         
