#ifndef __QEDR_H__
#define __QEDR_H__

#include <linux/mutex.h>
#include <linux/list.h>
#include <linux/spinlock.h>
#include <linux/pci.h>

#include <rdma/ib_verbs.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/ib_addr.h>

#if !defined(CONFIG_QED_L2) && !defined(CONFIG_QED_ROCE) && \
    !defined(CONFIG_QED_FCOE) && !defined(CONFIG_QED_ISCSI) && \
    !defined(CONFIG_QED_LL2)
#define CONFIG_QED_L2
#define CONFIG_QED_SRIOV
#define CONFIG_QED_ROCE
#define CONFIG_QED_FCOE
#define CONFIG_QED_ISCSI
#define CONFIG_QED_LL2
#endif

#include "qed_roce_if.h"
#include "qede_roce.h"
#include "qedr_hsi.h"
#include "qed_chain.h"
#include "qed_if.h"

#define QEDR_ROCE_INTERFACE_VERSION	910

#define QEDR_MODULE_VERSION	"8.10.10.0"
#define QEDR_NODE_DESC "QLogic 579xx RoCE HCA"

#define OC_SKH_DEVICE_PF 0x720
#define OC_SKH_DEVICE_VF 0x728
#define QEDR_MAX_AH 512

/* QEDR Limitations */

/* SQ/RQ Limitations
 * An S/RQ PBL contains a list a pointers to pages. Each page contains S/RQE
 * elements. Several S/RQE elements make an S/RQE, up to a certain maximum that
 * is different between SQ and RQ. The size of the PBL was chosen such as not to
 * limit the MAX_WR supported by ECORE, and rounded up to a power of two.
 */
/* SQ */
#define QEDR_MAX_SQ_PBL (0x8000) /* 2^15 bytes */
#define QEDR_MAX_SQ_PBL_ENTRIES (0x10000 / sizeof(void *)) /* number */
#define QEDR_SQE_ELEMENT_SIZE (sizeof(struct rdma_sq_sge)) /* bytes */
#define QEDR_MAX_SQE_ELEMENTS_PER_SQE (ROCE_REQ_MAX_SINGLE_SQ_WQE_SIZE / \
		QEDR_SQE_ELEMENT_SIZE) /* number */
#define QEDR_MAX_SQE_ELEMENTS_PER_PAGE ((RDMA_RING_PAGE_SIZE) / \
		QEDR_SQE_ELEMENT_SIZE) /* number */
#define QEDR_MAX_SQE ((QEDR_MAX_SQ_PBL_ENTRIES) * (RDMA_RING_PAGE_SIZE) / \
		(QEDR_SQE_ELEMENT_SIZE) / (QEDR_MAX_SQE_ELEMENTS_PER_SQE))
/* RQ */
#define QEDR_MAX_RQ_PBL (0x2000) /* 2^13 bytes */
#define QEDR_MAX_RQ_PBL_ENTRIES (0x10000 / sizeof(void *)) /* number */
#define QEDR_RQE_ELEMENT_SIZE (sizeof(struct rdma_rq_sge)) /* bytes */
#define QEDR_MAX_RQE_ELEMENTS_PER_RQE (RDMA_MAX_SGE_PER_RQ_WQE) /* number */
#define QEDR_MAX_RQE_ELEMENTS_PER_PAGE ((RDMA_RING_PAGE_SIZE) / \
		QEDR_RQE_ELEMENT_SIZE) /* number */
#define QEDR_MAX_RQE ((QEDR_MAX_RQ_PBL_ENTRIES) * (RDMA_RING_PAGE_SIZE) / \
		(QEDR_RQE_ELEMENT_SIZE) / (QEDR_MAX_RQE_ELEMENTS_PER_RQE))

/* CQE Limitation
 * Although FW supports two layer PBL we use single layer since it is more
 * than enough. For that layer we use a maximum size of 512 kB, again, because
 * it reaches the maximum number of page pointers. Notice is the '-1' in the
 * calculation that comes from having a u16 for the number of pages i.e. 0xffff
 * is the maximum number of pages (in single layer).
 */
#define QEDR_CQE_SIZE	(sizeof(union rdma_cqe))
#define QEDR_MAX_CQE_PBL_SIZE (512*1024) /* 512kB */
#define QEDR_MAX_CQE_PBL_ENTRIES (((QEDR_MAX_CQE_PBL_SIZE) / \
				  sizeof(u64)) - 1) /* 64k -1 */
#define QEDR_MAX_CQES ((u32)((QEDR_MAX_CQE_PBL_ENTRIES) * (QED_CHAIN_PAGE_SIZE)\
			     / QEDR_CQE_SIZE)) /* 8M -4096/32 = 8,388,480 */

/* CNQ size Limitation
 * The maximum CNQ size is not reachable because the FW supports a chain of u16
 * (specifically 64k-1). The FW can buffer CNQ elements avoiding an overflow, on
 * the expense of performance. Hence we set it to an arbitrarily smaller value
 * than the maximum.
 */
#define QEDR_ROCE_MAX_CNQ_SIZE		(0x4000) /* 2^16 */

#define QEDR_MAX_PORT			(1)

#define QEDR_UVERBS(CMD_NAME) (1ull << IB_USER_VERBS_CMD_##CMD_NAME)

#define convert_to_64bit(lo, hi) ((u64)hi << 32 | (u64)lo)

/* The following number is used to determine if a CQ handle recevied from the
 * FW does actually point to a CQ.
 */
#define QEDR_CQ_MAGIC_NUMBER	(0x11223344)

/* Fast path debug prints */
#define FP_DP_VERBOSE(...)
/* #define FP_DP_VERBOSE(...)	DP_VERBOSE(__VA_ARGS__) */

#define FW_PAGE_SIZE	(RDMA_RING_PAGE_SIZE)

enum DP_QEDR_MODULE {
	QEDR_MSG_INIT		= 0x10000,
	QEDR_MSG_CQ		= 0x20000,
	QEDR_MSG_RQ		= 0x40000,
	QEDR_MSG_SQ		= 0x80000,
	QEDR_MSG_QP		= (QEDR_MSG_SQ | QEDR_MSG_RQ),
	QEDR_MSG_MR		= 0x100000,
	QEDR_MSG_GSI		= 0x200000,
	QEDR_MSG_MISC		= 0x400000,
	QEDR_MSG_SRQ		= 0x800000,
	/* to be added...up to 0x8000000 */
};

#define QEDR_ROCE_V1		0
#define QEDR_ROCE_V2_IP4	4
#define QEDR_ROCE_V2_IP6	6

#define DP_NAME(dev) (dev)->ibdev.name
#define DP_TRACK(dev) 0

struct qedr_dev_attr {
	struct ib_device_attr ib_attr;
};

struct qedr_dma_mem {
	void *va;
	dma_addr_t pa;
	u32 size;
};

struct qedr_pbl {
	struct list_head list_entry;
	void *va;
	dma_addr_t pa;
};

struct qedr_queue_info {
	void *va;
	dma_addr_t dma;
	u32 size;
	u16 len;
	u16 entry_size;		/* Size of an element in the queue */
	u16 id;			/* qid, where to ring the doorbell. */
	u16 head, tail;
	bool created;
};

struct qedr_eq {
	struct qedr_queue_info q;
	u32 vector;
	int cq_cnt;
	struct qedr_dev *dev;
	char irq_name[32];
};

struct qedr_mq {
	struct qedr_queue_info sq;
	struct qedr_queue_info cq;
	bool rearm_cq;
};

struct phy_info {
	u16 auto_speeds_supported;
	u16 fixed_speeds_supported;
	u16 phy_type;
	u16 interface_type;
};

struct qedr_dev;

struct qedr_cnq {
	struct qedr_dev *dev;
	struct qed_chain pbl;
	struct qed_sb_info *sb;
	char name[32];
	u64 n_comp;
	__le16 *hw_cons_ptr;
	u8 index;
};

#define QEDR_MAX_SGID 128 /* TBD - add more source gids... */

struct qedr_device_attr {
	/* Vendor specific information */
	u32	vendor_id;
	u32	vendor_part_id;
	u32	hw_ver;
	u64	fw_ver;

	u64	node_guid;      /* node GUID */
	u64	sys_image_guid; /* System image GUID */

	u8	max_cnq;
	u8	max_sge;        /* Maximum # of scatter/gather entries
				 * per Work Request supported
				 */
	u16	max_inline;
	u32	max_sqe;        /* Maximum number of send outstanding send work
				 * requests on any Work Queue supported
				 */
	u32	max_rqe;        /* Maximum number of receive outstanding receive
				 * work requests on any Work Queue supported
				 */
	u8	max_qp_resp_rd_atomic_resc;     /* Maximum number of RDMA Reads
						 * & atomic operation that can
						 * be outstanding per QP
						 */

	u8	max_qp_req_rd_atomic_resc;      /* The maximum depth per QP for
						 * initiation of RDMA Read
						 * & atomic operations
						 */
	u64	max_dev_resp_rd_atomic_resc;
	u32	max_cq;
	u32	max_qp;
	u32	max_mr;         /* Maximum # of MRs supported */
	u64	max_mr_size;    /* Size (in bytes) of largest contiguous memory
				 * block that can be registered by this device
				 */
	u32	max_cqe;
	u32	max_mw;         /* Maximum # of memory windows supported */
	u32	max_fmr;
	u32	max_mr_mw_fmr_pbl;
	u64	max_mr_mw_fmr_size;
	u32	max_pd;         /* Maximum # of protection domains supported */
	u32	max_ah;
	u8	max_pkey;
	u32	max_srq;        /* Maximum number of SRQs */
	u32	max_srq_wr;     /* Maximum number of WRs per SRQ */
	u8	max_srq_sge;     /* Maximum number of SGE per WQE */
	u8	max_stats_queues; /* Maximum number of statistics queues */
	u32	dev_caps;

	/* Abilty to support RNR-NAK generation */

#define QED_ROCE_DEV_CAP_RNR_NAK_MASK                           0x1
#define QED_ROCE_DEV_CAP_RNR_NAK_SHIFT                  0
	/* Abilty to support shutdown port */
#define QED_ROCE_DEV_CAP_SHUTDOWN_PORT_MASK                     0x1
#define QED_ROCE_DEV_CAP_SHUTDOWN_PORT_SHIFT                    1
	/* Abilty to support port active event */
#define QED_ROCE_DEV_CAP_PORT_ACTIVE_EVENT_MASK         0x1
#define QED_ROCE_DEV_CAP_PORT_ACTIVE_EVENT_SHIFT                2
	/* Abilty to support port change event */
#define QED_ROCE_DEV_CAP_PORT_CHANGE_EVENT_MASK         0x1
#define QED_ROCE_DEV_CAP_PORT_CHANGE_EVENT_SHIFT                3
	/* Abilty to support system image GUID */
#define QED_ROCE_DEV_CAP_SYS_IMAGE_MASK                 0x1
#define QED_ROCE_DEV_CAP_SYS_IMAGE_SHIFT                        4
	/* Abilty to support bad P_Key counter support */
#define QED_ROCE_DEV_CAP_BAD_PKEY_CNT_MASK                      0x1
#define QED_ROCE_DEV_CAP_BAD_PKEY_CNT_SHIFT                     5
	/* Abilty to support atomic operations */
#define QED_ROCE_DEV_CAP_ATOMIC_OP_MASK                 0x1
#define QED_ROCE_DEV_CAP_ATOMIC_OP_SHIFT                        6
#define QED_ROCE_DEV_CAP_RESIZE_CQ_MASK                 0x1
#define QED_ROCE_DEV_CAP_RESIZE_CQ_SHIFT                        7
	/* Abilty to support modifying the maximum number of
	 * outstanding work requests per QP
	 */
#define QED_ROCE_DEV_CAP_RESIZE_MAX_WR_MASK                     0x1
#define QED_ROCE_DEV_CAP_RESIZE_MAX_WR_SHIFT                    8
	/* Abilty to support automatic path migration */
#define QED_ROCE_DEV_CAP_AUTO_PATH_MIG_MASK                     0x1
#define QED_ROCE_DEV_CAP_AUTO_PATH_MIG_SHIFT                    9
	/* Abilty to support the base memory management extensions */
#define QED_ROCE_DEV_CAP_BASE_MEMORY_EXT_MASK                   0x1
#define QED_ROCE_DEV_CAP_BASE_MEMORY_EXT_SHIFT          10
#define QED_ROCE_DEV_CAP_BASE_QUEUE_EXT_MASK                    0x1
#define QED_ROCE_DEV_CAP_BASE_QUEUE_EXT_SHIFT                   11
	/* Abilty to support multipile page sizes per memory region */
#define QED_ROCE_DEV_CAP_MULTI_PAGE_PER_MR_EXT_MASK             0x1
#define QED_ROCE_DEV_CAP_MULTI_PAGE_PER_MR_EXT_SHIFT            12
	/* Abilty to support block list physical buffer list */
#define QED_ROCE_DEV_CAP_BLOCK_MODE_MASK                        0x1
#define QED_ROCE_DEV_CAP_BLOCK_MODE_SHIFT                       13
	/* Abilty to support zero based virtual addresses */
#define QED_ROCE_DEV_CAP_ZBVA_MASK                              0x1
#define QED_ROCE_DEV_CAP_ZBVA_SHIFT                             14
	/* Abilty to support local invalidate fencing */
#define QED_ROCE_DEV_CAP_LOCAL_INV_FENCE_MASK                   0x1
#define QED_ROCE_DEV_CAP_LOCAL_INV_FENCE_SHIFT          15
	/* Abilty to support Loopback on QP */
#define QED_ROCE_DEV_CAP_LB_INDICATOR_MASK                      0x1
#define QED_ROCE_DEV_CAP_LB_INDICATOR_SHIFT                     16
	u64			page_size_caps;
	u8			dev_ack_delay;
	u32			reserved_lkey;	 /* Value of reserved L_key */
	u32			bad_pkey_counter;/* Bad P_key counter support
						  * indicator
						  */
	struct qed_rdma_events	events;
};

struct qedr_dev {
	struct ib_device ibdev;
	struct qed_dev *cdev;
	struct pci_dev *pdev;
	struct net_device *ndev;

	u32	dp_module;
	u8	dp_level;

	void *rdma_ctx;

	const struct qed_rdma_ops *ops;

	struct qed_sb_info *sb_array;
	struct qedr_cnq *cnq_array;
	int num_cnq;
	int sb_start;

	int gsi_qp_created;
	struct qedr_cq *gsi_sqcq;
	struct qedr_cq *gsi_rqcq;
	struct qedr_qp *gsi_qp;

	/* TBD: we'll need an array of these probablly per DPI... */
	void __iomem *db_addr;
	u64 db_phys_addr;
	u32 db_size;
	u16 dpi;

	u64 guid;
	struct qedr_device_attr attr;
	enum ib_atomic_cap atomic_cap;

	union ib_gid *sgid_tbl;
	spinlock_t sgid_lock;
	struct notifier_block nb_inet;
	struct notifier_block nb_inet6;

	struct qed_int_info int_info;

	u8 mr_key;
	struct list_head entry;

	struct dentry *dbgfs;

	u8 num_hwfns;
	u8 gsi_ll2_mac_address[ETH_ALEN];
	uint wq_multiplier;
	enum qed_rdma_type rdma_type;
};

union db_prod64 {
	struct rdma_pwm_val32_data data;
	u64 raw;
};

enum qedr_cq_type {
	QEDR_CQ_TYPE_GSI,
	QEDR_CQ_TYPE_KERNEL,
	QEDR_CQ_TYPE_USER
};

struct qedr_pbl_info {
	u32 num_pbls;
	u32 num_pbes;
	u32 pbl_size;
	u32 pbe_size;
	bool two_layered;
};

struct qedr_userq {
	struct ib_umem *umem;
	struct qedr_pbl_info pbl_info;
	struct qedr_pbl *pbl_tbl;
	u64 buf_addr;
	size_t buf_len;
};

struct qedr_cq {
	struct ib_cq ibcq;			/* must be first */

	enum qedr_cq_type cq_type;
	u32 sig;
	spinlock_t comp_handler_lock ____cacheline_aligned;
	u16 icid;

	/* relevant to cqs created from kernel space only (ULPs) */
	spinlock_t		cq_lock;
	u8			arm_flags;
	struct qed_chain	pbl;

	void __iomem		*db_addr;	/* db address for cons update*/
	union db_prod64		db;

	u8			pbl_toggle;
	union rdma_cqe		*latest_cqe;
	union rdma_cqe		*toggle_cqe;

	/* TODO: remove since it is redundant with 32 bit chains */
	u32			cq_cons;

	/* relevant to cqs created from user space only (applications) */
	struct qedr_userq	q;
};

struct qedr_pd {
	struct ib_pd ibpd;
	u32 pd_id;
	struct qedr_ucontext *uctx;
};

struct qedr_ah {
	struct ib_ah ibah;
	struct ib_ah_attr attr;
};

union db_prod32 {
	struct rdma_pwm_val16_data data;
	u32 raw;
};

struct qedr_qp_hwq_info {
	/* WQE Elements*/
	struct qed_chain	pbl;
	u64			p_phys_addr_tbl;
	u32			max_sges;

	/* WQE */
	u16			prod;     /* WQE prod index for SW ring */
	u16			cons;     /* WQE cons index for SW ring */
	u16			wqe_cons;
	u16			gsi_cons; /* filled in by GSI implementation */
	u16			max_wr;

	/* DB */
	void __iomem		*db;      /* Doorbell address */
	union db_prod32		db_data;  /* Doorbell data */
};

#define QEDR_INC_SW_IDX(p_info, index) 				\
	do {							\
		p_info->index = (p_info->index + 1) & 		\
			qed_chain_get_capacity(p_info->pbl)	\
	} while (0)

struct qedr_srq_hwq_info {
	u32 max_sges;
	u32 max_wr;
	struct qed_chain pbl;
	u64 p_phys_addr_tbl;
	u32 wqe_prod;     /* WQE prod index in HW ring */
	u32 sge_prod;     /* SGE prod index in HW ring */
	u32 wr_prod_cnt; /* wr producer count */
	u32 wr_cons_cnt; /* wr consumer count */
	u32 num_elems;

	u32 *virt_prod_pair_addr; /* producer pair virtual address */
	dma_addr_t phy_prod_pair_addr; /* producer pair physical address */
};

struct qedr_srq {
	struct ib_srq ibsrq;
	struct qedr_dev *dev;
	/* relevant to cqs created from user space only (applications) */
	struct qedr_userq	usrq;
	struct qedr_srq_hwq_info hw_srq;
	struct ib_umem *prod_umem;
	u16 srq_id;
	/* lock to protect srq recv post */
	spinlock_t lock;
};

enum qedr_qp_err_bitmap {
	QEDR_QP_ERR_SQ_FULL	= 1,
	QEDR_QP_ERR_RQ_FULL	= 2,
	QEDR_QP_ERR_BAD_SR	= 4,
	QEDR_QP_ERR_BAD_RR	= 8,
	QEDR_QP_ERR_SQ_PBL_FULL	= 16,
	QEDR_QP_ERR_RQ_PBL_FULL	= 32,
};

struct qedr_qp {
	struct ib_qp ibqp;		/* must be first */
	struct qedr_dev *dev;

	struct qedr_qp_hwq_info sq;
	struct qedr_qp_hwq_info rq;

	u32 max_inline_data;

	spinlock_t q_lock ____cacheline_aligned;
	struct qedr_cq *sq_cq;
	struct qedr_cq *rq_cq;
	struct qedr_srq *srq;
	enum qed_roce_qp_state state;	/*  QP state */
	u32 id;
	struct qedr_pd *pd;
	enum ib_qp_type qp_type;
	struct qed_rdma_qp *qed_qp;
	u32 qp_id;
	u16 icid;
	u16 mtu;
	int sgid_idx;
	u32 rq_psn;
	u32 sq_psn;
	u32 qkey;
	u32 dest_qp_num;

	/* relevant to qps created from kernel space only (ULPs) */
	u8 prev_wqe_size;
	u16 wqe_cons;
	u32 err_bitmap;
	bool signaled;
	/* SQ shadow */
	struct {
		u64 wr_id;
		enum ib_wc_opcode opcode;
		u32 bytes_len;
		u8 wqe_size;
		bool  signaled;
		dma_addr_t icrc_mapping;
		u32 *icrc;
#ifdef DEFINE_IB_FAST_REG /* ! QEDR_UPSTREAM */
		struct qedr_fast_reg_page_list *frmr;
#endif
		struct qedr_mr *mr;
	} *wqe_wr_id;

	/* RQ shadow */
	struct {
		u64 wr_id;
		struct ib_sge sg_list[RDMA_MAX_SGE_PER_RQ_WQE];
		uint8_t wqe_size;

		/* for GSI only */
		u8 smac[ETH_ALEN];
		u16 vlan_id;
		int rc;
	} *rqe_wr_id;

	/* relevant to qps created from user space only (applications) */
	struct qedr_userq usq;
	struct qedr_userq urq;
};

enum qedr_mr_type {
	QEDR_MR_USER,
	QEDR_MR_KERNEL,
	QEDR_MR_DMA,
	QEDR_MR_FRMR
};

struct mr_info {
	struct qedr_pbl *pbl_table;
	struct qedr_pbl_info pbl_info;
	struct list_head free_pbl_list;
	struct list_head inuse_pbl_list;
	u32 completed;
	u32 completed_handled;
};

struct qedr_mr {
	struct ib_mr 	ibmr;
	struct ib_umem 	*umem;

	struct qed_rdma_register_tid_in_params hw_mr;
	enum qedr_mr_type type;

	struct qedr_dev *dev;
	struct mr_info info;

	u64 *pages;
	u32 npages;
};

#ifdef DEFINE_IB_FAST_REG /* ! QEDR_UPSTREAM */
struct qedr_fast_reg_page_list {
	struct ib_fast_reg_page_list ibfrpl;
	struct qedr_dev *dev;
	struct mr_info info;
};
#endif

struct qedr_ucontext {
	struct ib_ucontext ibucontext;
	struct qedr_dev *dev;
	struct qedr_pd *pd;
	u64 dpi_phys_addr;
	u32 dpi_size;
	u16 dpi;

	struct list_head mm_head;
	struct mutex mm_list_lock;
};

struct qedr_mm {
	struct {
		u64 phy_addr;
		unsigned long len;
	} key;
	struct list_head entry;
};

static inline struct qedr_dev *get_qedr_dev(struct ib_device *ibdev)
{
	return container_of(ibdev, struct qedr_dev, ibdev);
}

static inline struct qedr_ucontext *get_qedr_ucontext(struct ib_ucontext
							  *ibucontext)
{
	return container_of(ibucontext, struct qedr_ucontext, ibucontext);
}

static inline struct qedr_pd *get_qedr_pd(struct ib_pd *ibpd)
{
	return container_of(ibpd, struct qedr_pd, ibpd);
}

static inline struct qedr_cq *get_qedr_cq(struct ib_cq *ibcq)
{
	return container_of(ibcq, struct qedr_cq, ibcq);
}

static inline struct qedr_qp *get_qedr_qp(struct ib_qp *ibqp)
{
	return container_of(ibqp, struct qedr_qp, ibqp);
}

static inline struct qedr_mr *get_qedr_mr(struct ib_mr *ibmr)
{
	return container_of(ibmr, struct qedr_mr, ibmr);
}

static inline struct qedr_ah *get_qedr_ah(struct ib_ah *ibah)
{
	return container_of(ibah, struct qedr_ah, ibah);
}

static inline struct qedr_srq *get_qedr_srq(struct ib_srq *ibsrq)
{
	return container_of(ibsrq, struct qedr_srq, ibsrq);
}
#ifdef DEFINE_IB_FAST_REG /* ! QEDR_UPSTREAM */
static inline struct qedr_fast_reg_page_list *get_qedr_frmr_list(
	struct ib_fast_reg_page_list *ifrpl)
{
	return container_of(ifrpl, struct qedr_fast_reg_page_list, ibfrpl);
}
#endif
#define SET_FIELD2(value, name, flag)			       \
	do {						       \
		(value) |= ((flag) << (name ## _SHIFT));       \
	} while (0)

#define QEDR_RESP_IMM	(RDMA_CQE_RESPONDER_IMM_FLG_MASK << \
			 RDMA_CQE_RESPONDER_IMM_FLG_SHIFT)
#define QEDR_RESP_RDMA	(RDMA_CQE_RESPONDER_RDMA_FLG_MASK << \
			 RDMA_CQE_RESPONDER_RDMA_FLG_SHIFT)
#define QEDR_RESP_RDMA_IMM (QEDR_RESP_IMM | QEDR_RESP_RDMA)

static inline int qedr_get_dmac(struct qedr_dev *dev,
				struct ib_ah_attr *ah_attr, u8 *mac_addr)
{
#ifdef DEFINE_NO_IP_BASED_GIDS
	u8 *guid = &ah_attr->grh.dgid.raw[8]; /* GID's 64 MSBs are the GUID */
#endif
	union ib_gid zero_sgid = { { 0 } };
	struct in6_addr in6;

	if (!memcmp(&ah_attr->grh.dgid, &zero_sgid, sizeof(union ib_gid))) {
		DP_ERR(dev, "Local port GID not supported\n");
		memset(mac_addr, 0x00, ETH_ALEN);
		return -EINVAL;
	}

	memcpy(&in6, ah_attr->grh.dgid.raw, sizeof(in6));
#ifdef DEFINE_NO_IP_BASED_GIDS
	/* get the MAC address from the GUID i.e. EUI-64 to MAC address */
	mac_addr[0] = guid[0] ^ 2; /* toggle the local/universal bit to local */
	mac_addr[1] = guid[1];
	mac_addr[2] = guid[2];
	mac_addr[3] = guid[5];
	mac_addr[4] = guid[6];
	mac_addr[5] = guid[7];
#else
	memcpy(mac_addr, ah_attr->dmac, ETH_ALEN);
#endif
	return 0;
}

#define QEDR_ROCE_PKEY_MAX 1
#define QEDR_ROCE_PKEY_TABLE_LEN 1
#define QEDR_ROCE_PKEY_DEFAULT 0xffff

static inline void qedr_inc_sw_cons(struct qedr_qp_hwq_info *info)
{
	info->cons = (info->cons + 1) % info->max_wr;
	info->wqe_cons++;
}

static inline void qedr_inc_sw_prod(struct qedr_qp_hwq_info *info)
{
	info->prod = (info->prod + 1) % info->max_wr;
}

#endif
