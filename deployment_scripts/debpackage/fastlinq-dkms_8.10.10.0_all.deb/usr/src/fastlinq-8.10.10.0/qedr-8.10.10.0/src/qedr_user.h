#ifndef __QEDR_USER_H__
#define __QEDR_USER_H__

#define QEDR_ABI_VERSION		(6)
#define QEDR_BE_ROCE_ABI_VERSION	(1)

/* user kernel communication data structures. */

struct qedr_alloc_ucontext_resp {
	u64 db_pa;
	u32 db_size;

	uint32_t max_send_wr;
	uint32_t max_recv_wr;
	uint32_t max_srq_wr;
	uint32_t sges_per_send_wr;
	uint32_t sges_per_recv_wr;
	uint32_t sges_per_srq_wr;
	int max_cqes;
};

struct qedr_alloc_pd_ureq {
	u64 rsvd1;
};

struct qedr_alloc_pd_uresp {
	u32 pd_id;
};

struct qedr_create_cq_ureq {
	uint64_t addr;		/* user space virtual address of CQ buffer */
	size_t len;		/* size of CQ buffer */
};

struct qedr_create_cq_uresp {
	u32 db_offset;
	u16 icid;
};

struct qedr_create_qp_ureq {
	u32 qp_handle_hi;
	u32 qp_handle_lo;

	/* SQ */
	uint64_t sq_addr;	/* user space virtual address of SQ buffer */
	size_t sq_len;		/* length of SQ buffer */

	/* RQ */
	uint64_t rq_addr;	/* user space virtual address of RQ buffer */
	size_t rq_len;		/* length of RQ buffer */
};

struct qedr_create_qp_uresp {
	u32 qp_id;
	int atomic_supported;

	/* SQ*/
	u32 sq_db_offset;
	u16 sq_icid;
	
	/* RQ */
	u32 rq_db_offset;
	u16 rq_icid;
};

struct qedr_create_srq_ureq {
	/* user space virtual address of producer pair */
	uint64_t prod_pair_addr;
	uint64_t srq_addr;	/* user space virtual address of SQ buffer */
	size_t srq_len;		/* length of SQ buffer */
};

struct qedr_create_srq_uresp {
	u16 srq_id;
};

#endif				/* __QEDR_USER_H__ */
