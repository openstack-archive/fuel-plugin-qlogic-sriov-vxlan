#include <linux/dma-mapping.h>
#include <linux/crc32.h>
#include <linux/iommu.h>
#include <net/ip.h>
#include <net/ipv6.h>
#include <net/udp.h>

#include <rdma/ib_verbs.h>
#include <rdma/ib_user_verbs.h>
#include <rdma/iw_cm.h>
#include <rdma/ib_umem.h>
#include <rdma/ib_addr.h>
#include <rdma/ib_cache.h>

#include "qedr_hsi.h"
#include "qed_if.h"
#include "qed_roce_if.h"
#include "qedr.h"
#include "qedr_hsi.h"
#include "verbs.h"
#include "qedr_user.h"
#include "qedr_hsi.h"
#include "qedr_cm.h"
#include "qedr_compat.h"

void qedr_inc_sw_gsi_cons(struct qedr_qp_hwq_info *info)
{
	info->gsi_cons = (info->gsi_cons + 1) % info->max_wr;
}

void qedr_store_gsi_qp_cq(struct qedr_dev *dev, struct qedr_qp *qp,
				 struct ib_qp_init_attr *attrs)
{
	dev->gsi_qp_created = 1;
	dev->gsi_sqcq = get_qedr_cq(attrs->send_cq);
	dev->gsi_rqcq = get_qedr_cq(attrs->recv_cq);
	dev->gsi_qp = qp;
}

void qedr_ll2_tx_cb(void *_qdev, struct qed_roce_ll2_packet *pkt)
{
	struct qedr_dev *dev = (struct qedr_dev *)_qdev;
	struct qedr_cq *cq = dev->gsi_sqcq;
	struct qedr_qp *qp = dev->gsi_qp;
	unsigned long flags;

	DP_VERBOSE(dev, QEDR_MSG_GSI, "LL2 TX CB: gsi_sqcq=%p, gsi_rqcq=%p, gsi_cons=%d, ibcq_comp=%s\n", dev->gsi_sqcq, dev->gsi_rqcq, qp->sq.gsi_cons, cq->ibcq.comp_handler? "Yes" : "No");

	dma_free_coherent(&dev->pdev->dev, pkt->header.len, pkt->header.vaddr,
			 pkt->header.baddr);
	kfree(pkt);

	spin_lock_irqsave(&qp->q_lock, flags);
	qedr_inc_sw_gsi_cons(&qp->sq);
	spin_unlock_irqrestore(&qp->q_lock, flags);

	if (cq->ibcq.comp_handler) {
		spin_lock_irqsave(&cq->comp_handler_lock, flags);
		(*cq->ibcq.comp_handler) (&cq->ibcq, cq->ibcq.cq_context);
		spin_unlock_irqrestore(&cq->comp_handler_lock, flags);
	}
}

static inline void qedr_print_hex_dump(const char *str, void *buf, size_t size)
{
	print_hex_dump(KERN_INFO, str, DUMP_PREFIX_OFFSET,
		       32 /* row size */, 1 /* group size */, buf,
		       size, false /* w/o ASCII */);
}

void qedr_ll2_rx_cb(void *_dev, struct qed_roce_ll2_packet *pkt,
		struct qed_roce_ll2_rx_params *params)
{
	struct qedr_dev *dev = (struct qedr_dev *)_dev;
	struct qedr_cq *cq = dev->gsi_rqcq;
	struct qedr_qp *qp = dev->gsi_qp;
	unsigned long flags;

	/* note: currently only one recv sg is supported */

	/* CM packet dump - supported unless IOMMU is enabled */
	if (unlikely((dev->dp_level <= QED_LEVEL_VERBOSE) &&
		     (dev->dp_module & QEDR_MSG_GSI) &&
		     (!iommu_present(&pci_bus_type))))
		qedr_print_hex_dump("RX CM ",
				    phys_to_virt(pkt->payload[0].baddr),
				    pkt->payload[0].len + IB_GRH_BYTES);

	spin_lock_irqsave(&qp->q_lock, flags);

	qp->rqe_wr_id[qp->rq.gsi_cons].rc = params->rc;
	qp->rqe_wr_id[qp->rq.gsi_cons].vlan_id = params->vlan_id;
	/* note: length stands for data length i.e. GRH is excluded */
	qp->rqe_wr_id[qp->rq.gsi_cons].sg_list[0].length = pkt->payload[0].len;
	memcpy(&qp->rqe_wr_id[qp->rq.gsi_cons].smac, &params->smac, ETH_ALEN);

	qedr_inc_sw_gsi_cons(&qp->rq);

	spin_unlock_irqrestore(&qp->q_lock, flags);

	if (cq->ibcq.comp_handler) {
		spin_lock_irqsave(&cq->comp_handler_lock, flags);
		(*cq->ibcq.comp_handler) (&cq->ibcq, cq->ibcq.cq_context);
		spin_unlock_irqrestore(&cq->comp_handler_lock, flags);
	}
}

static void qedr_destroy_gsi_cq(struct qedr_dev *dev,
				struct ib_qp_init_attr *attrs)
{
	struct qed_rdma_destroy_cq_in_params iparams;
	struct qed_rdma_destroy_cq_out_params oparams;
	struct qedr_cq *cq;

	cq = get_qedr_cq(attrs->send_cq);
	iparams.icid = cq->icid;
	dev->ops->rdma_destroy_cq(dev->rdma_ctx, &iparams, &oparams);
	dev->ops->common->chain_free(dev->cdev, &cq->pbl);

	cq = get_qedr_cq(attrs->recv_cq);
	/* if a dedicated recv_cq was used, delete it too */
	if (iparams.icid != cq->icid) {
		iparams.icid = cq->icid;
		dev->ops->rdma_destroy_cq(dev->rdma_ctx, &iparams, &oparams);
		dev->ops->common->chain_free(dev->cdev, &cq->pbl);
	}
}

static inline int qedr_check_gsi_qp_attrs(struct qedr_dev *dev,
				   struct ib_qp_init_attr *attrs)
{
	if (attrs->cap.max_recv_sge > QEDR_GSI_MAX_RECV_SGE) {
		DP_ERR(dev, " create gsi qp: failed. max_recv_sge is larger the max %d>%d\n", attrs->cap.max_recv_sge, QEDR_GSI_MAX_RECV_SGE);
		return -EINVAL;
	}

	if (attrs->cap.max_recv_wr > QEDR_GSI_MAX_RECV_WR) {
		DP_ERR(dev, " create gsi qp: failed. max_recv_wr is too large %d>%d\n", attrs->cap.max_recv_wr, QEDR_GSI_MAX_RECV_WR);
		return -EINVAL;
	}

	if (attrs->cap.max_send_wr > QEDR_GSI_MAX_SEND_WR) {
		DP_ERR(dev, " create gsi qp: failed. max_send_wr is too large %d>%d\n", attrs->cap.max_send_wr, QEDR_GSI_MAX_SEND_WR);
		return -EINVAL;
	}

	return 0;
}

struct ib_qp* qedr_create_gsi_qp(struct qedr_dev *dev,
				 struct ib_qp_init_attr *attrs,
				 struct qedr_qp *qp)
{
	struct qed_roce_ll2_params ll2_params;
	int rc;

	rc = qedr_check_gsi_qp_attrs(dev, attrs);
	if (rc)
		return ERR_PTR(rc);

	/* configure and start LL2 */
	memset(&ll2_params, 0, sizeof(ll2_params));
	ll2_params.max_tx_buffers = attrs->cap.max_send_wr;
	ll2_params.max_rx_buffers = attrs->cap.max_recv_wr;
	ll2_params.cbs.tx_cb = qedr_ll2_tx_cb;
	ll2_params.cbs.rx_cb = qedr_ll2_rx_cb;
	ll2_params.cb_cookie = (void *)dev;
	ll2_params.mtu = dev->ndev->mtu;
	memcpy(ll2_params.mac_address, dev->ndev->dev_addr, ETH_ALEN);
	rc = dev->ops->roce_ll2_start(dev->cdev, &ll2_params);
	if (rc) {
		DP_ERR(dev, "create gsi qp: failed on ll2 start. rc=%d\n", rc);
		return ERR_PTR(rc);
	}

	/* create QP */
	qp->ibqp.qp_num = 1;
	qp->rq.max_wr = attrs->cap.max_recv_wr;
	qp->sq.max_wr = attrs->cap.max_send_wr;

	qp->rqe_wr_id = kzalloc(qp->rq.max_wr * sizeof(*qp->rqe_wr_id),
				GFP_KERNEL);
	if (!qp->rqe_wr_id) {
		DP_ERR(dev, "create gsi qp: failed on rqe_wr_id allocation\n");
		goto err;
	}
	qp->wqe_wr_id = kzalloc(qp->sq.max_wr * sizeof(*qp->wqe_wr_id),
				GFP_KERNEL);
	if (!qp->wqe_wr_id) {
		DP_ERR(dev, "create gsi qp: failed on wqe_wr_id allocation\n");
		goto err;
	}

	qedr_store_gsi_qp_cq(dev, qp, attrs);
	memcpy(dev->gsi_ll2_mac_address, dev->ndev->dev_addr, ETH_ALEN);

	/* the GSI CQ is handled by the driver so remove it from the FW */
	qedr_destroy_gsi_cq(dev, attrs);
	dev->gsi_rqcq->cq_type = QEDR_CQ_TYPE_GSI;
	dev->gsi_rqcq->cq_type = QEDR_CQ_TYPE_GSI;

	return &qp->ibqp;

err:
	kfree(qp->rqe_wr_id);

	rc = dev->ops->roce_ll2_stop(dev->cdev);
	if (rc)
		DP_ERR(dev, "create gsi qp: failed destroy on create\n");

	return ERR_PTR(-ENOMEM);
}

int qedr_destroy_gsi_qp(struct qedr_dev *dev)
{
	int rc;

	rc = dev->ops->roce_ll2_stop(dev->cdev);
	if (rc)
		DP_ERR(dev, "destroy gsi qp: failed (rc=%d)\n", rc);
	else
		DP_VERBOSE(dev, (QEDR_MSG_QP | QEDR_MSG_GSI), "destroy gsi qp: success\n");

	return rc;
}

#if !DEFINE_ROCE_GID_TABLE  /* !QEDR_UPSTREAM */
static inline bool qedr_get_vlan_id_gsi(struct ib_ah_attr *ah_attr,
					u16 *vlan_id)
{
	u16 tmp_vlan_id;
#ifdef DEFINE_NO_IP_BASED_GIDS
	union ib_gid *dgid = &ah_attr->grh.dgid;
#endif

#ifdef DEFINE_NO_IP_BASED_GIDS
	tmp_vlan_id = (dgid->raw[11] << 8) | dgid->raw[12];
#else
	tmp_vlan_id = ah_attr->vlan_id;
#endif

	if (tmp_vlan_id < VLAN_CFI_MASK) {
		*vlan_id = tmp_vlan_id;
		return true;
	} else {
		*vlan_id = 0;
		return false;
	}
}
#endif

#define QEDR_MAX_UD_HEADER_SIZE	(100)
#define QEDR_GSI_QPN		(1)
static inline int qedr_gsi_build_header(struct qedr_dev *dev,
				 struct qedr_qp *qp, struct ib_send_wr *swr,
				 struct ib_ud_header *udh, int *roce_mode)
{
	bool has_vlan = false, has_grh_ipv6 = true;
	struct ib_ah_attr *ah_attr = &get_qedr_ah(ud_wr(swr)->ah)->attr;
	struct ib_global_route *grh = &ah_attr->grh;
	union ib_gid sgid;
	int send_size = 0;
	u16 vlan_id = 0;
	u16 ether_type;
#if DEFINE_ROCE_GID_TABLE /* QEDR_UPSTREAM */
	struct ib_gid_attr sgid_attr;
	int rc;
#endif
#if DEFINE_ROCE_V2_SUPPORT /* QEDR_UPSTREAM */
	int ip_ver = 0;

#endif
#ifdef DEFINE_IB_UD_HEADER_INIT_UDP_PRESENT /* QEDR_UPSTREAM */
	bool has_udp = false;
#endif
#if !DEFINE_IB_AH_ATTR_WITH_DMAC /* !QEDR_UPSTREAM */
	u8 mac[ETH_ALEN];
#endif
	int i;

	send_size = 0;
	for (i = 0; i < swr->num_sge; ++i)
		send_size += swr->sg_list[i].length;

#if DEFINE_ROCE_GID_TABLE /* QEDR_UPSTREAM */
	rc = ib_get_cached_gid(qp->ibqp.device, ah_attr->port_num,
			       grh->sgid_index, &sgid, &sgid_attr);
	if (rc) {
		DP_ERR(dev, "gsi post send: failed to get cached GID (port=%d, ix=%d)\n", ah_attr->port_num, grh->sgid_index);
		return rc;
	}

	vlan_id = rdma_vlan_dev_vlan_id(sgid_attr.ndev);
	if (vlan_id < VLAN_CFI_MASK)
		has_vlan = true;
	if (sgid_attr.ndev)
		dev_put(sgid_attr.ndev);

	if (!memcmp(&sgid, &zgid, sizeof(sgid))) {
		DP_ERR(dev, "gsi post send: GID not found GID index %d\n", ah_attr->grh.sgid_index);
		return -ENOENT;
	}

#if DEFINE_ROCE_V2_SUPPORT /* QEDR_UPSTREAM */
	has_udp = (sgid_attr.gid_type == IB_GID_TYPE_ROCE_UDP_ENCAP);
	if (!has_udp) {
		/* RoCE v1 */
		ether_type = ETH_P_ROCE;
		*roce_mode = ROCE_V1;
	} else  if (ipv6_addr_v4mapped((struct in6_addr *)&sgid)) {
		/* RoCE v2 IPv4 */
		ip_ver = 4;
		ether_type = ETH_P_IP;
		has_grh_ipv6 = false;
		*roce_mode = ROCE_V2_IPV4;
	} else {
		/* RoCE v2 IPv6 */
		ip_ver = 6;
		ether_type = ETH_P_IPV6;
		*roce_mode = ROCE_V2_IPV6;
	}
#else
	ether_type = ETH_P_ROCE;
	*roce_mode = ROCE_V1;

#endif
#else
	has_vlan = qedr_get_vlan_id_gsi(ah_attr, &vlan_id);
	ether_type = ETH_P_ROCE;
	*roce_mode = ROCE_V1;
	if (grh->sgid_index < QEDR_MAX_SGID)
		sgid = dev->sgid_tbl[grh->sgid_index];
	else
		sgid = dev->sgid_tbl[0];
#endif

#ifdef DEFINE_IB_UD_HEADER_INIT_UDP_PRESENT /* QEDR_UPSTREAM */
	rc = ib_ud_header_init(send_size, false /* LRH */, true /* ETH */,
			       has_vlan, has_grh_ipv6, ip_ver, has_udp,
			       0 /* immediate */, udh);
	if (rc) {
		DP_ERR(dev, "gsi post send: failed to init header\n");
		return rc;
	}
#else
	ib_ud_header_init(send_size, false /* LRH */, true /* ETH */,
			  has_vlan, has_grh_ipv6, 0 /* immediate */, udh);
#endif

	/* ENET + VLAN headers*/
#if DEFINE_IB_AH_ATTR_WITH_DMAC /* QEDR_UPSTREAM */
	memcpy(udh->eth.dmac_h, ah_attr->dmac, ETH_ALEN);
#else
	qedr_get_dmac(dev, ah_attr, mac);
	memcpy(udh->eth.dmac_h, mac, ETH_ALEN);
#endif
	memcpy(udh->eth.smac_h, dev->ndev->dev_addr, ETH_ALEN);
	if (has_vlan) {
		udh->eth.type = htons(ETH_P_8021Q);
		udh->vlan.tag = htons(vlan_id);
		udh->vlan.type = htons(ether_type);
	} else {
		udh->eth.type = htons(ether_type);
	}

	/* BTH */
	udh->bth.solicited_event = !!(swr->send_flags & IB_SEND_SOLICITED);
	udh->bth.pkey = QEDR_ROCE_PKEY_DEFAULT;	/* TODO: ib_get_cahced_pkey?! */
	udh->bth.destination_qpn = htonl(ud_wr(swr)->remote_qpn);
	udh->bth.psn = htonl((qp->sq_psn++) & ((1 << 24) - 1));
	udh->bth.opcode = IB_OPCODE_UD_SEND_ONLY;

	/* DETH */
	udh->deth.qkey = htonl(0x80010000); /* qp->qkey */ /* TODO: what is?! */
	udh->deth.source_qpn = htonl(QEDR_GSI_QPN);

	if (has_grh_ipv6) {
		/* GRH / IPv6 header */
		udh->grh.traffic_class = grh->traffic_class;
		udh->grh.flow_label = grh->flow_label;
		udh->grh.hop_limit = grh->hop_limit;
		udh->grh.destination_gid = grh->dgid;
		memcpy(&udh->grh.source_gid.raw, &sgid.raw,
		       sizeof(udh->grh.source_gid.raw));
	}
#ifdef DEFINE_IB_UD_HEADER_INIT_UDP_PRESENT /* QEDR_UPSTREAM */
	else {
		/* IPv4 header */
		u32 ipv4_addr;

		udh->ip4.protocol = IPPROTO_UDP;
		udh->ip4.tos = htonl(ah_attr->grh.flow_label);
		udh->ip4.frag_off = htons(IP_DF);
		udh->ip4.ttl = ah_attr->grh.hop_limit;

		ipv4_addr = qedr_get_ipv4_from_gid(sgid.raw);
		udh->ip4.saddr = ipv4_addr;
		ipv4_addr = qedr_get_ipv4_from_gid(ah_attr->grh.dgid.raw);
		udh->ip4.daddr = ipv4_addr;
		/* note: checksum is calculated by the device */
	}
#endif

#ifdef DEFINE_IB_UD_HEADER_INIT_UDP_PRESENT /* QEDR_UPSTREAM */
	/* UDP*/
	if (has_udp) {
		udh->udp.sport = htons(QEDR_ROCE_V2_UDP_SPORT);
		udh->udp.dport = htons(ROCE_V2_UDP_DPORT);
		udh->udp.csum = 0;
		/* UDP length is untouched hence is zero */
		/* TODO: set UDP source port to a hash of the GIDs and QP #.
		 * Why: it may be used by switches along the way for path
		 * selection. Hence it must be fixed for flows that should
		 * maintain order.
		 */
	}
#endif
	return 0;
}

static inline int qedr_gsi_build_packet(struct qedr_dev *dev,
				 struct qedr_qp *qp, struct ib_send_wr *swr,
				 struct qed_roce_ll2_packet **p_packet)
{
	u8 ud_header_buffer[QEDR_MAX_UD_HEADER_SIZE];
	struct qed_roce_ll2_packet *packet;
	struct pci_dev *pdev = dev->pdev;
	int roce_mode, header_size;
	struct ib_ud_header udh;
	int i, rc;

	*p_packet = NULL;

	rc = qedr_gsi_build_header(dev, qp, swr, &udh, &roce_mode);
	if (rc)
		return rc;

	header_size = ib_ud_header_pack(&udh, &ud_header_buffer);

	packet = kzalloc(sizeof(*packet), GFP_ATOMIC);
	if (!packet) {
		DP_ERR(dev, "gsi post send: failed to allocate packet\n");
		return -ENOMEM;
	}

	packet->header.vaddr = dma_alloc_coherent(&pdev->dev, header_size,
						 &packet->header.baddr,
						 GFP_ATOMIC);
	if (!packet->header.vaddr) {
		DP_ERR(dev, "cm header build: failed to allocate buffer for header\n");
		kfree(packet);
		return -ENOMEM;
	}

	if (memcmp(udh.eth.smac_h, udh.eth.dmac_h, ETH_ALEN))
		packet->tx_dest = QED_ROCE_LL2_TX_DEST_NW;
	else
		packet->tx_dest = QED_ROCE_LL2_TX_DEST_LB;

	packet->roce_mode = roce_mode;
	memcpy(packet->header.vaddr, ud_header_buffer, header_size);
	packet->header.len = header_size;
	packet->n_seg = swr->num_sge;
	for (i = 0; i < packet->n_seg; i++) {
		packet->payload[i].baddr = swr->sg_list[i].addr;
		packet->payload[i].len = swr->sg_list[i].length;
	}

	*p_packet = packet;

	return 0;
}

int qedr_gsi_post_send(struct ib_qp *ibqp, struct ib_send_wr *wr,
		       struct ib_send_wr **bad_wr)
{
	struct qed_roce_ll2_packet *pkt = NULL;
	struct qedr_qp *qp = get_qedr_qp(ibqp);
	struct qed_roce_ll2_tx_params params;
	struct qedr_dev *dev = qp->dev;
	unsigned long flags;
	int rc;

	if (qp->state != QED_ROCE_QP_STATE_RTS) {
		*bad_wr = wr;
		DP_ERR(dev, "gsi post recv: failed to post rx buffer. state is %d and not QED_ROCE_QP_STATE_RTS", qp->state);
		return -EINVAL;
	}

	if (wr->num_sge > RDMA_MAX_SGE_PER_SQ_WQE) {
		DP_ERR(dev, "gsi post send: num_sge is too large (%d>%d)\n", wr->num_sge, RDMA_MAX_SGE_PER_SQ_WQE);
		rc = -EINVAL;
		goto err;
	}

	if (wr->opcode != IB_WR_SEND) {
		DP_ERR(dev, "gsi post send: failed due to unsupported opcode %d\n", wr->opcode);
		rc = -EINVAL;
		goto err;
	}

	memset(&params, 0, sizeof(params));

	spin_lock_irqsave(&qp->q_lock, flags);

	rc = qedr_gsi_build_packet(dev, qp, wr, &pkt);
	if(rc) {
		spin_unlock_irqrestore(&qp->q_lock, flags);
		goto err;
	}

	if (unlikely((dev->dp_level <= QED_LEVEL_VERBOSE) &&
		     (dev->dp_module & QEDR_MSG_GSI)))
		qedr_print_hex_dump("TX CM Header ", pkt->header.vaddr,
				     pkt->header.len);

	rc = dev->ops->roce_ll2_tx(dev->cdev, pkt, &params);
	if (!rc) {
		qp->wqe_wr_id[qp->sq.prod].wr_id = wr->wr_id;
		qedr_inc_sw_prod(&qp->sq);
		DP_VERBOSE(qp->dev, QEDR_MSG_GSI, "gsi post send: opcode=%d, in_irq=%ld, irqs_disabled=%d, wr_id=%llx\n", wr->opcode, in_irq(), irqs_disabled(), wr->wr_id);
	} else {
		if (rc == QED_ROCE_TX_HEAD_FAILURE){
			/* TX failed while posting header - release resources*/
			dma_free_coherent(&dev->pdev->dev, pkt->header.len,
					  pkt->header.vaddr, pkt->header.baddr);
			kfree(pkt);
		} else if (rc == QED_ROCE_TX_FRAG_FAILURE) {
			/* NTD since TX failed while posting a fragment. We will
			 * release the resources on TX callback
			 */
		}

		DP_ERR(dev, "gsi post send: failed to transmit (rc=%d)\n", rc);
		rc = -EAGAIN;
		*bad_wr = wr;
	}

	spin_unlock_irqrestore(&qp->q_lock, flags);

	if (wr->next != NULL) {
		DP_ERR(dev, "gsi post send: failed second WR. Only one WR may be passed at a time\n");
		*bad_wr = wr->next;
		rc=-EINVAL;
	}

	return rc;

err:
	*bad_wr = wr;
	return rc;
}

int qedr_gsi_post_recv(struct ib_qp *ibqp, struct ib_recv_wr *wr,
		       struct ib_recv_wr **bad_wr)
{
	struct qedr_dev *dev = get_qedr_dev(ibqp->device);
	struct qedr_qp *qp = get_qedr_qp(ibqp);
	struct qed_roce_ll2_buffer buf;
	unsigned long flags;
	int status = 0;
	int rc;

	if ((qp->state != QED_ROCE_QP_STATE_RTR) &&
	    (qp->state != QED_ROCE_QP_STATE_RTS)) {
		*bad_wr = wr;
		DP_ERR(dev, "gsi post recv: failed to post rx buffer. state is %d and not QED_ROCE_QP_STATE_RTR/S", qp->state);
		return -EINVAL;
	}

	memset(&buf, 0, sizeof(buf));

	spin_lock_irqsave(&qp->q_lock, flags);

	while (wr) {
		if (wr->num_sge > QEDR_GSI_MAX_RECV_SGE) {
			DP_ERR(dev, "gsi post recv: failed to post rx buffer. too many sges %d>%d", wr->num_sge, QEDR_GSI_MAX_RECV_SGE);
			goto err;
		}

		buf.baddr = wr->sg_list[0].addr;
		buf.len = wr->sg_list[0].length;

		rc = dev->ops->roce_ll2_post_rx_buffer(dev->cdev, &buf,
						       0 /* cookie */,
						       1 /* notify_fw */);
		if (rc) {
			DP_ERR(dev, "gsi post recv: failed to post rx buffer (rc=%d)", rc);
			goto err;
		}

		memset(&qp->rqe_wr_id[qp->rq.prod], 0, sizeof(qp->rqe_wr_id[qp->rq.prod]));
		qp->rqe_wr_id[qp->rq.prod].sg_list[0] = wr->sg_list[0];
		qp->rqe_wr_id[qp->rq.prod].wr_id = wr->wr_id;

		qedr_inc_sw_prod(&qp->rq);

		wr = wr->next;
	}

	spin_unlock_irqrestore(&qp->q_lock, flags);

	return status;
err:
	spin_unlock_irqrestore(&qp->q_lock, flags);
	*bad_wr = wr;
	return -ENOMEM;
}

int qedr_gsi_poll_cq(struct ib_cq *ibcq, int num_entries, struct ib_wc *wc)
{
	struct qedr_dev *dev = get_qedr_dev(ibcq->device);
	struct qedr_cq *cq = get_qedr_cq(ibcq);
	struct qedr_qp *qp = dev->gsi_qp;
	unsigned long flags;
	int i = 0;

	spin_lock_irqsave(&cq->cq_lock, flags);

	while (i < num_entries && qp->rq.cons != qp->rq.gsi_cons) {
		memset(&wc[i], 0, sizeof(*wc));

		wc[i].qp = &qp->ibqp;
		wc[i].wr_id = qp->rqe_wr_id[qp->rq.cons].wr_id;
		wc[i].opcode = IB_WC_RECV;
		wc[i].pkey_index = 0;
		wc[i].status = (qp->rqe_wr_id[qp->rq.cons].rc)?
			       IB_WC_GENERAL_ERR:IB_WC_SUCCESS;
		/* 0 - currently only one recv sg is supported */
		wc[i].byte_len = qp->rqe_wr_id[qp->rq.cons].sg_list[0].length;
#if DEFINED_IB_WC_IP_CSUM_OK /* QEDR_UPSTREAM */
		wc[i].wc_flags |= IB_WC_GRH | IB_WC_IP_CSUM_OK;
#else
		wc[i].wc_flags |= IB_WC_GRH;
#endif
#if DEFINED_IB_WC_WITH_SMAC /* QEDR_UPSTREAM */
		memcpy(&wc[i].smac, qp->rqe_wr_id[qp->rq.cons].smac, ETH_ALEN);
		wc[i].wc_flags |= IB_WC_WITH_SMAC;
#endif
#if DEFINED_IB_WC_WITH_VLAN /* QEDR_UPSTREAM */
		if (qp->rqe_wr_id[qp->rq.cons].vlan_id) {
			wc[i].wc_flags |= IB_WC_WITH_VLAN;
			wc[i].vlan_id = qp->rqe_wr_id[qp->rq.cons].vlan_id;
		}
#endif

		qedr_inc_sw_cons(&qp->rq);
		i++;
	}

	while (i < num_entries && qp->sq.cons != qp->sq.gsi_cons) {
		memset(&wc[i], 0, sizeof(*wc));

		wc[i].qp = &qp->ibqp;
		wc[i].wr_id = qp->wqe_wr_id[qp->sq.cons].wr_id;
		wc[i].opcode = IB_WC_SEND;
		wc[i].status = IB_WC_SUCCESS;

		qedr_inc_sw_cons(&qp->sq);
		i++;
	}

	spin_unlock_irqrestore(&cq->cq_lock, flags);

	DP_VERBOSE(dev, (QEDR_MSG_CQ | QEDR_MSG_GSI), "gsi poll_cq: requested entries=%d, actual=%d, qp->rq.cons=%d, qp->rq.gsi_cons=%x, qp->sq.cons=%d, qp->sq.gsi_cons=%d, qp_num=%d\n", num_entries, i, qp->rq.cons, qp->rq.gsi_cons, qp->sq.cons, qp->sq.gsi_cons, qp->ibqp.qp_num);

	return i;
}

