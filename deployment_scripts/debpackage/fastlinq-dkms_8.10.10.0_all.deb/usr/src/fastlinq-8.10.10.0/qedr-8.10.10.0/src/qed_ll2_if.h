#ifndef _QED_LL2_IF_H
#define _QED_LL2_IF_H
#include <linux/types.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/skbuff.h>
#include <linux/types.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include "qed_if.h"
struct qed_ll2_stats {
	u64 gsi_invalid_hdr;
	u64 gsi_invalid_pkt_length;
	u64 gsi_unsupported_pkt_typ;
	u64 gsi_crcchksm_error;

	u64 packet_too_big_discard;
	u64 no_buff_discard;

	u64 rcv_ucast_bytes;
	u64 rcv_mcast_bytes;
	u64 rcv_bcast_bytes;
	u64 rcv_ucast_pkts;
	u64 rcv_mcast_pkts;
	u64 rcv_bcast_pkts;

	u64 sent_ucast_bytes;
	u64 sent_mcast_bytes;
	u64 sent_bcast_bytes;
	u64 sent_ucast_pkts;
	u64 sent_mcast_pkts;
	u64 sent_bcast_pkts;
};

#if !defined(QED_UPSTREAM)
/* It's nasty that we have to have these defines inside the interface header,
 * as they match the qed_compat.h headers - but protocol clients won't include
 * that file, thus the duplication
 */
#ifndef RHEL_RELEASE_VERSION
#define RHEL_RELEASE_VERSION(a, b) 0
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 37)) && !defined(MODERN_VLAN)
#define MODERN_VLAN
#endif

#endif

#define QED_LL2_UNUSED_HANDLE   (0xff)

struct qed_ll2_cb_ops {
#ifdef MODERN_VLAN
	int (*rx_cb) (void *, struct sk_buff *, u32, u32);
#else
	int (*rx_cb) (void *, struct sk_buff *, u16 vlan, u32, u32);
#endif
	int (*tx_cb) (void *, struct sk_buff *, bool);
};

struct qed_ll2_params {
	u16 mtu;
	bool drop_ttl0_packets;
	bool rx_vlan_stripping;
	u8 tx_tc;
	bool frags_mapped;
	u8 ll2_mac_address[ETH_ALEN];
};

struct qed_ll2_ops {
/**
 * @brief start - initializes ll2
 *
 * @param cdev
 * @param params - protocol driver configuration for the ll2.
 *
 * @return 0 on success, otherwise error value.
 */
	int (*start) (struct qed_dev * cdev, struct qed_ll2_params * params);

/**
 * @brief stop - stops the ll2
 *
 * @param cdev
 *
 * @return 0 on success, otherwise error value.
 */
	int (*stop) (struct qed_dev * cdev);

/**
 * @brief start_xmit - transmits an skb over the ll2 interface
 *
 * @param cdev
 * @param skb
 *
 * @return 0 on success, otherwise error value.
 */
	int (*start_xmit) (struct qed_dev * cdev, struct sk_buff * skb);

/**
 * @brief register_cb_ops - protocol driver register the callback for Rx/Tx
 * packets. Should be called before `start'.
 *
 * @param cdev
 * @param cookie - to be passed to the callback functions.
 * @param ops - the callback functions to register for Rx / Tx.
 *
 * @return 0 on success, otherwise error value.
 */
	void (*register_cb_ops) (struct qed_dev * cdev,
				 const struct qed_ll2_cb_ops * ops,
				 void *cookie);

/**
 * @brief get LL2 related statistics
 *
 * @param cdev
 * @param stats - pointer to struck that would be filled we stats
 *
 * @return 0 on success, error otherwise.
 */
	int (*get_stats) (struct qed_dev * cdev, struct qed_ll2_stats * stats);
};

#ifdef CONFIG_QED_LL2
int qed_ll2_alloc_if(struct qed_dev *);
void qed_ll2_dealloc_if(struct qed_dev *);
#else
static const struct qed_ll2_ops qed_ll2_ops_pass = {
	INIT_STRUCT_FIELD(start, NULL),
	INIT_STRUCT_FIELD(stop, NULL),
	INIT_STRUCT_FIELD(start_xmit, NULL),
	INIT_STRUCT_FIELD(register_cb_ops, NULL),
	INIT_STRUCT_FIELD(get_stats, NULL),
};

static inline int qed_ll2_alloc_if(struct qed_dev *cdev)
{
	return 0;
}

static inline void qed_ll2_dealloc_if(struct qed_dev *cdev)
{
}
#endif
#endif
