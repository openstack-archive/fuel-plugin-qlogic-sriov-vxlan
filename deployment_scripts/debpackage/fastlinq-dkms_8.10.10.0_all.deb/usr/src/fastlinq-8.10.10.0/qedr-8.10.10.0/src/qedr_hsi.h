#ifndef __QED_HSI_ROCE__
#define __QED_HSI_ROCE__ 
/********************************/
/* Add include to common target */
/********************************/
#include "common_hsi.h"

/************************************************************************/
/* Add include to common roce target for both eCore and protocol roce driver */
/************************************************************************/
#include "roce_common.h"
/************************************************************************/
/* Add include to qed hsi rdma target for both roce and iwarp qed driver */
/************************************************************************/
#include "qedr_hsi_rdma.h"

/*
 * Affiliated asynchronous events / errors enumeration
 */
enum roce_async_events_type
{
	ROCE_ASYNC_EVENT_NONE=0,
	ROCE_ASYNC_EVENT_COMM_EST=1,
	ROCE_ASYNC_EVENT_SQ_DRAINED,
	ROCE_ASYNC_EVENT_SRQ_LIMIT,
	ROCE_ASYNC_EVENT_LAST_WQE_REACHED,
	ROCE_ASYNC_EVENT_CQ_ERR,
	ROCE_ASYNC_EVENT_LOCAL_INVALID_REQUEST_ERR,
	ROCE_ASYNC_EVENT_LOCAL_CATASTROPHIC_ERR,
	ROCE_ASYNC_EVENT_LOCAL_ACCESS_ERR,
	ROCE_ASYNC_EVENT_QP_CATASTROPHIC_ERR,
	ROCE_ASYNC_EVENT_CQ_OVERFLOW_ERR,
	ROCE_ASYNC_EVENT_SRQ_EMPTY,
	MAX_ROCE_ASYNC_EVENTS_TYPE
};

#endif /* __QED_HSI_ROCE__ */
