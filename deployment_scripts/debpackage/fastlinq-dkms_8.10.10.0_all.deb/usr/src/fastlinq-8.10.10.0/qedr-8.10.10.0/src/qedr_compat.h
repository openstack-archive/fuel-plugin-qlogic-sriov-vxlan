#ifndef _QEDR_COMPAT_H_
#define _QEDR_COMPAT_H_

#ifndef ROCE_V2_UDP_DPORT
#define ROCE_V2_UDP_DPORT	(4791)
#endif

#ifdef NOT_DEFINED_IOMMU_PRESENT
static inline bool iommu_present(struct bus_type *bus)
{
	return iommu_found();
}
#endif

#ifndef array_size
#define array_size(x)  (sizeof(x) / sizeof((x)[0]))
#endif

#endif
