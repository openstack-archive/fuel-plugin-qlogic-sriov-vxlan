#ifndef __QEDR_VERBS_H__
#define __QEDR_VERBS_H__

int qedr_post_send(struct ib_qp *, struct ib_send_wr *,
		     struct ib_send_wr **bad_wr);
int qedr_post_recv(struct ib_qp *, struct ib_recv_wr *,
		     struct ib_recv_wr **bad_wr);

int qedr_poll_cq(struct ib_cq *, int num_entries, struct ib_wc *wc);
int qedr_arm_cq(struct ib_cq *, enum ib_cq_notify_flags flags);
#ifdef DEFINE_QUERY_DEVICE_PASS_VENDOR_SPECIFIC_DATA /* QEDR_UPSTREAM */
int qedr_query_device(struct ib_device *ibdev,
		      struct ib_device_attr *attr,
		      struct ib_udata *udata);
#else
int qedr_query_device(struct ib_device *, struct ib_device_attr *props);

#endif
int qedr_query_port(struct ib_device *, u8 port, struct ib_port_attr *props);
int qedr_modify_port(struct ib_device *, u8 port, int mask,
		       struct ib_port_modify *props);

int qedr_query_gid(struct ib_device *, u8 port,
		     int index, union ib_gid *gid);
int qedr_query_pkey(struct ib_device *, u8 port, u16 index, u16 *pkey);

struct ib_ucontext *qedr_alloc_ucontext(struct ib_device *,
					  struct ib_udata *);
int qedr_dealloc_ucontext(struct ib_ucontext *);

int qedr_mmap(struct ib_ucontext *, struct vm_area_struct *vma);

struct ib_pd *qedr_alloc_pd(struct ib_device *,
			      struct ib_ucontext *, struct ib_udata *);
int qedr_dealloc_pd(struct ib_pd *pd);

#ifdef DEFINE_CREATE_CQ_ATTR  /* QEDR_UPSTREAM */
struct ib_cq *qedr_create_cq(struct ib_device *ibdev,
			     const struct ib_cq_init_attr *attr,
			     struct ib_ucontext *ib_ctx,
			     struct ib_udata *udata);
#else
struct ib_cq *qedr_create_cq(struct ib_device *, int entries, int vector,
			       struct ib_ucontext *, struct ib_udata *);
#endif
int qedr_resize_cq(struct ib_cq *, int cqe, struct ib_udata *);
int qedr_destroy_cq(struct ib_cq *);

struct ib_qp *qedr_create_qp(struct ib_pd *,
			       struct ib_qp_init_attr *attrs,
			       struct ib_udata *);
int _qedr_modify_qp(struct ib_qp *, struct ib_qp_attr *attr,
		      int attr_mask);
int qedr_modify_qp(struct ib_qp *, struct ib_qp_attr *attr,
		     int attr_mask, struct ib_udata *udata);
int qedr_query_qp(struct ib_qp *,
		    struct ib_qp_attr *qp_attr,
		    int qp_attr_mask, struct ib_qp_init_attr *);
int qedr_destroy_qp(struct ib_qp *);

struct ib_srq *qedr_create_srq(struct ib_pd *, struct ib_srq_init_attr *,
				 struct ib_udata *);
int qedr_modify_srq(struct ib_srq *, struct ib_srq_attr *,
		      enum ib_srq_attr_mask, struct ib_udata *);
int qedr_query_srq(struct ib_srq *, struct ib_srq_attr *);
int qedr_destroy_srq(struct ib_srq *);
int qedr_post_srq_recv(struct ib_srq *, struct ib_recv_wr *,
			 struct ib_recv_wr **bad_recv_wr);
int qedr_modify_srq(struct ib_srq *, struct ib_srq_attr *,
		    enum ib_srq_attr_mask, struct ib_udata *);
int qedr_dereg_mr(struct ib_mr *);
struct ib_mr *qedr_get_dma_mr(struct ib_pd *, int acc);
#ifdef DEFINE_REG_PHYS_MR /* ! QEDR_UPSTREAM */
struct ib_mr *qedr_reg_kernel_mr(struct ib_pd *,
				   struct ib_phys_buf *buffer_list,
				   int num_phys_buf, int acc, u64 *iova_start);
#endif

#ifdef DEFINE_USER_NO_MR_ID /* QEDR_UPSTREAM */
struct ib_mr *qedr_reg_user_mr(struct ib_pd *, u64 start, u64 length,
			       u64 virt, int acc, struct ib_udata *);
#else
struct ib_mr *qedr_reg_user_mr(struct ib_pd *, u64 start, u64 length,
			       u64 virt, int acc, struct ib_udata *,
			       int mr_id);
#endif

#ifdef DEFINE_MAP_MR_SG /* QEDR_UPSTREAM */
#ifdef DEFINE_MAP_MR_SG_OFFSET /* QEDR_UPSTREAM */
int qedr_map_mr_sg(struct ib_mr *ibmr, struct scatterlist *sg,
		   int sg_nents, unsigned int *sg_offset);
#else
#ifndef DEFINE_MAP_MR_SG_UNSIGNED
int qedr_map_mr_sg(struct ib_mr *ibmr, struct scatterlist *sg,
		   int sg_nents);
#else
int qedr_map_mr_sg(struct ib_mr *ibmr, struct scatterlist *sg,
		   unsigned int sg_nents);
#endif
#endif
#endif

#ifdef DEFINE_ALLOC_MR /* QEDR_UPSTREAM */
struct ib_mr *qedr_alloc_mr(struct ib_pd *pd,
			    enum ib_mr_type mr_type,
			    u32 max_num_sg);
#else
struct ib_mr *qedr_alloc_frmr(struct ib_pd *pd, int max_page_list_len);
struct ib_fast_reg_page_list *qedr_alloc_frmr_page_list(struct ib_device
							*ibdev,
							int page_list_len);
void qedr_free_frmr_page_list(struct ib_fast_reg_page_list *page_list);
#endif

#ifdef _HAS_CREATE_AH_UDATA /* ! QEDR_UPSTREAM */
struct ib_ah *qedr_create_ah(struct ib_pd *ibpd, struct ib_ah_attr *attr,
			     struct ib_udata *udata);
#else
struct ib_ah *qedr_create_ah(struct ib_pd *ibpd, struct ib_ah_attr *attr);
#endif

int qedr_destroy_ah(struct ib_ah *ibah);

int qedr_query_ah(struct ib_ah *ibah, struct ib_ah_attr *attr);

int qedr_modify_ah(struct ib_ah *ibah, struct ib_ah_attr *attr);

#ifdef DEFINE_PROCESS_MAD_VARIABLE_SIZE /* QEDR_UPSTREAM */
int qedr_process_mad(struct ib_device *ibdev,
		     int process_mad_flags,
		     u8 port_num,
		     const struct ib_wc *in_wc,
		     const struct ib_grh *in_grh,
		     const struct ib_mad_hdr *in_mad,
		     size_t in_mad_size,
		     struct ib_mad_hdr *out_mad,
		     size_t *out_mad_size,
		     u16 *out_mad_pkey_index);
#elif defined(DEFINE_PROCESS_MAD_CONST_INPUTS)
int qedr_process_mad(struct ib_device *ibdev,
		     int process_mad_flags,
		     u8 port_num,
		     const struct ib_wc *in_wc,
		     const struct ib_grh *in_grh,
		     const struct ib_mad *in_mad,
		     struct ib_mad *out_mad);
#else
int qedr_process_mad(struct ib_device *ibdev,
		     int process_mad_flags,
		     u8 port_num,
		     struct ib_wc *in_wc,
		     struct ib_grh *in_grh,
		     struct ib_mad *in_mad,
		     struct ib_mad *out_mad);
#endif

#if DEFINE_PORT_IMMUTABLE /* QEDR_UPSTREAM */
int qedr_port_immutable(struct ib_device *ibdev, u8 port_num,
			struct ib_port_immutable *immutable);
#endif

#endif

int qedr_iw_connect(struct iw_cm_id *cm_id,
		    struct iw_cm_conn_param *conn_param);

int qedr_iw_create_listen(struct iw_cm_id *cm_id, int backlog);

int qedr_iw_destroy_listen(struct iw_cm_id *cm_id);

int qedr_iw_accept_cr(struct iw_cm_id *cm_id,
		      struct iw_cm_conn_param *conn_param);

int qedr_iw_reject_cr(struct iw_cm_id *cm_id, const void *pdata, u8 pdata_len);

void qedr_iw_qp_add_ref(struct ib_qp *qp);

void qedr_iw_qp_rem_ref(struct ib_qp *qp);

struct ib_qp *qedr_iw_get_qp(struct ib_device *dev, int qpn);

#if DEFINE_ROCE_GID_TABLE /* QEDR_UPSTREAM */
int qedr_del_gid(struct ib_device *device, u8 port_num,
		 unsigned int index, void **context);

int qedr_add_gid(struct ib_device *device, u8 port_num,
		 unsigned int index, const union ib_gid *gid,
		 const struct ib_gid_attr *attr, void **context);
#endif
