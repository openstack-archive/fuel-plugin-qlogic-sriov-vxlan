#ifndef __QELR_ABI_H__
#define __QELR_ABI_H__

#include <infiniband/kern-abi.h>

#define QELR_ABI_VERSION			(6)

struct qelr_get_context {
	struct ibv_get_context cmd;		/* must be first */
};

struct qelr_alloc_ucontext_resp {
	struct ibv_get_context_resp ibv_resp;	/* must be first */
	u64 db_pa;
	u32 db_size;

	uint32_t max_send_wr;
	uint32_t max_recv_wr;
	uint32_t max_srq_wr;
	uint32_t sges_per_send_wr;
	uint32_t sges_per_recv_wr;
	uint32_t sges_per_srq_wr;
	int max_cqes;
};

struct qelr_alloc_pd_req {
	struct ibv_alloc_pd cmd;		/* must be first */
};

struct qelr_alloc_pd_resp {
	struct ibv_alloc_pd_resp ibv_resp;	/* must be first */
	uint32_t pd_id;
};

struct qelr_create_cq_req {
	struct ibv_create_cq ibv_cmd;		/* must be first */

	uint64_t addr;	/* user space virtual address of CQ buffer */
	size_t len;	/* size of CQ buffer */
};

struct qelr_create_cq_resp {
	struct ibv_create_cq_resp ibv_resp;	/* must be first */
	uint32_t db_offset;
	uint16_t icid;
};

struct qelr_reg_mr {
	struct ibv_reg_mr ibv_cmd;		/* must be first */
};

struct qelr_reg_mr_resp {
	struct ibv_reg_mr_resp ibv_resp;	/* must be first */
};

struct qelr_create_srq_req {
	struct ibv_create_srq ibv_cmd;
	/* user space virtual address of producer pair */
	uint64_t prod_pair_addr;

	/* SRQ */
	uint64_t srq_addr;	/* user space virtual address of SRQ buffer */
	size_t srq_len;		/* length of SRQ buffer */
};

struct qelr_create_srq_resp {
	struct ibv_create_srq_resp ibv_resp;
	u16 srq_id;
};

struct qelr_create_qp_req {
	struct ibv_create_qp ibv_qp;	/* must be first */

	uint32_t qp_handle_hi;
	uint32_t qp_handle_lo;

	/* SQ */
	uint64_t sq_addr;	/* user space virtual address of SQ buffer */
	size_t sq_len;		/* length of SQ buffer */

	/* RQ */
	uint64_t rq_addr;	/* user space virtual address of RQ buffer */
	size_t rq_len;		/* length of RQ buffer */
}; 

struct qelr_create_qp_resp {
	struct ibv_create_qp_resp ibv_resp;	/* must be first */

	u32 qp_id;
	int atomic_supported;

	/* SQ */
	uint32_t sq_db_offset;
	u16 sq_icid;
	
	/* RQ */
	uint32_t rq_db_offset;
	u16 rq_icid;
};

#endif				/* __QELR_ABI_H__ */
