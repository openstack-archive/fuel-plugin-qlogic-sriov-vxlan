/* Copyright 2016 QLogic Corporation
 *
 * Unless you and QLogic execute a separate written software license agreement
 * governing use of this software, this software is licensed to you under the
 * terms of the GNU General Public License version 2 (the "GPL"), available at
 * http://www.gnu.org/licenses/gpl-2.0.html, with the following added to such
 * license:
 *
 * As a special exception, the copyright holders of this software give you
 * permission to link this software with independent modules, and to copy and
 * distribute the resulting executable under terms of your choice, provided that
 * you also meet, for each linked independent module, the terms and conditions
 * of the license of that module.  An independent module is a module which is
 * not derived from this software.  The special exception does not apply to any
 * modifications of the software.
 */

#include <sys/types.h>
#include <sys/mman.h>
#include <stdio.h>
#include <string.h>
#include <endian.h>
#include <errno.h>

#include "qelr.h"

void *qelr_chain_get_last_elem(struct qelr_chain *p_chain)
{
	void			*p_virt_addr	= NULL;
	u32			size;

	if (!p_chain->addr)
		goto out;

	size		= p_chain->elem_size * (p_chain->n_elems - 1);
	p_virt_addr	= ((u8 *)p_chain->addr + size);
out:
	return p_virt_addr;
}

void qelr_chain_reset(struct qelr_chain *p_chain)
{
	p_chain->prod_idx	= 0;
	p_chain->cons_idx	= 0;

	p_chain->p_cons_elem	= p_chain->addr;
	p_chain->p_prod_elem	= p_chain->addr;
}

#define QELR_ANON_FD		(-1)	/* MAP_ANONYMOUS => file desc.= -1  */
#define QELR_ANON_OFFSET	(0)	/* MAP_ANONYMOUS => offset    = d/c */

int qelr_chain_alloc(struct qelr_chain *chain, int chain_size, int page_size,
		     u16 elem_size)
{
	int ret, a_chain_size;
	void *addr;

	/* alloc aligned page aligned chain */
	a_chain_size = (chain_size + page_size -1) & ~(page_size - 1);
	addr = mmap(NULL, a_chain_size, PROT_READ | PROT_WRITE,
			 MAP_PRIVATE | MAP_ANONYMOUS, QELR_ANON_FD,
			 QELR_ANON_OFFSET);
	if (chain->addr == MAP_FAILED)
		return errno;

	ret = ibv_dontfork_range(addr, a_chain_size);
	if (ret) {
		munmap(addr, a_chain_size);
		return ret;
	}

	/* init chain */
	memset(chain, 0, sizeof(*chain));
	memset(chain->addr, 0, chain->size);
	chain->addr = addr;
	chain->size = a_chain_size;
	chain->p_cons_elem = chain->addr;
	chain->p_prod_elem = chain->addr;
	chain->elem_size = elem_size;
	chain->n_elems = chain->size / elem_size;

	return 0;
}

void qelr_chain_free(struct qelr_chain *chain)
{
	if (chain->size) {
		ibv_dofork_range(chain->addr, chain->size);
		munmap(chain->addr, chain->size);
	}
}
