#ifndef __QELR_H__
#define __QELR_H__

#include <inttypes.h>
#include <stddef.h>
#include <endian.h>

#include <infiniband/driver.h>
#include <infiniband/arch.h>

#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t
#define u64 uint64_t
#define dma_addr_t uint64_t
#define cpu_to_le32 htole32
#define cpu_to_le16 htole16

#define writel(b, p) (*(uint32_t *)(p) = (b))
#define writeq(b, p) (*(uint64_t *)(p) = (b))

#include "qelr_hsi.h"

#define qelr_err(format, arg...) printf(format, ##arg)

extern uint32_t qelr_dp_level;
extern uint32_t qelr_dp_module;


#define min_t(type, x, y) ({		\
	type __max1 = (x);		\
	type __max2 = (y);		\
	__max1 < __max2 ? __max1: __max2; })

#define max_t(type, x, y) ({		\
	type __max1 = (x);		\
	type __max2 = (y);		\
	__max1 > __max2 ? __max1: __max2; })

enum DP_MODULE {
	QELR_MSG_CQ		= 0x10000,
	QELR_MSG_RQ		= 0x20000,
	QELR_MSG_SQ		= 0x40000,
	QELR_MSG_QP		= (QELR_MSG_SQ | QELR_MSG_RQ),
	QELR_MSG_MR		= 0x80000,
	QELR_MSG_INIT		= 0x100000,
	QELR_MSG_SRQ		= 0x200000,
	/* to be added...up to 0x8000000 */
};

enum DP_LEVEL {
	QELR_LEVEL_VERBOSE	= 0x0,
	QELR_LEVEL_INFO		= 0x1,
	QELR_LEVEL_NOTICE	= 0x2,
	QELR_LEVEL_ERR		= 0x3,
};

/* End of removal... */

#define DP_ERR(fd, fmt, ...)					\
do {								\
	fprintf(fd, "[%s:%d]" fmt,				\
		  __func__, __LINE__, 				\
		  ##__VA_ARGS__);				\
	fflush(fd); \
} while (0)

#define DP_NOTICE(fd, fmt, ...)					\
do {								\
	if (qelr_dp_level <= QELR_LEVEL_NOTICE)	{\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__, 			\
		      ##__VA_ARGS__);				\
		      fflush(fd); }\
} while (0)

#define DP_INFO(fd, fmt, ...)					\
do {								\
	if (qelr_dp_level <= QELR_LEVEL_INFO)	{	\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__, 			\
		      ##__VA_ARGS__); fflush(fd);}				\
} while (0)

#define DP_VERBOSE(fd, module, fmt, ...)			\
do {								\
	if ((qelr_dp_level <= QELR_LEVEL_VERBOSE) &&	\
		     (qelr_dp_module & (module))) {		\
		fprintf(fd, "[%s:%d]" fmt,			\
		      __func__, __LINE__, 			\
		      ##__VA_ARGS__);	fflush(fd); }			\
} while (0)


#define ROUND_UP_X(_val, _x) \
    (((unsigned long)(_val) + ((_x)-1)) & (long)~((_x)-1))

#define QED_U32_MAX		((u32) ~0U)

struct qelr_buf {
	void		*addr;
	size_t		len;		/* a 64 uint is used as s preparation
					 * for double layer pbl.
					 */
};

struct qelr_chain {
	/* Address of first page of the chain */
	void		*addr;

	/* Point to next element to produce/consume */
	void		*p_prod_elem;
	void		*p_cons_elem;

	u32		prod_idx;
	u32		cons_idx;

	u32		n_elems;
	u32		size;
	u16		elem_size;
};

/* fast path functions are inline */

static inline u32 qelr_chain_get_cons_idx_u32(struct qelr_chain *p_chain)
{
	return p_chain->cons_idx;
}

static inline void *qelr_chain_produce(struct qelr_chain *p_chain)
{
	void *p_ret = NULL;

	p_chain->prod_idx++;

	p_ret = p_chain->p_prod_elem;

	if (p_chain->prod_idx % p_chain->n_elems == 0)
		p_chain->p_prod_elem = p_chain->addr;
	else
		p_chain->p_prod_elem = (void *)(((u8 *)p_chain->p_prod_elem) +
				       p_chain->elem_size);

	return p_ret;
}

static inline void *qelr_chain_produce_n(struct qelr_chain *p_chain, int n)
{
	void *p_ret = NULL;
	int n_wrap;

	p_chain->prod_idx++;
	p_ret = p_chain->p_prod_elem;

	n_wrap = p_chain->prod_idx % p_chain->n_elems;
	if (n_wrap < n)
		p_chain->p_prod_elem = (void *)(((u8 *)p_chain->addr) +
				       ( p_chain->elem_size * n_wrap ));
	else
		p_chain->p_prod_elem = (void *)(((u8 *)p_chain->p_prod_elem) +
				       ( p_chain->elem_size * n ));

	return p_ret;
}

static inline void *qelr_chain_consume(struct qelr_chain *p_chain)
{
	void *p_ret = NULL;

	p_chain->cons_idx++;

	p_ret = p_chain->p_cons_elem;

	if (p_chain->cons_idx % p_chain->n_elems == 0)
		p_chain->p_cons_elem = p_chain->addr;
	else
		p_chain->p_cons_elem	= (void *)(((u8 *)p_chain->p_cons_elem) +
					   p_chain->elem_size);

	return p_ret;
}

static inline void *qelr_chain_consume_n(struct qelr_chain *p_chain, int n)
{
	void *p_ret = NULL;
	int n_wrap;

	p_chain->cons_idx += n;
	p_ret = p_chain->p_cons_elem;

	n_wrap = p_chain->cons_idx % p_chain->n_elems;
	if (n_wrap < n)
		p_chain->p_cons_elem = (void *)(((u8 *)p_chain->addr) +
				       ( p_chain->elem_size * n_wrap ));
	else
		p_chain->p_cons_elem = (void *)(((u8 *)p_chain->p_cons_elem) +
				       ( p_chain->elem_size * n ));

	return p_ret;
}

static inline u32 qelr_chain_get_elem_left_u32(struct qelr_chain *p_chain)
{
	u32 used;

	used = (u32)(((u64)QED_U32_MAX + 1 +
		      (u64)(p_chain->prod_idx)) -
		     (u64)p_chain->cons_idx);

	return p_chain->n_elems - used;
}

static inline u8 qelr_chain_is_full(struct qelr_chain *p_chain)
{
	return qelr_chain_get_elem_left_u32(p_chain) == p_chain->n_elems;
}

static inline void qelr_chain_set_prod(
		struct qelr_chain *p_chain,
		u32 prod_idx,
		void *p_prod_elem)
{
	p_chain->prod_idx = prod_idx;
	p_chain->p_prod_elem = p_prod_elem;
}

struct qelr_device {
	struct ibv_device ibv_dev;
};

struct qelr_devctx {
	struct ibv_context	ibv_ctx;
	FILE			*dbg_fp;
	void			*db_addr;
	uint64_t		db_pa;
	uint32_t		db_size;
	uint8_t			disable_edpm;
	uint32_t		kernel_page_size;

	uint32_t		max_send_wr;
	uint32_t		max_recv_wr;
	uint32_t		max_srq_wr;
	uint32_t		sges_per_send_wr;
	uint32_t		sges_per_recv_wr;
	uint32_t		sges_per_srq_wr;
	int			max_cqes;
};

struct qelr_pd {
	struct ibv_pd 		ibv_pd;
	uint32_t 		pd_id;
};

struct qelr_mr {
	struct ibv_mr 		ibv_mr;
};

union db_prod64 {
	struct rdma_pwm_val32_data data;
	uint64_t raw;
};

struct qelr_cq {
	struct ibv_cq		ibv_cq;	/* must be first */

	struct qelr_chain	chain;

	void			*db_addr;
	union db_prod64		db;

	uint8_t			chain_toggle;
	union rdma_cqe		*latest_cqe;
	union rdma_cqe		*toggle_cqe;

	u8			arm_flags;
};

enum qelr_qp_state {
	QELR_QPS_RST		= 0,
	QELR_QPS_INIT		= 1,
	QELR_QPS_RTR		= 2,
	QELR_QPS_RTS		= 3,
	QELR_QPS_SQE		= 4,
	QELR_QPS_SQ_DRAINING	= 5,
	QELR_QPS_ERR		= 6,
	QELR_QPS_SQD		= 7
};

union db_prod32 {
	struct rdma_pwm_val16_data	data;
	uint32_t			raw;
};
struct qelr_qp_hwq_info {
	/* WQE */
	struct qelr_chain			chain;
	uint8_t					max_sges;

	/* WQ */
	//uint16_t				wqe_prod;
	uint16_t				prod;     /* WQE prod index for SW ring */
	uint16_t				wqe_cons;
	uint16_t				cons;     /* WQE cons index for SW ring */
	uint16_t				max_wr; /* cons and prod wrap when they reach it  */

	/* DB */
	void					*db;      /* Doorbell address */
	void					*edpm_db; /* Doorbell address for EDPM*/
	union db_prod32				db_data;  /* Doorbell data */

	uint16_t				icid;
};

struct qelr_rdma_ext {
	uint64_t remote_va;
	uint32_t remote_key;
	uint32_t dma_length;
};

/* rdma extension, invalidate / immediate data + padding, inline data... */
#define QELR_MAX_DPM_PAYLOAD (sizeof(struct qelr_rdma_ext) + sizeof(uint64_t) + ROCE_REQ_MAX_INLINE_DATA_SIZE)
struct qelr_edpm {
	union {
		struct db_roce_dpm_data	data;
		uint64_t raw;
	} msg;
	
	uint8_t 		dpm_payload[QELR_MAX_DPM_PAYLOAD];
	uint32_t 		dpm_payload_size;
	uint32_t 		dpm_payload_offset;
	uint8_t			is_edpm;
	struct qelr_rdma_ext    *rdma_ext;
};

struct qelr_srq_hwq_info {
	u32 max_sges;
	u32 max_wr;
	struct qelr_chain chain;
	u32 wqe_prod;     /* WQE prod index in HW ring */
	u32 sge_prod;     /* SGE prod index in HW ring */
	u32 wr_prod_cnt; /* wr producer count */
	u32 wr_cons_cnt; /* wr consumer count */
	u32 num_elems;

	u32 *virt_prod_pair_addr; /* producer pair virtual address */
	u64 phy_prod_pair_addr; /* producer pair physical address */
};

struct qelr_srq {
	struct ibv_srq ibv_srq;
	struct qelr_srq_hwq_info hw_srq;
	u16 srq_id;
	pthread_spinlock_t lock;
};

struct qelr_qp {
	struct ibv_qp 				ibv_qp;
	pthread_spinlock_t			q_lock;
	enum qelr_qp_state			state;   /*  QP state */

	struct qelr_qp_hwq_info			sq;
	struct qelr_qp_hwq_info			rq;
	struct qelr_srq				*srq;
	struct {
		uint64_t wr_id;
		enum ibv_wc_opcode opcode;
		uint32_t bytes_len;
		uint8_t wqe_size;
		uint8_t signaled;
	} *wqe_wr_id;


	struct {
		uint64_t wr_id;
		uint8_t wqe_size;
	} *rqe_wr_id;

	struct qelr_edpm			edpm;
	uint8_t					prev_wqe_size;
	uint32_t				max_inline_data;
	uint32_t				qp_id;
	int					sq_sig_all;
	int					atomic_supported;

};


#define get_qelr_xxx(xxx, type)				\
	((struct qelr_##type *)					\
	((void *) ib##xxx - offsetof(struct qelr_##type, ibv_##xxx)))

static inline struct qelr_devctx *get_qelr_ctx(struct ibv_context *ibctx)
{
	return get_qelr_xxx(ctx, devctx);
}

static inline struct qelr_device *get_qelr_dev(struct ibv_device *ibdev)
{
	return get_qelr_xxx(dev, device);
}

static inline struct qelr_qp *get_qelr_qp(struct ibv_qp *ibqp)
{
	return get_qelr_xxx(qp, qp);
}

static inline struct qelr_srq *get_qelr_srq(struct ibv_srq *ibsrq)
{
	return get_qelr_xxx(srq, srq);
}

static inline struct qelr_pd *get_qelr_pd(struct ibv_pd *ibpd)
{
	return get_qelr_xxx(pd, pd);
}

static inline struct qelr_cq *get_qelr_cq(struct ibv_cq *ibcq)
{
	return get_qelr_xxx(cq, cq);
}

#define SET_FIELD(value, name, flag)			       \
	do {						       \
		(value) &= ~(name ## _MASK << name ## _SHIFT); \
		(value) |= ((flag) << (name ## _SHIFT));       \
	} while (0)

#define SET_FIELD2(value, name, flag)			       \
	do {						       \
		(value) |= ((flag) << (name ## _SHIFT));       \
	} while (0)

#define GET_FIELD(value, name) \
	(((value) >> (name ## _SHIFT)) & name ## _MASK)

#define ROCE_WQE_ELEM_SIZE	sizeof(struct rdma_sq_sge)


#define QELR_RESP_IMM (RDMA_CQE_RESPONDER_IMM_FLG_MASK << RDMA_CQE_RESPONDER_IMM_FLG_SHIFT)
#define QELR_RESP_RDMA (RDMA_CQE_RESPONDER_RDMA_FLG_MASK << RDMA_CQE_RESPONDER_RDMA_FLG_SHIFT)
#define QELR_RESP_RDMA_IMM (QELR_RESP_IMM | QELR_RESP_RDMA)

#define round_up(_val, _x) \
    (((unsigned long)(_val) + ((_x)-1)) & (long)~((_x)-1))

#define TYPEPTR_ADDR_SET(type_ptr, field, vaddr)				\
	do {								\
		(type_ptr)->field.hi = cpu_to_le32(U64_HI(vaddr));	\
		(type_ptr)->field.lo = cpu_to_le32(U64_LO(vaddr));	\
	} while (0)


#define RQ_SGE_SET(sge, vaddr, vlength, vflags)			\
	do {							\
		TYPEPTR_ADDR_SET(sge, addr, vaddr);		\
		(sge)->length = cpu_to_le32(vlength);		\
		(sge)->flags = cpu_to_le32(vflags);		\
	} while (0)

#define SRQ_HDR_SET(hdr, vwr_id, num_sge)			\
	do {							\
		TYPEPTR_ADDR_SET(hdr, wr_id, vwr_id);		\
		(hdr)->num_sges = num_sge;			\
	} while (0)

#define SRQ_SGE_SET(sge, vaddr, vlength, vlkey)			\
	do {							\
		TYPEPTR_ADDR_SET(sge, addr, vaddr);		\
		(sge)->length = cpu_to_le32(vlength);		\
		(sge)->l_key = cpu_to_le32(vlkey);		\
	} while (0)

#define U64_HI(val) ((uint32_t)(((uint64_t)(val)) >> 32))
#define U64_LO(val) ((uint32_t)(((uint64_t)(val)) & 0xffffffff))
#define HILO_U64(hi, lo)		((((uint64_t)(hi)) << 32) + (lo))


#define QELR_MAX_RQ_WQE_SIZE (RDMA_MAX_SGE_PER_RQ_WQE)
#define QELR_MAX_SQ_WQE_SIZE (ROCE_REQ_MAX_SINGLE_SQ_WQE_SIZE / ROCE_WQE_ELEM_SIZE)

#endif /* __QELR_H__ */
