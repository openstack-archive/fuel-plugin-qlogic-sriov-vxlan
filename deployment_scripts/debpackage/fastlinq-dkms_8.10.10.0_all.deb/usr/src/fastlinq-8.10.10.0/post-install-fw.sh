FL_VERSION=8.10.10.0
FW_VERSION=8.10.9.0

mkdir -p /lib/firmware/qed
cp /usr/src/fastlinq-${FL_VERSION}/qed-${FL_VERSION}/src/qed_init_values_zipped-${FW_VERSION}.bin /lib/firmware/qed
