#ifndef _QED_PTP_IF_H
#define _QED_PTP_IF_H
#include <linux/types.h>
/**
 * @file
 *
 * @brief QED_PTP
 *
 */
#ifdef CONFIG_QED_PTP
#include "qed_ptp.h"
#else
struct qed_hwfn;
static inline int qed_ptp_enable_pkt2host(struct qed_hwfn *hwfn)
{return -EPERM;}
static inline int qed_ptp_hwtstamp_tx_on(struct qed_hwfn *hwfn)
{return -EPERM;}
static inline int qed_ptp_cfg_rx_filters(struct qed_hwfn *hwfn, u32 rule_mask,
					 u32 param_mask)
{return -EPERM;}
static inline u64 qed_ptp_read_rx_ts(struct qed_hwfn *hwfn, int *valid)
{return -EPERM;}
static inline u64 qed_ptp_read_tx_ts(struct qed_hwfn *hwfn, int *valid)
{return -EPERM;}
static inline u64 qed_ptp_read_cc(struct qed_hwfn *hwfn, int *valid)
{return -EPERM;}
static inline int qed_ptp_disable(struct qed_hwfn *hwfn)
{return -EPERM;}
static inline int qed_ptp_adjfreq(struct qed_hwfn *hwfn, u32 cfg)
{return -EPERM;}
static inline int qed_ptp_enable(struct qed_hwfn *hwfn)
{return -EPERM;}
#endif /* End CONFIG_QED_PTP */

#endif /* End  _QED_PTP_IF_H */
