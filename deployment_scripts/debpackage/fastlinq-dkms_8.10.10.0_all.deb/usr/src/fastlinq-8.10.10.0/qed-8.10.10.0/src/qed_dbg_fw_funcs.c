#include <linux/types.h>
#include <linux/bitops.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/pci.h>
#include <linux/slab.h>
#include <linux/string.h>
#define __PREVENT_PXP_GLOBAL_WIN__
#include "qed.h"
#include "qed_hsi.h"
#include "qed_hw.h"
#include "qed_mcp.h"
#include "qed_reg_addr.h"
/* Chip IDs enum */
enum chip_ids {
	CHIP_BB_A0,
	CHIP_BB_B0,
	CHIP_K2,
	MAX_CHIP_IDS
};
/* Memory groups enum */
enum mem_groups {
	MEM_GROUP_PXP_MEM,
	MEM_GROUP_DMAE_MEM,
	MEM_GROUP_CM_MEM,
	MEM_GROUP_QM_MEM,
	MEM_GROUP_TM_MEM,
	MEM_GROUP_BRB_RAM,
	MEM_GROUP_BRB_MEM,
	MEM_GROUP_PRS_MEM,
	MEM_GROUP_SDM_MEM,
	MEM_GROUP_PBUF,
	MEM_GROUP_IOR,
	MEM_GROUP_RAM,
	MEM_GROUP_BTB_RAM,
	MEM_GROUP_RDIF_CTX,
	MEM_GROUP_TDIF_CTX,
	MEM_GROUP_CONN_CFC_MEM,
	MEM_GROUP_TASK_CFC_MEM,
	MEM_GROUP_CAU_PI,
	MEM_GROUP_CAU_MEM,
	MEM_GROUP_PXP_ILT,
	MEM_GROUP_MULD_MEM,
	MEM_GROUP_BTB_MEM,
	MEM_GROUP_IGU_MEM,
	MEM_GROUP_IGU_MSIX,
	MEM_GROUP_CAU_SB,
	MEM_GROUP_BMB_RAM,
	MEM_GROUP_BMB_MEM,
	MEM_GROUPS_NUM
};
/* Memory groups names */
static const char *s_mem_group_names[] = {
	"PXP_MEM",
	"DMAE_MEM",
	"CM_MEM",
	"QM_MEM",
	"TM_MEM",
	"BRB_RAM",
	"BRB_MEM",
	"PRS_MEM",
	"SDM_MEM",
	"PBUF",
	"IOR",
	"RAM",
	"BTB_RAM",
	"RDIF_CTX",
	"TDIF_CTX",
	"CONN_CFC_MEM",
	"TASK_CFC_MEM",
	"CAU_PI",
	"CAU_MEM",
	"PXP_ILT",
	"MULD_MEM",
	"BTB_MEM",
	"IGU_MEM",
	"IGU_MSIX",
	"CAU_SB",
	"BMB_RAM",
	"BMB_MEM",
};

/* Idle check conditions */
#ifndef __PREVENT_COND_ARR__
static u32 cond4(const u32 * r, const u32 * imm)
{
	return ((r[0] & imm[0]) != imm[1]) && ((r[1] & imm[2]) != imm[3]);
}

static u32 cond6(const u32 * r, const u32 * imm)
{
	return ((r[0] >> imm[0]) & imm[1]) != imm[2];
}

static u32 cond5(const u32 * r, const u32 * imm)
{
	return (r[0] & imm[0]) != imm[1];
}

static u32 cond8(const u32 * r, const u32 * imm)
{
	return ((r[0] & imm[0]) >> imm[1]) !=
	    (((r[0] & imm[2]) >> imm[3]) | ((r[1] & imm[4]) << imm[5]));
}

static u32 cond9(const u32 * r, const u32 * imm)
{
	return ((r[0] & imm[0]) >> imm[1]) != (r[0] & imm[2]);
}

static u32 cond1(const u32 * r, const u32 * imm)
{
	return (r[0] & ~imm[0]) != imm[1];
}

static u32 cond0(const u32 * r, const u32 * imm)
{
	return r[0] != imm[0];
}

static u32 cond10(const u32 * r, const u32 * imm)
{
	return r[0] != r[1] && r[2] == imm[0];
}

static u32 cond11(const u32 * r, const u32 * imm)
{
	return r[0] != r[1] && r[2] > imm[0];
}

static u32 cond3(const u32 * r, const u32 * imm)
{
	return r[0] != r[1];
}

static u32 cond12(const u32 * r, const u32 * imm)
{
	return r[0] & imm[0];
}

static u32 cond7(const u32 * r, const u32 * imm)
{
	return r[0] < (r[1] - imm[0]);
}

static u32 cond2(const u32 * r, const u32 * imm)
{
	return r[0] > imm[0];
}

/* Array of Idle Check conditions */
static u32(*cond_arr[]) (const u32 * r, const u32 * imm) = {
cond0,
	    cond1,
	    cond2,
	    cond3,
	    cond4, cond5, cond6, cond7, cond8, cond9, cond10, cond11, cond12,};
#endif /* __PREVENT_COND_ARR__ */
/******************************* Data Types **********************************/
enum platform_ids {
	PLATFORM_ASIC,
	PLATFORM_EMUL_FULL,
	PLATFORM_EMUL_REDUCED,
	PLATFORM_FPGA,
	MAX_PLATFORM_IDS
};
struct dbg_array {
	const u32 *ptr;
	u32 size_in_dwords;
};
/* Chip constant definitions */
struct chip_defs {
	const char *name;
	struct {
		u8 num_ports;
		u8 num_pfs;
	} per_platform[MAX_PLATFORM_IDS];
};
/* platform constant definitions */
struct platform_defs {
	const char *name;
	u32 delay_factor;
};
/* Storm constant definitions */
struct storm_defs {
	char letter;
	enum block_id block_id;
	enum dbg_bus_clients dbg_client_id[MAX_CHIP_IDS];
	bool has_vfc;
	u32 sem_fast_mem_addr;
	u32 sem_frame_mode_addr;
	u32 sem_slow_enable_addr;
	u32 sem_slow_mode_addr;
	u32 sem_slow_mode1_conf_addr;
	u32 sem_sync_dbg_empty_addr;
	u32 sem_slow_dbg_empty_addr;
	u32 cm_ctx_wr_addr;
	u32 cm_conn_ag_ctx_lid_size;	/* in quad-regs */
	u32 cm_conn_ag_ctx_rd_addr;
	u32 cm_conn_st_ctx_lid_size;	/* in quad-regs */
	u32 cm_conn_st_ctx_rd_addr;
	u32 cm_task_ag_ctx_lid_size;	/* in quad-regs */
	u32 cm_task_ag_ctx_rd_addr;
	u32 cm_task_st_ctx_lid_size;	/* in quad-regs */
	u32 cm_task_st_ctx_rd_addr;
};
/* Block constant definitions */
struct block_defs {
	const char *name;
	bool has_dbg_bus[MAX_CHIP_IDS];
	bool associated_to_storm;
	u32 storm_id;		/* valid only if associated_to_storm is true */
	enum dbg_bus_clients dbg_client_id[MAX_CHIP_IDS];
	u32 dbg_select_addr;
	u32 dbg_cycle_enable_addr;
	u32 dbg_shift_addr;
	u32 dbg_force_valid_addr;
	u32 dbg_force_frame_addr;
	bool has_reset_bit;
	bool unreset;		/* if true, the block is taken out of reset before dump */
	enum dbg_reset_regs reset_reg;
	u8 reset_bit_offset;	/* bit offset in reset register */
};
/* Reset register definitions */
struct reset_reg_defs {
	u32 addr;
	u32 unreset_val;
	bool exists[MAX_CHIP_IDS];
};
/* Debug Bus Constraint operation constant definitions */
struct dbg_bus_constraint_op_defs {
	u8 hw_op_val;
	bool is_cyclic;
};
/* Storm Mode definitions */
struct storm_mode_defs {
	const char *name;
	bool is_fast_dbg;
	u8 id_in_hw;
};
struct grc_param_defs {
	u32 default_val[MAX_CHIP_IDS];
	u32 min;
	u32 max;
	bool is_preset;
	u32 exclude_all_preset_val;
	u32 crash_preset_val;
};
struct rss_mem_defs {
	const char *mem_name;
	const char *type_name;
	u32 addr;		/* in 128b units */
	u32 num_entries[MAX_CHIP_IDS];
	u32 entry_width[MAX_CHIP_IDS];	/* in bits */
};
struct vfc_ram_defs {
	const char *mem_name;
	const char *type_name;
	u32 base_row;
	u32 num_rows;
};
struct big_ram_defs {
	const char *instance_name;
	enum mem_groups mem_group_id;
	enum mem_groups ram_mem_group_id;
	enum dbg_grc_params grc_param;
	u32 addr_reg_addr;
	u32 data_reg_addr;
	u32 num_of_blocks[MAX_CHIP_IDS];
};
struct phy_defs {
	const char *phy_name;
	u32 base_addr;		/* PHY base GRC address */
	u32 tbus_addr_lo_addr;	/* relative GRC address of indirect TBUS address (bits 0..7) register */
	u32 tbus_addr_hi_addr;	/* relative GRC address of indirect TBUS address (bits 8..10) register */
	u32 tbus_data_lo_addr;	/* relative GRC address of indirect TBUS data (bits 0..7) register */
	u32 tbus_data_hi_addr;	/* relative GRC address of indirect TBUS data (bits 8..11) register */
};
/******************************** Constants **********************************/
#define MAX_LCIDS                                       320
#define MAX_LTIDS                                       320
#define NUM_IOR_SETS                            2
#define IORS_PER_SET                            176
#define IOR_SET_OFFSET(set_id)          ((set_id) * 256)
#define BYTES_IN_DWORD                          4
/* in the macros below, size and offset are specified in bits */
#define CEIL_DWORDS(size)                               DIV_ROUND_UP(size, 32)
#define FIELD_BIT_OFFSET(type, field)   type ## _ ## field ## _ ## OFFSET
#define FIELD_BIT_SIZE(type, field)             type ## _ ## field ## _ ## SIZE
#define FIELD_DWORD_OFFSET(type, \
			   field) (int)(FIELD_BIT_OFFSET(type, field) / 32)
#define FIELD_DWORD_SHIFT(type, field)  (FIELD_BIT_OFFSET(type, field) % 32)
#define FIELD_BIT_MASK(type,					      \
		       field)             (((1 <<		      \
					     FIELD_BIT_SIZE(type,     \
							    field)) - \
					    1) << FIELD_DWORD_SHIFT(type, field))
#define SET_VAR_FIELD(var, type, field,					   \
		      val)    var[FIELD_DWORD_OFFSET(type,		   \
						     field)] &=		   \
	(~FIELD_BIT_MASK(type, field));					   \
	var[FIELD_DWORD_OFFSET(type,					   \
			       field)] |= (val) << FIELD_DWORD_SHIFT(type, \
								     field)
#define ARR_REG_WR(dev, ptt, addr, arr, arr_size)       for (i = 0;		\
							     i < (arr_size);	\
							     i++) qed_wr(dev,	\
									 ptt,	\
									 addr,	\
									 (arr)[	\
										 i])
#define ARR_REG_RD(dev, ptt, addr, arr, arr_size)       for (i = 0;	     \
							     i < (arr_size); \
							     i++) (arr)[i] = \
			qed_rd(dev, ptt, addr)

#define DWORDS_TO_BYTES(dwords)         ((dwords) * BYTES_IN_DWORD)
#define BYTES_TO_DWORDS(bytes)          ((bytes) / BYTES_IN_DWORD)
#define RAM_LINES_TO_DWORDS(lines)      ((lines) * 2)
#define RAM_LINES_TO_BYTES(lines)       DWORDS_TO_BYTES(RAM_LINES_TO_DWORDS( \
								lines))
#define REG_DUMP_LEN_SHIFT                      24
#define MEM_DUMP_ENTRY_SIZE_DWORDS      BYTES_TO_DWORDS(sizeof(struct \
							       dbg_dump_mem))
#define IDLE_CHK_RULE_SIZE_DWORDS               BYTES_TO_DWORDS(sizeof(struct \
								       dbg_idle_chk_rule))
#define IDLE_CHK_RESULT_HDR_DWORDS              BYTES_TO_DWORDS(sizeof(struct \
								       dbg_idle_chk_result_hdr))
#define IDLE_CHK_RESULT_REG_HDR_DWORDS  BYTES_TO_DWORDS(sizeof(struct \
							       dbg_idle_chk_result_reg_hdr))
#define IDLE_CHK_MAX_ENTRIES_SIZE       32
/* the sizes and offsets below are specified in bits */
#define VFC_CAM_CMD_STRUCT_SIZE         64
#define VFC_CAM_CMD_ROW_OFFSET          48
#define VFC_CAM_CMD_ROW_SIZE            9
#define VFC_CAM_ADDR_STRUCT_SIZE        16
#define VFC_CAM_ADDR_OP_OFFSET          0
#define VFC_CAM_ADDR_OP_SIZE            4
#define VFC_CAM_RESP_STRUCT_SIZE        256
#define VFC_RAM_ADDR_STRUCT_SIZE        16
#define VFC_RAM_ADDR_OP_OFFSET          0
#define VFC_RAM_ADDR_OP_SIZE            2
#define VFC_RAM_ADDR_ROW_OFFSET         2
#define VFC_RAM_ADDR_ROW_SIZE           10
#define VFC_RAM_RESP_STRUCT_SIZE        256
#define VFC_CAM_CMD_DWORDS                      CEIL_DWORDS( \
		VFC_CAM_CMD_STRUCT_SIZE)
#define VFC_CAM_ADDR_DWORDS                     CEIL_DWORDS( \
		VFC_CAM_ADDR_STRUCT_SIZE)
#define VFC_CAM_RESP_DWORDS                     CEIL_DWORDS( \
		VFC_CAM_RESP_STRUCT_SIZE)
#define VFC_RAM_CMD_DWORDS                      VFC_CAM_CMD_DWORDS
#define VFC_RAM_ADDR_DWORDS                     CEIL_DWORDS( \
		VFC_RAM_ADDR_STRUCT_SIZE)
#define VFC_RAM_RESP_DWORDS                     CEIL_DWORDS( \
		VFC_RAM_RESP_STRUCT_SIZE)
#define NUM_VFC_RAM_TYPES                       4
#define VFC_CAM_NUM_ROWS                        512
#define VFC_OPCODE_CAM_RD                       14
#define VFC_OPCODE_RAM_RD                       0
#define NUM_RSS_MEM_TYPES                       5
#define NUM_BIG_RAM_TYPES                       3
#define BIG_RAM_BLOCK_SIZE_BYTES        128
#define BIG_RAM_BLOCK_SIZE_DWORDS       BYTES_TO_DWORDS( \
		BIG_RAM_BLOCK_SIZE_BYTES)
#define NUM_PHY_TBUS_ADDRESSES          2048
#define PHY_DUMP_SIZE_DWORDS            (NUM_PHY_TBUS_ADDRESSES / 2)
#define SEM_FAST_MODE6_SRC_ENABLE       0x10
#define SEM_FAST_MODE6_SRC_DISABLE      0x3f
#define SEM_SLOW_MODE1_DATA_ENABLE      0x1
#define UNITS_PER_CYCLE                         4
#define MAX_CYCLE_UNITS_MASK            (BIT(UNITS_PER_CYCLE) - 1)
#define MAX_DWORDS_PER_CYCLE            8
#define HW_ID_BITS                                      3
#define NUM_HW_IDS                                      BIT(HW_ID_BITS)
#define NUM_CALENDAR_SLOTS                      16
#define FINAL_TRIGGER_STATE                     3
#define TRIGGER_SETS_PER_STATE          2
#define MAX_CONSTRAINTS                         4
#define SEM_FILTER_CID_EN_MASK                  0x008
#define SEM_FILTER_EID_MASK_EN_MASK             0x010
#define SEM_FILTER_EID_RANGE_EN_MASK    0x110
#define CHUNK_SIZE_IN_DWORDS            64
#define CHUNK_SIZE_IN_BYTES                     DWORDS_TO_BYTES( \
		CHUNK_SIZE_IN_DWORDS)
#define INT_BUF_NUM_OF_LINES            192
#define INT_BUF_LINE_SIZE_IN_DWORDS     16
#define INT_BUF_SIZE_IN_DWORDS          (INT_BUF_NUM_OF_LINES *	\
					 INT_BUF_LINE_SIZE_IN_DWORDS)
#define INT_BUF_SIZE_IN_CHUNKS          (INT_BUF_SIZE_IN_DWORDS / \
					 CHUNK_SIZE_IN_DWORDS)
#define PCI_BUF_LINE_SIZE_IN_DWORDS     8
#define PCI_BUF_LINE_SIZE_IN_BYTES      DWORDS_TO_BYTES( \
		PCI_BUF_LINE_SIZE_IN_DWORDS)
#define TARGET_EN_MASK_PCI                      0x3
#define TARGET_EN_MASK_NIG                      0x4
#define PCI_REQ_CREDIT                          1
#define PCI_PHYS_ADDR_TYPE                      0
#define OPAQUE_FID(pci_func)            ((pci_func << 4) | 0xff00)
#define RESET_REG_UNRESET_OFFSET        4
#define PCI_PKT_SIZE_IN_CHUNKS          1
#define PCI_PKT_SIZE_IN_BYTES           (PCI_PKT_SIZE_IN_CHUNKS * \
					 CHUNK_SIZE_IN_BYTES)
#define NIG_PKT_SIZE_IN_CHUNKS          4
#define FLUSH_DELAY_MS                          500
#define STALL_DELAY_MS                          500
#define SRC_MAC_ADDR_LO16                       0x0a0b
#define SRC_MAC_ADDR_HI32                       0x0c0d0e0f
#define ETH_TYPE                                        0x1000
#define STATIC_DEBUG_LINE_DWORDS        9
#define NUM_DBG_BUS_LINES                       256
#define NUM_COMMON_GLOBAL_PARAMS        8
#define FW_IMG_KUKU                                     0
#define FW_IMG_MAIN                                     1
#define FW_IMG_L2B                                      2
#define REG_FIFO_DEPTH_ELEMENTS         32
#define REG_FIFO_ELEMENT_DWORDS         2
#define REG_FIFO_DEPTH_DWORDS           (REG_FIFO_ELEMENT_DWORDS * \
					 REG_FIFO_DEPTH_ELEMENTS)
#define IGU_FIFO_DEPTH_ELEMENTS         64
#define IGU_FIFO_ELEMENT_DWORDS         4
#define IGU_FIFO_DEPTH_DWORDS           (IGU_FIFO_ELEMENT_DWORDS * \
					 IGU_FIFO_DEPTH_ELEMENTS)
#define SEMI_SYNC_FIFO_POLLING_DELAY_MS         5
#define SEMI_SYNC_FIFO_POLLING_COUNT            20
#define PROTECTION_OVERRIDE_DEPTH_ELEMENTS      20
#define PROTECTION_OVERRIDE_ELEMENT_DWORDS      2
#define PROTECTION_OVERRIDE_DEPTH_DWORDS        (    \
		PROTECTION_OVERRIDE_DEPTH_ELEMENTS * \
		PROTECTION_OVERRIDE_ELEMENT_DWORDS)
#define MCP_SPAD_TRACE_OFFSIZE_ADDR                     (MCP_REG_SCRATCH +     \
							 offsetof(struct       \
								  static_init, \
								  sections[    \
									  SPAD_SECTION_TRACE]))
#define MCP_TRACE_META_IMAGE_SIGNATURE          0x669955aa
#define EMPTY_FW_VERSION_STR                            "???_???_???_???"
#define EMPTY_FW_IMAGE_STR \
	"???????????????"
/***************************** Constant Arrays *******************************/
/* debug arrays */
static struct dbg_array s_dbg_arrays[MAX_BIN_DBG_BUFFER_TYPE] = { {0} };

/* Chip constant definitions array */
static struct chip_defs s_chip_defs[MAX_CHIP_IDS] = {
	/* BB A0 */ {"bb_a0",
		     /* ASIC */
		     {{
		       MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* EMUL_FULL */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* EMUL_REDUCED */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* FPGA */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB}}},
	/* BB B0 */ {"bb_b0",
		     /* ASIC */
		     {{MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* EMUL_FULL */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* EMUL_REDUCED */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB},
		      /* FPGA */
		      {MAX_NUM_PORTS_BB,
		       MAX_NUM_PFS_BB}}},
	/* K2 */ {"k2",
		  /* ASIC */
		  {{MAX_NUM_PORTS_K2,
		    MAX_NUM_PFS_K2},
		   /* EMUL_FULL */
		   {MAX_NUM_PORTS_K2,
		    MAX_NUM_PFS_K2},
		   /* EMUL_REDUCED */
		   {MAX_NUM_PORTS_K2,
		    MAX_NUM_PFS_K2},
		   /* FPGA */
		   {MAX_NUM_PORTS_K2, 8}}}
};

/* Storm constant definitions array */
static struct storm_defs s_storm_defs[] = {
	/* Tstorm */
	{'T', BLOCK_TSEM,
	 {DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT,
	  DBG_BUS_CLIENT_RBCT}, true,
	 TSEM_REG_FAST_MEMORY,
	 TSEM_REG_DBG_FRAME_MODE, TSEM_REG_SLOW_DBG_ACTIVE,
	 TSEM_REG_SLOW_DBG_MODE, TSEM_REG_DBG_MODE1_CFG,
	 TSEM_REG_SYNC_DBG_EMPTY, TSEM_REG_SLOW_DBG_EMPTY,
	 TCM_REG_CTX_RBC_ACCS,
	 4, TCM_REG_AGG_CON_CTX,
	 16, TCM_REG_SM_CON_CTX,
	 2, TCM_REG_AGG_TASK_CTX,
	 4, TCM_REG_SM_TASK_CTX},
	/* Mstorm */
	{'M', BLOCK_MSEM,
	 {DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT,
	  DBG_BUS_CLIENT_RBCM}, false,
	 MSEM_REG_FAST_MEMORY,
	 MSEM_REG_DBG_FRAME_MODE, MSEM_REG_SLOW_DBG_ACTIVE,
	 MSEM_REG_SLOW_DBG_MODE, MSEM_REG_DBG_MODE1_CFG,
	 MSEM_REG_SYNC_DBG_EMPTY, MSEM_REG_SLOW_DBG_EMPTY,
	 MCM_REG_CTX_RBC_ACCS,
	 1, MCM_REG_AGG_CON_CTX,
	 10, MCM_REG_SM_CON_CTX,
	 2, MCM_REG_AGG_TASK_CTX,
	 7, MCM_REG_SM_TASK_CTX},
	/* Ustorm */
	{'U', BLOCK_USEM,
	 {DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU,
	  DBG_BUS_CLIENT_RBCU}, false,
	 USEM_REG_FAST_MEMORY,
	 USEM_REG_DBG_FRAME_MODE, USEM_REG_SLOW_DBG_ACTIVE,
	 USEM_REG_SLOW_DBG_MODE, USEM_REG_DBG_MODE1_CFG,
	 USEM_REG_SYNC_DBG_EMPTY, USEM_REG_SLOW_DBG_EMPTY,
	 UCM_REG_CTX_RBC_ACCS,
	 2, UCM_REG_AGG_CON_CTX,
	 13, UCM_REG_SM_CON_CTX,
	 3, UCM_REG_AGG_TASK_CTX,
	 3, UCM_REG_SM_TASK_CTX},
	/* Xstorm */
	{'X', BLOCK_XSEM,
	 {DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX,
	  DBG_BUS_CLIENT_RBCX}, false,
	 XSEM_REG_FAST_MEMORY,
	 XSEM_REG_DBG_FRAME_MODE, XSEM_REG_SLOW_DBG_ACTIVE,
	 XSEM_REG_SLOW_DBG_MODE, XSEM_REG_DBG_MODE1_CFG,
	 XSEM_REG_SYNC_DBG_EMPTY, XSEM_REG_SLOW_DBG_EMPTY,
	 XCM_REG_CTX_RBC_ACCS,
	 9, XCM_REG_AGG_CON_CTX,
	 15, XCM_REG_SM_CON_CTX,
	 0, 0,
	 0, 0},
	/* Ystorm */
	{'Y', BLOCK_YSEM,
	 {DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX,
	  DBG_BUS_CLIENT_RBCY}, false,
	 YSEM_REG_FAST_MEMORY,
	 YSEM_REG_DBG_FRAME_MODE, YSEM_REG_SLOW_DBG_ACTIVE,
	 YSEM_REG_SLOW_DBG_MODE, YSEM_REG_DBG_MODE1_CFG,
	 YSEM_REG_SYNC_DBG_EMPTY, TSEM_REG_SLOW_DBG_EMPTY,
	 YCM_REG_CTX_RBC_ACCS,
	 2, YCM_REG_AGG_CON_CTX,
	 3, YCM_REG_SM_CON_CTX,
	 2, YCM_REG_AGG_TASK_CTX,
	 12, YCM_REG_SM_TASK_CTX},
	/* Pstorm */
	{'P', BLOCK_PSEM,
	 {DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS,
	  DBG_BUS_CLIENT_RBCS}, true,
	 PSEM_REG_FAST_MEMORY,
	 PSEM_REG_DBG_FRAME_MODE, PSEM_REG_SLOW_DBG_ACTIVE,
	 PSEM_REG_SLOW_DBG_MODE, PSEM_REG_DBG_MODE1_CFG,
	 PSEM_REG_SYNC_DBG_EMPTY, PSEM_REG_SLOW_DBG_EMPTY,
	 PCM_REG_CTX_RBC_ACCS,
	 0, 0,
	 10, PCM_REG_SM_CON_CTX,
	 0, 0,
	 0, 0}
};

/* Block definitions array */
static struct block_defs block_grc_defs = {
	"grc",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCN, DBG_BUS_CLIENT_RBCN, DBG_BUS_CLIENT_RBCN},
	GRC_REG_DBG_SELECT, GRC_REG_DBG_DWORD_ENABLE,
	GRC_REG_DBG_SHIFT, GRC_REG_DBG_FORCE_VALID,
	GRC_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_UA, 1
};

static struct block_defs block_miscs_defs = {
	"miscs", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_misc_defs = {
	"misc", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_dbu_defs = {
	"dbu", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_pglue_b_defs = {
	"pglue_b",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCH, DBG_BUS_CLIENT_RBCH, DBG_BUS_CLIENT_RBCH},
	PGLUE_B_REG_DBG_SELECT, PGLUE_B_REG_DBG_DWORD_ENABLE,
	PGLUE_B_REG_DBG_SHIFT, PGLUE_B_REG_DBG_FORCE_VALID,
	PGLUE_B_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 1
};

static struct block_defs block_cnig_defs = {
	"cnig",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCW},
	CNIG_REG_DBG_SELECT_K2, CNIG_REG_DBG_DWORD_ENABLE_K2,
	CNIG_REG_DBG_SHIFT_K2, CNIG_REG_DBG_FORCE_VALID_K2,
	CNIG_REG_DBG_FORCE_FRAME_K2,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 0
};

static struct block_defs block_cpmu_defs = {
	"cpmu", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 8
};

static struct block_defs block_ncsi_defs = {
	"ncsi",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCZ},
	NCSI_REG_DBG_SELECT, NCSI_REG_DBG_DWORD_ENABLE,
	NCSI_REG_DBG_SHIFT, NCSI_REG_DBG_FORCE_VALID,
	NCSI_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 5
};

static struct block_defs block_opte_defs = {
	"opte", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 4
};

static struct block_defs block_bmb_defs = {
	"bmb",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCB},
	BMB_REG_DBG_SELECT, BMB_REG_DBG_DWORD_ENABLE,
	BMB_REG_DBG_SHIFT, BMB_REG_DBG_FORCE_VALID,
	BMB_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_UA, 7
};

static struct block_defs block_pcie_defs = {
	"pcie",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS,
	 DBG_BUS_CLIENT_RBCH},
	PCIE_REG_DBG_COMMON_SELECT, PCIE_REG_DBG_COMMON_DWORD_ENABLE,
	PCIE_REG_DBG_COMMON_SHIFT, PCIE_REG_DBG_COMMON_FORCE_VALID,
	PCIE_REG_DBG_COMMON_FORCE_FRAME,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_mcp_defs = {
	"mcp", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_mcp2_defs = {
	"mcp2",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCZ, DBG_BUS_CLIENT_RBCZ},
	MCP2_REG_DBG_SELECT, MCP2_REG_DBG_DWORD_ENABLE,
	MCP2_REG_DBG_SHIFT, MCP2_REG_DBG_FORCE_VALID,
	MCP2_REG_DBG_FORCE_FRAME,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_pswhst_defs = {
	"pswhst",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWHST_REG_DBG_SELECT, PSWHST_REG_DBG_DWORD_ENABLE,
	PSWHST_REG_DBG_SHIFT, PSWHST_REG_DBG_FORCE_VALID,
	PSWHST_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 0
};

static struct block_defs block_pswhst2_defs = {
	"pswhst2",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWHST2_REG_DBG_SELECT, PSWHST2_REG_DBG_DWORD_ENABLE,
	PSWHST2_REG_DBG_SHIFT, PSWHST2_REG_DBG_FORCE_VALID,
	PSWHST2_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 0
};

static struct block_defs block_pswrd_defs = {
	"pswrd",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWRD_REG_DBG_SELECT, PSWRD_REG_DBG_DWORD_ENABLE,
	PSWRD_REG_DBG_SHIFT, PSWRD_REG_DBG_FORCE_VALID,
	PSWRD_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 2
};

static struct block_defs block_pswrd2_defs = {
	"pswrd2",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWRD2_REG_DBG_SELECT, PSWRD2_REG_DBG_DWORD_ENABLE,
	PSWRD2_REG_DBG_SHIFT, PSWRD2_REG_DBG_FORCE_VALID,
	PSWRD2_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 2
};

static struct block_defs block_pswwr_defs = {
	"pswwr",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWWR_REG_DBG_SELECT, PSWWR_REG_DBG_DWORD_ENABLE,
	PSWWR_REG_DBG_SHIFT, PSWWR_REG_DBG_FORCE_VALID,
	PSWWR_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 3
};

static struct block_defs block_pswwr2_defs = {
	"pswwr2", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISC_PL_HV, 3
};

static struct block_defs block_pswrq_defs = {
	"pswrq",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWRQ_REG_DBG_SELECT, PSWRQ_REG_DBG_DWORD_ENABLE,
	PSWRQ_REG_DBG_SHIFT, PSWRQ_REG_DBG_FORCE_VALID,
	PSWRQ_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 1
};

static struct block_defs block_pswrq2_defs = {
	"pswrq2",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PSWRQ2_REG_DBG_SELECT, PSWRQ2_REG_DBG_DWORD_ENABLE,
	PSWRQ2_REG_DBG_SHIFT, PSWRQ2_REG_DBG_FORCE_VALID,
	PSWRQ2_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISC_PL_HV, 1
};

static struct block_defs block_pglcs_defs = {
	"pglcs",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCH},
	PGLCS_REG_DBG_SELECT, PGLCS_REG_DBG_DWORD_ENABLE,
	PGLCS_REG_DBG_SHIFT, PGLCS_REG_DBG_FORCE_VALID,
	PGLCS_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 2
};

static struct block_defs block_ptu_defs = {
	"ptu",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	PTU_REG_DBG_SELECT, PTU_REG_DBG_DWORD_ENABLE,
	PTU_REG_DBG_SHIFT, PTU_REG_DBG_FORCE_VALID,
	PTU_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 20
};

static struct block_defs block_dmae_defs = {
	"dmae",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	DMAE_REG_DBG_SELECT, DMAE_REG_DBG_DWORD_ENABLE,
	DMAE_REG_DBG_SHIFT, DMAE_REG_DBG_FORCE_VALID,
	DMAE_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 28
};

static struct block_defs block_tcm_defs = {
	"tcm",
	{true, true, true}, true, DBG_TSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT},
	TCM_REG_DBG_SELECT, TCM_REG_DBG_DWORD_ENABLE,
	TCM_REG_DBG_SHIFT, TCM_REG_DBG_FORCE_VALID,
	TCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 5
};

static struct block_defs block_mcm_defs = {
	"mcm",
	{true, true, true}, true, DBG_MSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	MCM_REG_DBG_SELECT, MCM_REG_DBG_DWORD_ENABLE,
	MCM_REG_DBG_SHIFT, MCM_REG_DBG_FORCE_VALID,
	MCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 3
};

static struct block_defs block_ucm_defs = {
	"ucm",
	{true, true, true}, true, DBG_USTORM_ID,
	{DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU},
	UCM_REG_DBG_SELECT, UCM_REG_DBG_DWORD_ENABLE,
	UCM_REG_DBG_SHIFT, UCM_REG_DBG_FORCE_VALID,
	UCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 8
};

static struct block_defs block_xcm_defs = {
	"xcm",
	{true, true, true}, true, DBG_XSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX},
	XCM_REG_DBG_SELECT, XCM_REG_DBG_DWORD_ENABLE,
	XCM_REG_DBG_SHIFT, XCM_REG_DBG_FORCE_VALID,
	XCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 19
};

static struct block_defs block_ycm_defs = {
	"ycm",
	{true, true, true}, true, DBG_YSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCY},
	YCM_REG_DBG_SELECT, YCM_REG_DBG_DWORD_ENABLE,
	YCM_REG_DBG_SHIFT, YCM_REG_DBG_FORCE_VALID,
	YCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 5
};

static struct block_defs block_pcm_defs = {
	"pcm",
	{true, true, true}, true, DBG_PSTORM_ID,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS},
	PCM_REG_DBG_SELECT, PCM_REG_DBG_DWORD_ENABLE,
	PCM_REG_DBG_SHIFT, PCM_REG_DBG_FORCE_VALID,
	PCM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 4
};

static struct block_defs block_qm_defs = {
	"qm",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCQ},
	QM_REG_DBG_SELECT, QM_REG_DBG_DWORD_ENABLE,
	QM_REG_DBG_SHIFT, QM_REG_DBG_FORCE_VALID,
	QM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 16
};

static struct block_defs block_tm_defs = {
	"tm",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS},
	TM_REG_DBG_SELECT, TM_REG_DBG_DWORD_ENABLE,
	TM_REG_DBG_SHIFT, TM_REG_DBG_FORCE_VALID,
	TM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 17
};

static struct block_defs block_dorq_defs = {
	"dorq",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCY},
	DORQ_REG_DBG_SELECT, DORQ_REG_DBG_DWORD_ENABLE,
	DORQ_REG_DBG_SHIFT, DORQ_REG_DBG_FORCE_VALID,
	DORQ_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 18
};

static struct block_defs block_brb_defs = {
	"brb",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCR},
	BRB_REG_DBG_SELECT, BRB_REG_DBG_DWORD_ENABLE,
	BRB_REG_DBG_SHIFT, BRB_REG_DBG_FORCE_VALID,
	BRB_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 0
};

static struct block_defs block_src_defs = {
	"src",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF},
	SRC_REG_DBG_SELECT, SRC_REG_DBG_DWORD_ENABLE,
	SRC_REG_DBG_SHIFT, SRC_REG_DBG_FORCE_VALID,
	SRC_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 2
};

static struct block_defs block_prs_defs = {
	"prs",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCR},
	PRS_REG_DBG_SELECT, PRS_REG_DBG_DWORD_ENABLE,
	PRS_REG_DBG_SHIFT, PRS_REG_DBG_FORCE_VALID,
	PRS_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 1
};

static struct block_defs block_tsdm_defs = {
	"tsdm",
	{true, true, true}, true, DBG_TSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT},
	TSDM_REG_DBG_SELECT, TSDM_REG_DBG_DWORD_ENABLE,
	TSDM_REG_DBG_SHIFT, TSDM_REG_DBG_FORCE_VALID,
	TSDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 3
};

static struct block_defs block_msdm_defs = {
	"msdm",
	{true, true, true}, true, DBG_MSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	MSDM_REG_DBG_SELECT, MSDM_REG_DBG_DWORD_ENABLE,
	MSDM_REG_DBG_SHIFT, MSDM_REG_DBG_FORCE_VALID,
	MSDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 6
};

static struct block_defs block_usdm_defs = {
	"usdm",
	{true, true, true}, true, DBG_USTORM_ID,
	{DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU},
	USDM_REG_DBG_SELECT, USDM_REG_DBG_DWORD_ENABLE,
	USDM_REG_DBG_SHIFT, USDM_REG_DBG_FORCE_VALID,
	USDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 7
};

static struct block_defs block_xsdm_defs = {
	"xsdm",
	{true, true, true}, true, DBG_XSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX},
	XSDM_REG_DBG_SELECT, XSDM_REG_DBG_DWORD_ENABLE,
	XSDM_REG_DBG_SHIFT, XSDM_REG_DBG_FORCE_VALID,
	XSDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 20
};

static struct block_defs block_ysdm_defs = {
	"ysdm",
	{true, true, true}, true, DBG_YSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCY},
	YSDM_REG_DBG_SELECT, YSDM_REG_DBG_DWORD_ENABLE,
	YSDM_REG_DBG_SHIFT, YSDM_REG_DBG_FORCE_VALID,
	YSDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 8
};

static struct block_defs block_psdm_defs = {
	"psdm",
	{true, true, true}, true, DBG_PSTORM_ID,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS},
	PSDM_REG_DBG_SELECT, PSDM_REG_DBG_DWORD_ENABLE,
	PSDM_REG_DBG_SHIFT, PSDM_REG_DBG_FORCE_VALID,
	PSDM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 7
};

static struct block_defs block_tsem_defs = {
	"tsem",
	{true, true, true}, true, DBG_TSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT},
	TSEM_REG_DBG_SELECT, TSEM_REG_DBG_DWORD_ENABLE,
	TSEM_REG_DBG_SHIFT, TSEM_REG_DBG_FORCE_VALID,
	TSEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 4
};

static struct block_defs block_msem_defs = {
	"msem",
	{true, true, true}, true, DBG_MSTORM_ID,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	MSEM_REG_DBG_SELECT, MSEM_REG_DBG_DWORD_ENABLE,
	MSEM_REG_DBG_SHIFT, MSEM_REG_DBG_FORCE_VALID,
	MSEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 9
};

static struct block_defs block_usem_defs = {
	"usem",
	{true, true, true}, true, DBG_USTORM_ID,
	{DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU},
	USEM_REG_DBG_SELECT, USEM_REG_DBG_DWORD_ENABLE,
	USEM_REG_DBG_SHIFT, USEM_REG_DBG_FORCE_VALID,
	USEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 9
};

static struct block_defs block_xsem_defs = {
	"xsem",
	{true, true, true}, true, DBG_XSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX},
	XSEM_REG_DBG_SELECT, XSEM_REG_DBG_DWORD_ENABLE,
	XSEM_REG_DBG_SHIFT, XSEM_REG_DBG_FORCE_VALID,
	XSEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 21
};

static struct block_defs block_ysem_defs = {
	"ysem",
	{true, true, true}, true, DBG_YSTORM_ID,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCY},
	YSEM_REG_DBG_SELECT, YSEM_REG_DBG_DWORD_ENABLE,
	YSEM_REG_DBG_SHIFT, YSEM_REG_DBG_FORCE_VALID,
	YSEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 11
};

static struct block_defs block_psem_defs = {
	"psem",
	{true, true, true}, true, DBG_PSTORM_ID,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS},
	PSEM_REG_DBG_SELECT, PSEM_REG_DBG_DWORD_ENABLE,
	PSEM_REG_DBG_SHIFT, PSEM_REG_DBG_FORCE_VALID,
	PSEM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 10
};

static struct block_defs block_rss_defs = {
	"rss",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT},
	RSS_REG_DBG_SELECT, RSS_REG_DBG_DWORD_ENABLE,
	RSS_REG_DBG_SHIFT, RSS_REG_DBG_FORCE_VALID,
	RSS_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 18
};

static struct block_defs block_tmld_defs = {
	"tmld",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	TMLD_REG_DBG_SELECT, TMLD_REG_DBG_DWORD_ENABLE,
	TMLD_REG_DBG_SHIFT, TMLD_REG_DBG_FORCE_VALID,
	TMLD_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 13
};

static struct block_defs block_muld_defs = {
	"muld",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU},
	MULD_REG_DBG_SELECT, MULD_REG_DBG_DWORD_ENABLE,
	MULD_REG_DBG_SHIFT, MULD_REG_DBG_FORCE_VALID,
	MULD_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 14
};

static struct block_defs block_yuld_defs = {
	"yuld",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU, DBG_BUS_CLIENT_RBCU},
	YULD_REG_DBG_SELECT, YULD_REG_DBG_DWORD_ENABLE,
	YULD_REG_DBG_SHIFT, YULD_REG_DBG_FORCE_VALID,
	YULD_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 15
};

static struct block_defs block_xyld_defs = {
	"xyld",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX, DBG_BUS_CLIENT_RBCX},
	XYLD_REG_DBG_SELECT, XYLD_REG_DBG_DWORD_ENABLE,
	XYLD_REG_DBG_SHIFT, XYLD_REG_DBG_FORCE_VALID,
	XYLD_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 12
};

static struct block_defs block_prm_defs = {
	"prm",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	PRM_REG_DBG_SELECT, PRM_REG_DBG_DWORD_ENABLE,
	PRM_REG_DBG_SHIFT, PRM_REG_DBG_FORCE_VALID,
	PRM_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 21
};

static struct block_defs block_pbf_pb1_defs = {
	"pbf_pb1",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCV},
	PBF_PB1_REG_DBG_SELECT, PBF_PB1_REG_DBG_DWORD_ENABLE,
	PBF_PB1_REG_DBG_SHIFT, PBF_PB1_REG_DBG_FORCE_VALID,
	PBF_PB1_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1,
	11
};

static struct block_defs block_pbf_pb2_defs = {
	"pbf_pb2",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCV},
	PBF_PB2_REG_DBG_SELECT, PBF_PB2_REG_DBG_DWORD_ENABLE,
	PBF_PB2_REG_DBG_SHIFT, PBF_PB2_REG_DBG_FORCE_VALID,
	PBF_PB2_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1,
	12
};

static struct block_defs block_rpb_defs = {
	"rpb",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	RPB_REG_DBG_SELECT, RPB_REG_DBG_DWORD_ENABLE,
	RPB_REG_DBG_SHIFT, RPB_REG_DBG_FORCE_VALID,
	RPB_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 13
};

static struct block_defs block_btb_defs = {
	"btb",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCR, DBG_BUS_CLIENT_RBCV},
	BTB_REG_DBG_SELECT, BTB_REG_DBG_DWORD_ENABLE,
	BTB_REG_DBG_SHIFT, BTB_REG_DBG_FORCE_VALID,
	BTB_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 10
};

static struct block_defs block_pbf_defs = {
	"pbf",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCV},
	PBF_REG_DBG_SELECT, PBF_REG_DBG_DWORD_ENABLE,
	PBF_REG_DBG_SHIFT, PBF_REG_DBG_FORCE_VALID,
	PBF_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 15
};

static struct block_defs block_rdif_defs = {
	"rdif",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCT, DBG_BUS_CLIENT_RBCM},
	RDIF_REG_DBG_SELECT, RDIF_REG_DBG_DWORD_ENABLE,
	RDIF_REG_DBG_SHIFT, RDIF_REG_DBG_FORCE_VALID,
	RDIF_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 16
};

static struct block_defs block_tdif_defs = {
	"tdif",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS, DBG_BUS_CLIENT_RBCS},
	TDIF_REG_DBG_SELECT, TDIF_REG_DBG_DWORD_ENABLE,
	TDIF_REG_DBG_SHIFT, TDIF_REG_DBG_FORCE_VALID,
	TDIF_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 17
};

static struct block_defs block_cdu_defs = {
	"cdu",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF},
	CDU_REG_DBG_SELECT, CDU_REG_DBG_DWORD_ENABLE,
	CDU_REG_DBG_SHIFT, CDU_REG_DBG_FORCE_VALID,
	CDU_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 23
};

static struct block_defs block_ccfc_defs = {
	"ccfc",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF},
	CCFC_REG_DBG_SELECT, CCFC_REG_DBG_DWORD_ENABLE,
	CCFC_REG_DBG_SHIFT, CCFC_REG_DBG_FORCE_VALID,
	CCFC_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 24
};

static struct block_defs block_tcfc_defs = {
	"tcfc",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF, DBG_BUS_CLIENT_RBCF},
	TCFC_REG_DBG_SELECT, TCFC_REG_DBG_DWORD_ENABLE,
	TCFC_REG_DBG_SHIFT, TCFC_REG_DBG_FORCE_VALID,
	TCFC_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 25
};

static struct block_defs block_igu_defs = {
	"igu",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	IGU_REG_DBG_SELECT, IGU_REG_DBG_DWORD_ENABLE,
	IGU_REG_DBG_SHIFT, IGU_REG_DBG_FORCE_VALID,
	IGU_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_1, 27
};

static struct block_defs block_cau_defs = {
	"cau",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP, DBG_BUS_CLIENT_RBCP},
	CAU_REG_DBG_SELECT, CAU_REG_DBG_DWORD_ENABLE,
	CAU_REG_DBG_SHIFT, CAU_REG_DBG_FORCE_VALID,
	CAU_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VMAIN_2, 19
};

static struct block_defs block_umac_defs = {
	"umac",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCZ},
	UMAC_REG_DBG_SELECT, UMAC_REG_DBG_DWORD_ENABLE,
	UMAC_REG_DBG_SHIFT, UMAC_REG_DBG_FORCE_VALID,
	UMAC_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 6
};

static struct block_defs block_xmac_defs = {
	"xmac", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_dbg_defs = {
	"dbg", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VAUX, 3
};

static struct block_defs block_nig_defs = {
	"nig",
	{true, true, true}, false, 0,
	{DBG_BUS_CLIENT_RBCN, DBG_BUS_CLIENT_RBCN, DBG_BUS_CLIENT_RBCN},
	NIG_REG_DBG_SELECT, NIG_REG_DBG_DWORD_ENABLE,
	NIG_REG_DBG_SHIFT, NIG_REG_DBG_FORCE_VALID,
	NIG_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VAUX, 0
};

static struct block_defs block_wol_defs = {
	"wol",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCZ},
	WOL_REG_DBG_SELECT, WOL_REG_DBG_DWORD_ENABLE,
	WOL_REG_DBG_SHIFT, WOL_REG_DBG_FORCE_VALID,
	WOL_REG_DBG_FORCE_FRAME,
	true, true, DBG_RESET_REG_MISC_PL_PDA_VAUX, 7
};

static struct block_defs block_bmbn_defs = {
	"bmbn",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCB},
	BMBN_REG_DBG_SELECT, BMBN_REG_DBG_DWORD_ENABLE,
	BMBN_REG_DBG_SHIFT, BMBN_REG_DBG_FORCE_VALID,
	BMBN_REG_DBG_FORCE_FRAME,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_ipc_defs = {
	"ipc", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISCS_PL_UA, 8
};

static struct block_defs block_nwm_defs = {
	"nwm",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, DBG_BUS_CLIENT_RBCW},
	NWM_REG_DBG_SELECT, NWM_REG_DBG_DWORD_ENABLE,
	NWM_REG_DBG_SHIFT, NWM_REG_DBG_FORCE_VALID,
	NWM_REG_DBG_FORCE_FRAME,
	true, false, DBG_RESET_REG_MISCS_PL_HV_2, 0
};

static struct block_defs block_nws_defs = {
	"nws", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 12
};

static struct block_defs block_ms_defs = {
	"ms", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, false, DBG_RESET_REG_MISCS_PL_HV, 13
};

static struct block_defs block_phy_pcie_defs = {
	"phy_pcie",
	{false, false, true}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS,
	 DBG_BUS_CLIENT_RBCH},
	PCIE_REG_DBG_COMMON_SELECT, PCIE_REG_DBG_COMMON_DWORD_ENABLE,
	PCIE_REG_DBG_COMMON_SHIFT, PCIE_REG_DBG_COMMON_FORCE_VALID,
	PCIE_REG_DBG_COMMON_FORCE_FRAME,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_led_defs = {
	"led", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	true, true, DBG_RESET_REG_MISCS_PL_HV, 14
};

static struct block_defs block_misc_aeu_defs = {
	"misc_aeu", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs block_bar0_map_defs = {
	"bar0_map", {false, false, false}, false, 0,
	{MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS, MAX_DBG_BUS_CLIENTS},
	0, 0, 0, 0, 0,
	false, false, MAX_DBG_RESET_REGS, 0
};

static struct block_defs *s_block_defs[MAX_BLOCK_ID] = {
	&block_grc_defs,
	&block_miscs_defs,
	&block_misc_defs,
	&block_dbu_defs,
	&block_pglue_b_defs,
	&block_cnig_defs,
	&block_cpmu_defs,
	&block_ncsi_defs,
	&block_opte_defs,
	&block_bmb_defs,
	&block_pcie_defs,
	&block_mcp_defs,
	&block_mcp2_defs,
	&block_pswhst_defs,
	&block_pswhst2_defs,
	&block_pswrd_defs,
	&block_pswrd2_defs,
	&block_pswwr_defs,
	&block_pswwr2_defs,
	&block_pswrq_defs,
	&block_pswrq2_defs,
	&block_pglcs_defs,
	&block_dmae_defs,
	&block_ptu_defs,
	&block_tcm_defs,
	&block_mcm_defs,
	&block_ucm_defs,
	&block_xcm_defs,
	&block_ycm_defs,
	&block_pcm_defs,
	&block_qm_defs,
	&block_tm_defs,
	&block_dorq_defs,
	&block_brb_defs,
	&block_src_defs,
	&block_prs_defs,
	&block_tsdm_defs,
	&block_msdm_defs,
	&block_usdm_defs,
	&block_xsdm_defs,
	&block_ysdm_defs,
	&block_psdm_defs,
	&block_tsem_defs,
	&block_msem_defs,
	&block_usem_defs,
	&block_xsem_defs,
	&block_ysem_defs,
	&block_psem_defs,
	&block_rss_defs,
	&block_tmld_defs,
	&block_muld_defs,
	&block_yuld_defs,
	&block_xyld_defs,
	&block_prm_defs,
	&block_pbf_pb1_defs,
	&block_pbf_pb2_defs,
	&block_rpb_defs,
	&block_btb_defs,
	&block_pbf_defs,
	&block_rdif_defs,
	&block_tdif_defs,
	&block_cdu_defs,
	&block_ccfc_defs,
	&block_tcfc_defs,
	&block_igu_defs,
	&block_cau_defs,
	&block_umac_defs,
	&block_xmac_defs,
	&block_dbg_defs,
	&block_nig_defs,
	&block_wol_defs,
	&block_bmbn_defs,
	&block_ipc_defs,
	&block_nwm_defs,
	&block_nws_defs,
	&block_ms_defs,
	&block_phy_pcie_defs,
	&block_led_defs,
	&block_misc_aeu_defs,
	&block_bar0_map_defs,
};

/* Constraint operation types */
static struct dbg_bus_constraint_op_defs s_constraint_op_defs[] = {
	{0, false},		/* DBG_BUS_CONSTRAINT_OP_EQ */
	{5, false},		/* DBG_BUS_CONSTRAINT_OP_NE */
	{1, false},		/* DBG_BUS_CONSTRAINT_OP_LT */
	{1, true},		/* DBG_BUS_CONSTRAINT_OP_LTC */
	{2, false},		/* DBG_BUS_CONSTRAINT_OP_LE */
	{2, true},		/* DBG_BUS_CONSTRAINT_OP_LEC */
	{4, false},		/* DBG_BUS_CONSTRAINT_OP_GT */
	{4, true},		/* DBG_BUS_CONSTRAINT_OP_GTC */
	{3, false},		/* DBG_BUS_CONSTRAINT_OP_GE */
	{3, true}		/* DBG_BUS_CONSTRAINT_OP_GEC */
};

static const char *s_dbg_target_names[] = {
	"int-buf",		/* DBG_BUS_TARGET_ID_INT_BUF */
	"nw",			/* DBG_BUS_TARGET_ID_NIG */
	"pci-buf"		/* DBG_BUS_TARGET_ID_PCI */
};

static struct storm_mode_defs s_storm_mode_defs[] = {
	{"printf", true, 0},	/* DBG_BUS_STORM_MODE_PRINTF */
	{"pram_addr", true, 1},	/* DBG_BUS_STORM_MODE_PRAM_ADDR */
	{"dra_rw", true, 2},	/* DBG_BUS_STORM_MODE_DRA_RW */
	{"dra_w", true, 3},	/* DBG_BUS_STORM_MODE_DRA_W */
	{"ld_st_addr", true, 4},	/* DBG_BUS_STORM_MODE_LD_ST_ADDR */
	{"dra_fsm", true, 5},	/* DBG_BUS_STORM_MODE_DRA_FSM */
	{"rh", true, 6},	/* DBG_BUS_STORM_MODE_RH */
	{"foc", false, 1},	/* DBG_BUS_STORM_MODE_FOC */
	{"ext_store", false, 3}	/* DBG_BUS_STORM_MODE_EXT_STORE */
};

static struct platform_defs s_platform_defs[] = {
	{"asic", 1},		/* PLATFORM_ASIC */
	{"emul_full", 2000},	/* PLATFORM_EMUL_FULL */
	{"emul_reduced", 2000},	/* PLATFORM_EMUL_REDUCED */
	{"fpga", 200}		/* PLATFORM_FPGA */
};

static struct grc_param_defs s_grc_param_defs[] = {
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_TSTORM */
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_MSTORM */
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_USTORM */
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_XSTORM */
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_YSTORM */
	{{1, 1,
	  1}, 0, 1, false, 1, 1},	/* DBG_GRC_PARAM_DUMP_PSTORM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_REGS */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_RAM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_PBUF */
	{{0, 0,
	  0}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_IOR */
	{{0, 0,
	  0}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_VFC */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_CM_CTX */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_ILT */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_RSS */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_CAU */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_QM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_MCP */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_RESERVED */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_CFC */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_IGU */
	{{0, 0,
	  0}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_BRB */
	{{0, 0,
	  0}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_BTB */
	{{0, 0,
	  0}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_BMB */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_NIG */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_MULD */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_PRS */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_DMAE */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_TM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_SDM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_DIF */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_STATIC */
	{{0, 0,
	  0}, 0, 1, false, 0, 0},	/* DBG_GRC_PARAM_UNSTALL */
	{{MAX_LCIDS, MAX_LCIDS,
	  MAX_LCIDS}, 1, MAX_LCIDS, false, MAX_LCIDS, MAX_LCIDS},	/* DBG_GRC_PARAM_NUM_LCIDS */
	{{MAX_LTIDS, MAX_LTIDS,
	  MAX_LTIDS}, 1, MAX_LTIDS, false, MAX_LTIDS, MAX_LTIDS},	/* DBG_GRC_PARAM_NUM_LTIDS */
	{{0, 0,
	  0}, 0, 1, true, 0, 0},	/* DBG_GRC_PARAM_EXCLUDE_ALL */
	{{0, 0,
	  0}, 0, 1, true, 0, 0},	/* DBG_GRC_PARAM_CRASH */
	{{0, 0,
	  0}, 0, 1, false, 1, 0},	/* DBG_GRC_PARAM_PARITY_SAFE */
	{{1, 1,
	  1}, 0, 1, false, 0, 1},	/* DBG_GRC_PARAM_DUMP_CM */
	{{1, 1,
	  1}, 0, 1, false, 0, 1}	/* DBG_GRC_PARAM_DUMP_PHY */
};

static struct rss_mem_defs s_rss_mem_defs[] = {
	{"rss_mem_cid", "rss_cid", 0,
	 {256, 256, 320},
	 {32, 32, 32}},
	{"rss_mem_key_msb", "rss_key", 1024,
	 {((128)), ((128)), ((208))},
	 {256, 256, 256}},
	{"rss_mem_key_lsb", "rss_key", 2048,
	 {((128)), ((128)), ((208))},
	 {64, 64, 64}},
	{"rss_mem_info", "rss_info", 3072,
	 {((128)), ((128)), ((208))},
	 {16, 16, 16}},
	{"rss_mem_ind", "rss_ind", 4096,
	 {((128) * (128)), ((128) * (128)), ((128) * (208))},
	 {16, 16, 16}}
};

static struct vfc_ram_defs s_vfc_ram_defs[] = {
	{"vfc_ram_tt1", "vfc_ram", 0, 512},
	{"vfc_ram_mtt2", "vfc_ram", 512, 128},
	{"vfc_ram_stt2", "vfc_ram", 640, 32},
	{"vfc_ram_ro_vect", "vfc_ram", 672, 32}
};

static struct big_ram_defs s_big_ram_defs[] = {
	{"BRB", MEM_GROUP_BRB_MEM, MEM_GROUP_BRB_RAM, DBG_GRC_PARAM_DUMP_BRB,
	 BRB_REG_BIG_RAM_ADDRESS, BRB_REG_BIG_RAM_DATA,
	 {4800, 4800, 5632}},
	{"BTB", MEM_GROUP_BTB_MEM, MEM_GROUP_BTB_RAM, DBG_GRC_PARAM_DUMP_BTB,
	 BTB_REG_BIG_RAM_ADDRESS, BTB_REG_BIG_RAM_DATA,
	 {2880, 2880, 3680}},
	{"BMB", MEM_GROUP_BMB_MEM, MEM_GROUP_BMB_RAM, DBG_GRC_PARAM_DUMP_BMB,
	 BMB_REG_BIG_RAM_ADDRESS, BMB_REG_BIG_RAM_DATA,
	 {1152, 1152, 1152}}
};

static struct reset_reg_defs s_reset_regs_defs[] = {
	{MISCS_REG_RESET_PL_UA, 0x0,
	 {true, true, true}},	/* DBG_RESET_REG_MISCS_PL_UA */
	{MISCS_REG_RESET_PL_HV, 0x0,
	 {true, true, true}},	/* DBG_RESET_REG_MISCS_PL_HV */
	{MISCS_REG_RESET_PL_HV_2, 0x0,
	 {false, false, true}},	/* DBG_RESET_REG_MISCS_PL_HV_2 */
	{MISC_REG_RESET_PL_UA, 0x0,
	 {true, true, true}},	/* DBG_RESET_REG_MISC_PL_UA */
	{MISC_REG_RESET_PL_HV, 0x0,
	 {true, true, true}},	/* DBG_RESET_REG_MISC_PL_HV */
	{MISC_REG_RESET_PL_PDA_VMAIN_1, 0x4404040,
	 {true, true, true}},	/* DBG_RESET_REG_MISC_PL_PDA_VMAIN_1 */
	{MISC_REG_RESET_PL_PDA_VMAIN_2, 0x7c00007,
	 {true, true, true}},	/* DBG_RESET_REG_MISC_PL_PDA_VMAIN_2 */
	{MISC_REG_RESET_PL_PDA_VAUX, 0x2,
	 {true, true, true}},	/* DBG_RESET_REG_MISC_PL_PDA_VAUX */
};

static struct phy_defs s_phy_defs[] = {
	{"nw_phy", NWS_REG_NWS_CMU, PHY_NW_IP_REG_PHY0_TOP_TBUS_ADDR_7_0,
	 PHY_NW_IP_REG_PHY0_TOP_TBUS_ADDR_15_8,
	 PHY_NW_IP_REG_PHY0_TOP_TBUS_DATA_7_0,
	 PHY_NW_IP_REG_PHY0_TOP_TBUS_DATA_11_8},
	{"sgmii_phy", MS_REG_MS_CMU, PHY_SGMII_IP_REG_AHB_CMU_CSR_0_X132,
	 PHY_SGMII_IP_REG_AHB_CMU_CSR_0_X133,
	 PHY_SGMII_IP_REG_AHB_CMU_CSR_0_X130,
	 PHY_SGMII_IP_REG_AHB_CMU_CSR_0_X131},
	{"pcie_phy0", PHY_PCIE_REG_PHY0, PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X132,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X133,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X130,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X131},
	{"pcie_phy1", PHY_PCIE_REG_PHY1, PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X132,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X133,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X130,
	 PHY_PCIE_IP_REG_AHB_CMU_CSR_0_X131},
};

/* The order of indexes that should be applied to a PCI buffer line */
static const u8 s_pci_buf_line_ind[PCI_BUF_LINE_SIZE_IN_DWORDS] =
    { 1, 0, 3, 2, 5, 4, 7, 6 };
/******************************** Variables **********************************/
/* The version of the calling app */
static u32 s_app_ver;
/**************************** Private Functions ******************************/
static void qed_static_asserts(void)
{
}

/* Reads and returns a single dword from the specified unaligned buffer. */
static u32 qed_read_unaligned_dword(u8 * buf)
{
	u32 dword;

	memcpy((u8 *) & dword, buf, sizeof(dword));
	return dword;
}

/* Returns the difference in bytes between the specified physical addresses.
 * Assumes that the first address is bigger then the second, and that the
 * difference is a 32-bit value. */
static u32 qed_phys_addr_diff(struct dbg_bus_mem_addr *a,
			      struct dbg_bus_mem_addr *b)
{
	return a->hi == b->hi ? a->lo - b->lo : b->lo - a->lo;
}

/* initializes debug data for the specified device */
static enum dbg_status qed_dbg_dev_init(struct qed_hwfn *p_hwfn,
					struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	if (dev_data->initialized)
		return DBG_STATUS_OK;
	if (!s_app_ver)
		return DBG_STATUS_APP_VERSION_NOT_SET;
	if (QED_IS_K2(p_hwfn->cdev)) {
		dev_data->chip_id = CHIP_K2;
		dev_data->mode_enable[MODE_K2] = 1;
	} else if (QED_IS_BB_A0(p_hwfn->cdev)) {
		dev_data->chip_id = CHIP_BB_A0;
		dev_data->mode_enable[MODE_BB_A0] = 1;
	} else if (QED_IS_BB_B0(p_hwfn->cdev)) {
		dev_data->chip_id = CHIP_BB_B0;
		dev_data->mode_enable[MODE_BB_B0] = 1;
	} else {
		return DBG_STATUS_UNKNOWN_CHIP;
	}
#ifdef ASIC_ONLY
	dev_data->platform_id = PLATFORM_ASIC;
	dev_data->mode_enable[MODE_ASIC] = 1;
#else
	if (CHIP_REV_IS_ASIC(p_hwfn->cdev)) {
		dev_data->platform_id = PLATFORM_ASIC;
		dev_data->mode_enable[MODE_ASIC] = 1;
	} else if (CHIP_REV_IS_EMUL(p_hwfn->cdev)) {
		if (qed_rd(p_hwfn, p_ptt, MISCS_REG_ECO_RESERVED) & 0x20000000) {
			dev_data->platform_id = PLATFORM_EMUL_FULL;
			dev_data->mode_enable[MODE_EMUL_FULL] = 1;
		} else {
			dev_data->platform_id = PLATFORM_EMUL_REDUCED;
			dev_data->mode_enable[MODE_EMUL_REDUCED] = 1;
		}
	} else if (CHIP_REV_IS_FPGA(p_hwfn->cdev)) {
		dev_data->platform_id = PLATFORM_FPGA;
		dev_data->mode_enable[MODE_FPGA] = 1;
	} else {
		return DBG_STATUS_UNKNOWN_CHIP;
	}
#endif
	dev_data->initialized = true;
	return DBG_STATUS_OK;
}

static u32 qed_calc_crc32(u8 * buf, u32 buf_size)
{
	u32 crc = 0xffffffff;
	u8 k;

/* CRC-32 Castagnoli polynomial (used by Intel crc32 instruction) in reversed bit order. */
#define POLY 0xedb88320
	while (buf_size--) {
		crc ^= *buf++;
		for (k = 0; k < 8; k++)
			crc = crc & 1 ? (crc >> 1) ^ POLY : crc >> 1;
	}
	return ~crc;
}

/* returns the nearest power of 2 of the specified number */
static u32 qed_get_near_pow2(u32 num)
{
	u32 i;

	num--;
	for (i = 1; i < 32; i <<= 1)
		num |= num >> i;
	return num + 1;
}

/* reads the FW info structure for the specified Storm from the chip,
 * and writes it to the specified fw_info pointer */
static void qed_read_fw_info(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt,
			     u8 storm_id, struct fw_info *fw_info)
{
	/* read first the address that points to fw_info location.
	 * The address is located in the last line of the Storm RAM. */
	struct fw_info_location fw_info_location;
	u32 addr =
	    s_storm_defs[storm_id].sem_fast_mem_addr +
	    SEM_FAST_REG_INT_RAM +
	    DWORDS_TO_BYTES(SEM_FAST_REG_INT_RAM_SIZE) -
	    sizeof(struct fw_info_location);
	u32 *dest = (u32 *) & fw_info_location;
	u32 i;

	memset(&fw_info_location, 0, sizeof(fw_info_location));
	memset(fw_info, 0, sizeof(struct fw_info));
	for (i = 0; i < BYTES_TO_DWORDS(sizeof(struct fw_info_location));
	     i++, addr += BYTES_IN_DWORD)
		dest[i] = qed_rd(p_hwfn, p_ptt, addr);
	if (fw_info_location.size > 0 && fw_info_location.size <=
	    sizeof(struct fw_info)) {
		/* read FW version info from Storm RAM */
		addr = fw_info_location.grc_addr;
		dest = (u32 *) fw_info;
		for (i = 0; i < BYTES_TO_DWORDS(fw_info_location.size);
		     i++, addr += BYTES_IN_DWORD)
			dest[i] = qed_rd(p_hwfn, p_ptt, addr);
	}
}

/* Dumps the specified string to the specified buffer. Returns the dumped size in bytes. */
static u32 qed_dump_str(char *dump_buf, bool dump, const char *str)
{
	if (dump)
		strcpy(dump_buf, str);
	return (u32) strlen(str) + 1;
}

/* Dumps zeros to align the specified buffer to dwords. Returns the dumped size in bytes. */
static u32 qed_dump_align(char *dump_buf, bool dump, u32 byte_offset)
{
	u8 offset_in_dword = (u8) (byte_offset & 0x3);
	u8 align_size = offset_in_dword ? BYTES_IN_DWORD - offset_in_dword : 0;

	if (dump && align_size)
		memset(dump_buf, 0, align_size);
	return align_size;
}

/* Writes the specified string param to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_str_param(u32 * dump_buf,
			      bool dump,
			      const char *param_name, const char *param_val)
{
	char *char_buf = (char *)dump_buf;
	u32 offset = 0;

	/* dump param name */
	offset += qed_dump_str(char_buf + offset, dump, param_name);
	/* indicate a string param value */
	if (dump)
		*(char_buf + offset) = 1;
	offset++;
	/* dump param value */
	offset += qed_dump_str(char_buf + offset, dump, param_val);
	/* align buffer to next dword */
	offset += qed_dump_align(char_buf + offset, dump, offset);
	return BYTES_TO_DWORDS(offset);
}

/* Writes the specified numeric param to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_num_param(u32 * dump_buf,
			      bool dump, const char *param_name, u32 param_val)
{
	char *char_buf = (char *)dump_buf;
	u32 offset = 0;

	/* dump param name */
	offset += qed_dump_str(char_buf + offset, dump, param_name);
	/* indicate a numeric param value */
	if (dump)
		*(char_buf + offset) = 0;
	offset++;
	/* align buffer to next dword */
	offset += qed_dump_align(char_buf + offset, dump, offset);
	/* dump param value (and change offset from bytes to dwords) */
	offset = BYTES_TO_DWORDS(offset);
	if (dump)
		*(dump_buf + offset) = param_val;
	offset++;
	return offset;
}

/* Reads the FW version and writes it as a param to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_fw_ver_param(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	struct fw_info fw_info = { {0}, {0} };
	char fw_ver_str[16] = EMPTY_FW_VERSION_STR;
	char fw_img_str[16] = EMPTY_FW_IMAGE_STR;
	u32 offset = 0;
	int printed_chars;

	if (dump) {
		/* read FW image/version from PRAM in a non-reset SEMI */
		bool found = false;
		u8 storm_id;
		for (storm_id = 0; storm_id < MAX_DBG_STORMS && !found;
		     storm_id++) {
			/* read FW version/image  */
			if (!dev_data->
			    block_in_reset[s_storm_defs[storm_id].block_id]) {
				/* read FW info for the current Storm  */
				qed_read_fw_info(p_hwfn,
						 p_ptt, storm_id, &fw_info);
				/* create FW version/image strings */
				printed_chars =
				    snprintf(fw_ver_str,
					     sizeof(fw_ver_str),
					     "%d_%d_%d_%d",
					     fw_info.ver.num.major,
					     fw_info.ver.num.minor,
					     fw_info.ver.num.rev,
					     fw_info.ver.num.eng);
				if (printed_chars < 0 || printed_chars >=
				    sizeof(fw_ver_str))
					DP_NOTICE(p_hwfn,
						  "Unexpected debug error: invalid FW version string");
				switch (fw_info.ver.image_id) {
				case FW_IMG_KUKU:
					strcpy(fw_img_str, "kuku");
					break;
				case FW_IMG_MAIN:
					strcpy(fw_img_str, "main");
					break;
				case FW_IMG_L2B:
					strcpy(fw_img_str, "l2b");
					break;
				default:
					strcpy(fw_img_str, "unknown");
					break;
				}
				found = true;
			}
		}
	}
	/* dump FW version, image and timestamp */
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "fw-version", fw_ver_str);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "fw-image", fw_img_str);
	offset += qed_dump_num_param(dump_buf + offset,
				     dump,
				     "fw-timestamp", fw_info.ver.timestamp);
	return offset;
}

/* Reads the MFW version and writes it as a param to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_mfw_ver_param(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	char mfw_ver_str[16] = EMPTY_FW_VERSION_STR;
	bool is_emul = dev_data->platform_id ==
	    PLATFORM_EMUL_FULL || dev_data->platform_id ==
	    PLATFORM_EMUL_REDUCED;

	if (dump && !is_emul) {
		/* find MCP public data GRC address. Needs to be ORed with MCP_REG_SCRATCH due to a HW bug. */
		u32 public_data_addr = qed_rd(p_hwfn,
					      p_ptt,
					      MISC_REG_SHARED_MEM_ADDR) |
		    MCP_REG_SCRATCH;
		/* find MCP public global section offset */
		u32 global_section_offsize_addr = public_data_addr +
		    offsetof(struct mcp_public_data,
			     sections) + sizeof(offsize_t) * PUBLIC_GLOBAL;
		u32 global_section_offsize = qed_rd(p_hwfn,
						    p_ptt,
						    global_section_offsize_addr);
		u32 global_section_addr = MCP_REG_SCRATCH +
		    (global_section_offsize & OFFSIZE_OFFSET_MASK) * 4;
		/* read MFW version from MCP public global section */
		u32 mfw_ver = qed_rd(p_hwfn,
				     p_ptt,
				     global_section_addr +
				     offsetof(struct public_global, mfw_ver));
		/* dump MFW version param */
		int printed_chars = snprintf(mfw_ver_str,
					     sizeof(mfw_ver_str),
					     "%d_%d_%d_%d",
					     (u8) (mfw_ver >> 24),
					     (u8) (mfw_ver >> 16),
					     (u8) (mfw_ver >> 8),
					     (u8) mfw_ver);
		if (printed_chars < 0 || printed_chars >= sizeof(mfw_ver_str))
			DP_NOTICE(p_hwfn,
				  "Unexpected debug error: invalid MFW version string");
	}
	return qed_dump_str_param(dump_buf, dump, "mfw-version", mfw_ver_str);
}

/* Writes a section header to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_section_hdr(u32 * dump_buf,
				bool dump, const char *name, u32 num_params)
{
	return qed_dump_num_param(dump_buf, dump, name, num_params);
}

/* Writes the common global params to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_dump_common_global_params(struct qed_hwfn *p_hwfn,
					 struct qed_ptt *p_ptt,
					 u32 * dump_buf,
					 bool dump,
					 u8 num_specific_global_params)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0;

	/* dump global params section header */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump,
				       "global_params",
				       NUM_COMMON_GLOBAL_PARAMS +
				       num_specific_global_params);
	/* store params */
	offset += qed_dump_fw_ver_param(p_hwfn, p_ptt, dump_buf + offset, dump);
	offset += qed_dump_mfw_ver_param(p_hwfn,
					 p_ptt, dump_buf + offset, dump);
	offset += qed_dump_num_param(dump_buf + offset,
				     dump, "tools-version", TOOLS_VERSION);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump,
				     "chip",
				     s_chip_defs[dev_data->chip_id].name);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump,
				     "platform",
				     s_platform_defs[dev_data->
						     platform_id].name);
	offset +=
	    qed_dump_num_param(dump_buf + offset, dump, "pci-func",
			       p_hwfn->abs_pf_id);
	return offset;
}

/* Writes the last section to the specified buffer at the given offset. Returns the dumped size in dwords. */
static u32 qed_dump_last_section(u32 * dump_buf, u32 offset, bool dump)
{
	u32 start_offset = offset;

	/* dump CRC section header */
	offset += qed_dump_section_hdr(dump_buf + offset, dump, "last", 0);
	/* calculate CRC32 and add it to the dword following the "last" section */
	if (dump)
		*(dump_buf + offset) = qed_calc_crc32((u8 *) dump_buf,
						      DWORDS_TO_BYTES(offset));
	offset++;
	return offset - start_offset;
}

/* Update blocks reset state  */
static void qed_update_blocks_reset_state(struct qed_hwfn *p_hwfn,
					  struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 reg_val[MAX_DBG_RESET_REGS] = { 0 };
	u32 i;

	/* read reset registers */
	for (i = 0; i < MAX_DBG_RESET_REGS; i++)
		if (s_reset_regs_defs[i].exists[dev_data->chip_id])
			reg_val[i] = qed_rd(p_hwfn,
					    p_ptt, s_reset_regs_defs[i].addr);
	/* check if blocks are in reset */
	for (i = 0; i < MAX_BLOCK_ID; i++)
		dev_data->block_in_reset[i] =
		    s_block_defs[i]->has_reset_bit &&
		    (reg_val[s_block_defs[i]->reset_reg] &
		     BIT(s_block_defs[i]->reset_bit_offset)) == 0;
}

/* Enable / disable the Debug block */
static void qed_bus_enable_dbg_block(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt, bool enable)
{
	qed_wr(p_hwfn, p_ptt, DBG_REG_DBG_BLOCK_ON, enable ? 1 : 0);
}

/* Resets the Debug block */
static void qed_bus_reset_dbg_block(struct qed_hwfn *p_hwfn,
				    struct qed_ptt *p_ptt)
{
	u32 dbg_reset_reg_addr =
	    s_reset_regs_defs[s_block_defs[BLOCK_DBG]->reset_reg].addr;
	u32 old_reset_reg_val = qed_rd(p_hwfn,
				       p_ptt,
				       dbg_reset_reg_addr);
	u32 new_reset_reg_val =
	    old_reset_reg_val & ~BIT(s_block_defs[BLOCK_DBG]->reset_bit_offset);

	qed_wr(p_hwfn, p_ptt, dbg_reset_reg_addr, new_reset_reg_val);
	qed_wr(p_hwfn, p_ptt, dbg_reset_reg_addr, old_reset_reg_val);
}

static void qed_bus_set_framing_mode(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     enum dbg_bus_frame_modes mode)
{
	qed_wr(p_hwfn, p_ptt, DBG_REG_FRAMING_MODE, (u8) mode);
}

/* Enable / disable Debug Bus clients according to the specified mask (1 = enable, 0 = disable) */
static void qed_bus_enable_clients(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt, u32 client_mask)
{
	qed_wr(p_hwfn, p_ptt, DBG_REG_CLIENT_ENABLE, client_mask);
}

/* Enables the specified Storm for Debug Bus. Assumes a valid Storm ID. */
static void qed_bus_enable_storm(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 enum dbg_storms storm,
				 enum dbg_bus_filter_types filter_type)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 base_addr = s_storm_defs[storm].sem_fast_mem_addr;
	u32 sem_filter_params = filter_type;
	enum dbg_bus_semi_frame_modes framing_mode =
	    dev_data->bus.storms[storm].fast_enabled ?
	    DBG_BUS_SEMI_FRAME_MODE_0SLOW_4FAST :
	    DBG_BUS_SEMI_FRAME_MODE_4SLOW_0FAST;

	/* config framing mode */
	qed_wr(p_hwfn,
	       p_ptt,
	       s_storm_defs[storm].sem_frame_mode_addr, (u8) framing_mode);
	/* config SEM fast debug */
	if (dev_data->bus.storms[storm].fast_enabled) {
		/* enable fast debug: */
		qed_wr(p_hwfn,
		       p_ptt,
		       base_addr + SEM_FAST_REG_DEBUG_MODE,
		       s_storm_mode_defs[dev_data->bus.storms[storm].
					 fast_mode].id_in_hw);
		qed_wr(p_hwfn, p_ptt, base_addr + SEM_FAST_REG_DEBUG_ACTIVE, 1);
		/* enable all messages except STORE. Must be done after enabling SEM_FAST_REG_DEBUG_ACTIVE, otherwise
		 * messages will be dropped after the SEMI sync fifo is filled. */
		qed_wr(p_hwfn,
		       p_ptt,
		       base_addr + SEM_FAST_REG_DBG_MODE6_SRC_DISABLE,
		       SEM_FAST_MODE6_SRC_ENABLE);
	}
	/* config SEM slow debug */
	if (dev_data->bus.storms[storm].slow_enabled) {
		/* ensable slow debug */
		qed_wr(p_hwfn,
		       p_ptt, s_storm_defs[storm].sem_slow_enable_addr, 1);
		qed_wr(p_hwfn,
		       p_ptt,
		       s_storm_defs[storm].sem_slow_mode_addr,
		       s_storm_mode_defs[dev_data->bus.storms[storm].
					 slow_mode].id_in_hw);
		qed_wr(p_hwfn, p_ptt,
		       s_storm_defs[storm].sem_slow_mode1_conf_addr,
		       SEM_SLOW_MODE1_DATA_ENABLE);
	}
	/* config SEM cid filter */
	if (dev_data->bus.storms[storm].cid_filter_en) {
		qed_wr(p_hwfn,
		       p_ptt,
		       base_addr + SEM_FAST_REG_FILTER_CID,
		       dev_data->bus.storms[storm].cid);
		sem_filter_params |= SEM_FILTER_CID_EN_MASK;
	}
	/* config SEM eid filter */
	if (dev_data->bus.storms[storm].eid_filter_en) {
		if (dev_data->bus.storms[storm].eid_range_not_mask) {
			qed_wr(p_hwfn,
			       p_ptt,
			       base_addr + SEM_FAST_REG_EVENT_ID_RANGE_STRT,
			       dev_data->bus.storms[storm].
			       eid_filter_params.range.min);
			qed_wr(p_hwfn, p_ptt,
			       base_addr + SEM_FAST_REG_EVENT_ID_RANGE_END,
			       dev_data->bus.storms[storm].
			       eid_filter_params.range.max);
			sem_filter_params |= SEM_FILTER_EID_RANGE_EN_MASK;
		} else {
			qed_wr(p_hwfn,
			       p_ptt,
			       base_addr + SEM_FAST_REG_FILTER_EVENT_ID,
			       dev_data->bus.storms[storm].
			       eid_filter_params.mask.val);
			qed_wr(p_hwfn, p_ptt,
			       base_addr + SEM_FAST_REG_EVENT_ID_MASK,
			       ~dev_data->bus.storms[storm].
			       eid_filter_params.mask.mask);
			sem_filter_params |= SEM_FILTER_EID_MASK_EN_MASK;
		}
	}
	/* config accumulaed SEM filter parameters (if any) */
	if (sem_filter_params)
		qed_wr(p_hwfn,
		       p_ptt,
		       base_addr + SEM_FAST_REG_RECORD_FILTER_ENABLE,
		       sem_filter_params);
}

/* Disables Debug Bus block inputs */
static enum dbg_status qed_bus_disable_inputs(struct qed_hwfn *p_hwfn,
					      struct qed_ptt *p_ptt,
					      bool empty_semi_fifos)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 block_id, polling_count = 0;
	u32 polling_ms =
	    SEMI_SYNC_FIFO_POLLING_DELAY_MS *
	    s_platform_defs[dev_data->platform_id].delay_factor;
	bool is_fifo_empty[MAX_DBG_STORMS] = { false };
	u8 storm_id, num_fifos_to_empty = MAX_DBG_STORMS;

	/* disable all blocks */
	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++)
		if (s_block_defs[block_id]->has_dbg_bus[dev_data->chip_id] &&
		    !dev_data->block_in_reset[block_id])
			qed_wr(p_hwfn,
			       p_ptt,
			       s_block_defs[block_id]->dbg_cycle_enable_addr,
			       0);
	/* disable messages output in all Storms */
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++)
		if (!dev_data->block_in_reset[s_storm_defs[storm_id].block_id])
			qed_wr(p_hwfn,
			       p_ptt,
			       s_storm_defs[storm_id].sem_fast_mem_addr +
			       SEM_FAST_REG_DBG_MODE6_SRC_DISABLE,
			       SEM_FAST_MODE6_SRC_DISABLE);
	/* try to empty the SEMI sync fifo. Must be done after messages output were disabled in all Storms
	 * (i.e. SEM_FAST_REG_DBG_MODE6_SRC_DISABLE was set to all 1's */
	while (num_fifos_to_empty) {
		for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
			if (!is_fifo_empty[storm_id]) {
				/* check if sync fifo got empty */
				if (dev_data->
				    block_in_reset[s_storm_defs
						   [storm_id].block_id]
				    || qed_rd(p_hwfn, p_ptt,
					      s_storm_defs
					      [storm_id].sem_sync_dbg_empty_addr))
				{
					is_fifo_empty[storm_id] = true;
					num_fifos_to_empty--;
				}
			}
		}
		/* check if need to continue polling */
		if (num_fifos_to_empty) {
			if (empty_semi_fifos && polling_count <
			    SEMI_SYNC_FIFO_POLLING_COUNT) {
				msleep(polling_ms);
				polling_count++;
			} else {
				DP_NOTICE(p_hwfn,
					  "Failed to empty the SEMI sync FIFO. This can happen when the DBG block is blocked (e.g. due to a PCI problem).\n");
				break;
			}
		}
	}
	/* disable debug in all Storms */
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (!dev_data->block_in_reset[s_storm_defs[storm_id].block_id]) {
			u32 base_addr =
			    s_storm_defs[storm_id].sem_fast_mem_addr;
			qed_wr(p_hwfn,
			       p_ptt, base_addr + SEM_FAST_REG_DEBUG_ACTIVE, 0);
			qed_wr(p_hwfn,
			       p_ptt,
			       base_addr + SEM_FAST_REG_RECORD_FILTER_ENABLE,
			       DBG_BUS_FILTER_TYPE_OFF);
			qed_wr(p_hwfn,
			       p_ptt,
			       s_storm_defs[storm_id].sem_frame_mode_addr,
			       DBG_BUS_FRAME_MODE_4HW_0ST);
			qed_wr(p_hwfn,
			       p_ptt,
			       s_storm_defs[storm_id].sem_slow_enable_addr, 0);
		}
	}
	/* disable all clients */
	qed_bus_enable_clients(p_hwfn, p_ptt, 0);
	/* disable timestamp */
	qed_wr(p_hwfn, p_ptt, DBG_REG_TIMESTAMP_VALID_EN, 0);
	/* disable filters and triggers */
	qed_wr(p_hwfn, p_ptt, DBG_REG_FILTER_ENABLE, DBG_BUS_FILTER_TYPE_OFF);
	qed_wr(p_hwfn, p_ptt, DBG_REG_TRIGGER_ENABLE, 0);
	return DBG_STATUS_OK;
}

/* Sets a Debug Bus trigger/filter constraint */
static void qed_bus_set_constraint(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   bool is_filter,
				   u8 constraint_id,
				   u8 hw_op_val,
				   u32 data_val,
				   u32 data_mask,
				   u8 frame_bit,
				   u8 frame_mask,
				   u16 offset,
				   u16 range, u8 cyclic_bit, u8 must_bit)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 reg_offset = constraint_id * BYTES_IN_DWORD;

	if (!is_filter)
		reg_offset +=
		    (dev_data->bus.next_trigger_state -
		     1) * TRIGGER_SETS_PER_STATE * MAX_CONSTRAINTS *
		    BYTES_IN_DWORD;
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_OPRTN_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_OPRTN_0)
	       + reg_offset, hw_op_val);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_DATA_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_DATA_0)
	       + reg_offset, data_val);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_DATA_MASK_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_DATA_MASK_0)
	       + reg_offset, data_mask);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_FRAME_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_FRAME_0)
	       + reg_offset, frame_bit);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_FRAME_MASK_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_FRAME_MASK_0)
	       + reg_offset, frame_mask);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_OFFSET_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_OFFSET_0)
	       + reg_offset, offset);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_RANGE_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_RANGE_0)
	       + reg_offset, range);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_CYCLIC_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_CYCLIC_0)
	       + reg_offset, cyclic_bit);
	qed_wr(p_hwfn,
	       p_ptt,
	       (is_filter ? DBG_REG_FILTER_CNSTR_MUST_0 :
		DBG_REG_TRIGGER_STATE_SET_CNSTR_MUST_0)
	       + reg_offset, must_bit);
}

/* Reads the specified DBG Bus internal buffer range and copy it to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_int_buf_range(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 * dump_buf,
				      bool dump, u32 start_line, u32 end_line)
{
	u32 line, reg_addr, i;
	u32 offset = 0;

	if (dump) {
		for (line = start_line,
		     reg_addr = DBG_REG_INTR_BUFFER +
		     DWORDS_TO_BYTES(start_line *
				     INT_BUF_LINE_SIZE_IN_DWORDS);
		     line <= end_line;
		     line++, offset += INT_BUF_LINE_SIZE_IN_DWORDS)
			for (i = 0; i < INT_BUF_LINE_SIZE_IN_DWORDS;
			     i++, reg_addr += BYTES_IN_DWORD)
				dump_buf[offset + INT_BUF_LINE_SIZE_IN_DWORDS -
					 1 - i] = qed_rd(p_hwfn,
							 p_ptt, reg_addr);
	} else {
		offset +=
		    (end_line - start_line + 1) * INT_BUF_LINE_SIZE_IN_DWORDS;
	}
	return offset;
}

/* Reads the DBG Bus internal buffer and copy its contents to a buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_int_buf(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				u32 * dump_buf, bool dump)
{
	u32 last_written_line = qed_rd(p_hwfn,
				       p_ptt,
				       DBG_REG_INTR_BUFFER_WR_PTR);
	u32 offset = 0;

	if (qed_rd(p_hwfn, p_ptt, DBG_REG_WRAP_ON_INT_BUFFER)) {
		/* internal buffer was wrapped: first dump from write pointer to buffer end, then dump from buffer start to write pointer */
		if (last_written_line < INT_BUF_NUM_OF_LINES - 1)
			offset += qed_bus_dump_int_buf_range(p_hwfn,
							     p_ptt,
							     dump_buf + offset,
							     dump,
							     last_written_line
							     + 1,
							     INT_BUF_NUM_OF_LINES
							     - 1);
		offset += qed_bus_dump_int_buf_range(p_hwfn,
						     p_ptt,
						     dump_buf + offset,
						     dump,
						     0, last_written_line);
	} else if (last_written_line) {
		/* internal buffer wasn't wrapped: dump from buffer start until write pointer */
		if (qed_rd(p_hwfn, p_ptt, DBG_REG_INTR_BUFFER_RD_PTR) == 0)
			offset += qed_bus_dump_int_buf_range(p_hwfn,
							     p_ptt,
							     dump_buf + offset,
							     dump,
							     0,
							     last_written_line);
		else
			DP_NOTICE(p_hwfn,
				  "Unexpected Debug Bus error: internal buffer read pointer is not zero");
	}
	return offset;
}

/* Reads the specified DBG Bus PCI buffer range and copy it to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_pci_buf_range(struct qed_hwfn *p_hwfn,
				      u32 * dump_buf,
				      bool dump, u32 start_line, u32 end_line)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0;

	if (dump) {
		// extract PCI buffer pointer from virtual address
		void *virt_addr_lo = &dev_data->bus.pci_buf.virt_addr.lo;
		u32 *pci_buf_start =
		    (u32 *) (uintptr_t) * ((u64 *) virt_addr_lo);
		u32 *pci_buf, line, i;
		for (line = start_line,
		     pci_buf = pci_buf_start + start_line *
		     PCI_BUF_LINE_SIZE_IN_DWORDS;
		     line <= end_line;
		     line++, offset += PCI_BUF_LINE_SIZE_IN_DWORDS)
			for (i = 0; i < PCI_BUF_LINE_SIZE_IN_DWORDS;
			     i++, pci_buf++)
				dump_buf[offset +
					 s_pci_buf_line_ind[i]] = *pci_buf;
	} else {
		offset +=
		    (end_line - start_line + 1) * PCI_BUF_LINE_SIZE_IN_DWORDS;
	}
	return offset;
}

/* Copies the DBG Bus PCI buffer to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_pci_buf(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 next_wr_byte_offset, next_wr_line_offset;
	u32 pci_buf_size_in_lines =
	    dev_data->bus.pci_buf.size / PCI_BUF_LINE_SIZE_IN_BYTES;
	u32 offset = 0;
	/* extract write pointer (physical address) */
	struct dbg_bus_mem_addr next_wr_phys_addr;

	next_wr_phys_addr.lo = qed_rd(p_hwfn, p_ptt, DBG_REG_EXT_BUFFER_WR_PTR);
	next_wr_phys_addr.hi = qed_rd(p_hwfn,
				      p_ptt,
				      DBG_REG_EXT_BUFFER_WR_PTR +
				      BYTES_IN_DWORD);
	/* convert write pointer to offset */
	next_wr_byte_offset = qed_phys_addr_diff(&next_wr_phys_addr,
						 &dev_data->bus.
						 pci_buf.phys_addr);
	if ((next_wr_byte_offset % PCI_BUF_LINE_SIZE_IN_BYTES)
	    || next_wr_byte_offset > dev_data->bus.pci_buf.size)
		return 0;
	next_wr_line_offset = next_wr_byte_offset / PCI_BUF_LINE_SIZE_IN_BYTES;
	/* If PCI buffer was wrapped: first dump from write pointer to buffer end */
	if (qed_rd(p_hwfn, p_ptt, DBG_REG_WRAP_ON_EXT_BUFFER))
		offset += qed_bus_dump_pci_buf_range(p_hwfn,
						     dump_buf + offset,
						     dump,
						     next_wr_line_offset,
						     pci_buf_size_in_lines - 1);
	/* dump from buffer start until write pointer */
	if (next_wr_line_offset)
		offset += qed_bus_dump_pci_buf_range(p_hwfn,
						     dump_buf + offset,
						     dump,
						     0,
						     next_wr_line_offset - 1);
	return offset;
}

/* Copies the DBG Bus recorded data to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_data(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0;

	if (dev_data->bus.target != DBG_BUS_TARGET_ID_NIG) {
		switch (dev_data->bus.target) {
		case DBG_BUS_TARGET_ID_INT_BUF:
			offset = qed_bus_dump_int_buf(p_hwfn,
						      p_ptt, dump_buf, dump);
			break;
		case DBG_BUS_TARGET_ID_PCI:
			offset = qed_bus_dump_pci_buf(p_hwfn,
						      p_ptt, dump_buf, dump);
			break;
		default:
			break;
		}
	}
	return offset;
}

/* Frees the Debug Bus PCI buffer */
static void qed_bus_free_pci_buf(struct qed_hwfn *p_hwfn)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	if (dev_data->bus.pci_buf.size) {
		// extract PCI buffer pointer from virtual address
		void *virt_addr_lo = &dev_data->bus.pci_buf.virt_addr.lo;
		u32 *pci_buf = (u32 *) (uintptr_t) * ((u64 *) virt_addr_lo);
		dma_addr_t pci_buf_phys_addr;
		memcpy(&pci_buf_phys_addr,
		       &dev_data->bus.pci_buf.phys_addr,
		       sizeof(pci_buf_phys_addr));
		dma_free_coherent(&p_hwfn->cdev->pdev->dev,
				  dev_data->bus.pci_buf.size,
				  pci_buf, pci_buf_phys_addr);
		dev_data->bus.pci_buf.size = 0;
	}
}

/* Dumps the list of DBG Bus inputs (blocks/Storms) to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_inputs(struct qed_hwfn *p_hwfn,
			       u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 block_id;
	u8 storm_id;
	u32 offset = 0;
	char storm_name[8] = "?storm";

	/* store storms */
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (dev_data->bus.storms[storm_id].fast_enabled ||
		    dev_data->bus.storms[storm_id].slow_enabled) {
			/* dump section header */
			storm_name[0] = s_storm_defs[storm_id].letter;
			offset += qed_dump_section_hdr(dump_buf + offset,
						       dump, "bus_input", 3);
			offset += qed_dump_str_param(dump_buf + offset,
						     dump, "name", storm_name);
			offset += qed_dump_num_param(dump_buf + offset,
						     dump,
						     "id",
						     dev_data->
						     bus.storms[storm_id].
						     hw_id);
			if (dev_data->bus.storms[storm_id].fast_enabled
			    && !dev_data->bus.storms[storm_id].slow_enabled)
				offset +=
				    qed_dump_str_param(dump_buf + offset, dump,
						       "mode",
						       s_storm_mode_defs
						       [dev_data->bus.
							storms[storm_id]
							.fast_mode]
						       .name);
			if (!dev_data->bus.storms[storm_id].fast_enabled &&
			    dev_data->bus.storms[storm_id].slow_enabled)
				offset += qed_dump_str_param(dump_buf + offset,
							     dump,
							     "mode",
							     s_storm_mode_defs
							     [dev_data->bus.
							      storms[storm_id]
							      .slow_mode]
							     .name);
			if (dev_data->bus.storms[storm_id].fast_enabled &&
			    dev_data->bus.storms[storm_id].slow_enabled) {
				/* join fast and slow mode names */
				char buf[64];
				u8 fast_mode_name_len =
				    (u8)
				    strlen(s_storm_mode_defs
					   [dev_data->bus.storms[storm_id]
					    .fast_mode].name);
				strcpy(buf,
				       s_storm_mode_defs[dev_data->bus.
							 storms[storm_id]
							 .fast_mode].name);
				buf[fast_mode_name_len] = '+';
				strcpy(buf + fast_mode_name_len + 1,
				       s_storm_mode_defs[dev_data->bus.
							 storms[storm_id]
							 .slow_mode].name);
				offset += qed_dump_str_param(dump_buf + offset,
							     dump, "mode", buf);
			}
		}
	}
	/* store blocks */
	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++) {
		if (dev_data->bus.blocks[block_id].enabled) {
			/* dump section header */
			offset += qed_dump_section_hdr(dump_buf + offset,
						       dump, "bus_input", 5);
			offset += qed_dump_str_param(dump_buf + offset,
						     dump,
						     "name",
						     s_block_defs
						     [block_id]->name);
			offset +=
			    qed_dump_num_param(dump_buf + offset, dump, "id",
					       dev_data->bus.blocks[block_id].
					       hw_id);
			offset +=
			    qed_dump_num_param(dump_buf + offset, dump, "line",
					       dev_data->bus.
					       blocks[block_id].line_num);
			offset +=
			    qed_dump_num_param(dump_buf + offset, dump, "en",
					       dev_data->bus.
					       blocks[block_id].cycle_en);
			offset +=
			    qed_dump_num_param(dump_buf + offset, dump, "shr",
					       dev_data->bus.
					       blocks[block_id].right_shift);
		}
	}
	return offset;
}

/* Dumps the Debug Bus header (params, inputs, data header) to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_bus_dump_hdr(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0;

	/* dump global params */
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 4);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "debug-bus");
	offset += qed_dump_str_param(dump_buf + offset,
				     dump,
				     "wrap-mode",
				     dev_data->bus.one_shot_en ? "one-shot" :
				     "wrap-around");
	offset += qed_dump_num_param(dump_buf + offset,
				     dump,
				     "hw-dwords", dev_data->bus.hw_dwords);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump,
				     "target",
				     s_dbg_target_names[dev_data->bus.target]);
	offset += qed_bus_dump_inputs(p_hwfn, dump_buf + offset, dump);
	if (dev_data->bus.target != DBG_BUS_TARGET_ID_NIG) {
		u32 recorded_dwords = dump ? qed_bus_dump_data(p_hwfn,
							       p_ptt,
							       NULL,
							       false) : 0;
		offset += qed_dump_section_hdr(dump_buf + offset,
					       dump, "bus_data", 1);
		offset += qed_dump_num_param(dump_buf + offset,
					     dump, "size", recorded_dwords);
	}
	return offset;
}

static bool qed_is_mode_match(struct qed_hwfn *p_hwfn, u16 * modes_buf_offset)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u8 tree_val =
	    ((u8 *) s_dbg_arrays[BIN_BUF_DBG_MODE_TREE].ptr)[(*modes_buf_offset)
							     ++];
	bool arg1, arg2;

	switch (tree_val) {
	case INIT_MODE_OP_NOT:
		return !qed_is_mode_match(p_hwfn, modes_buf_offset);
	case INIT_MODE_OP_OR:
	case INIT_MODE_OP_AND:
		arg1 = qed_is_mode_match(p_hwfn, modes_buf_offset);
		arg2 = qed_is_mode_match(p_hwfn, modes_buf_offset);
		return (tree_val == INIT_MODE_OP_OR) ? (arg1 ||
							arg2) : (arg1 && arg2);
	default:
		return dev_data->mode_enable[tree_val - MAX_INIT_MODE_OPS] > 0;
	}
}

/* Sets the value of the specified GRC param */
static void qed_grc_set_param(struct qed_hwfn *p_hwfn,
			      enum dbg_grc_params grc_param, u32 val)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	dev_data->grc.param_val[grc_param] = val;
	dev_data->grc.param_set_by_user[grc_param] = 1;
}

/* Returns the value of the specified GRC param */
static u32 qed_grc_get_param(struct qed_hwfn *p_hwfn,
			     enum dbg_grc_params grc_param)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	return dev_data->grc.param_val[grc_param];
}

/* Clear all GRC params */
static void qed_dbg_grc_clear_params(struct qed_hwfn *p_hwfn)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 i;

	for (i = 0; i < MAX_DBG_GRC_PARAMS; i++)
		dev_data->grc.param_set_by_user[i] = 0;
}

/* Assign default GRC param values */
static void qed_dbg_grc_set_params_default(struct qed_hwfn *p_hwfn)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 i;

	for (i = 0; i < MAX_DBG_GRC_PARAMS; i++)
		if (!dev_data->grc.param_set_by_user[i])
			dev_data->grc.param_val[i] =
			    s_grc_param_defs[i].default_val[dev_data->chip_id];
}

/* Returns true if the specified entity (indicated by GRC param) should be included in the dump, false otherwise. */
static bool qed_grc_is_included(struct qed_hwfn *p_hwfn,
				enum dbg_grc_params grc_param)
{
	return qed_grc_get_param(p_hwfn, grc_param) > 0;
}

/* Returns true of the specified Storm should be included in the dump, false otherwise */
static bool qed_grc_is_storm_included(struct qed_hwfn *p_hwfn,
				      enum dbg_storms storm)
{
	return qed_grc_get_param(p_hwfn, (enum dbg_grc_params)storm) > 0;
}

/* Returns true if the specified memory should be included in the dump, false otherwise */
static bool qed_grc_is_mem_included(struct qed_hwfn *p_hwfn,
				    enum block_id block_id, u8 mem_group_id)
{
	u8 i;

	/* check Storm match */
	if (s_block_defs[block_id]->associated_to_storm &&
	    !qed_grc_is_storm_included(p_hwfn,
				       (enum dbg_storms)s_block_defs[block_id]
				       ->storm_id))
		return false;
	for (i = 0; i < NUM_BIG_RAM_TYPES; i++)
		if (mem_group_id == s_big_ram_defs[i].mem_group_id ||
		    mem_group_id == s_big_ram_defs[i].ram_mem_group_id)
			return qed_grc_is_included(p_hwfn,
						   s_big_ram_defs[i].grc_param);
	if (mem_group_id == MEM_GROUP_PXP_ILT || mem_group_id ==
	    MEM_GROUP_PXP_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_PXP);
	if (mem_group_id == MEM_GROUP_RAM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_RAM);
	if (mem_group_id == MEM_GROUP_PBUF)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_PBUF);
	if (mem_group_id == MEM_GROUP_CAU_MEM ||
	    mem_group_id == MEM_GROUP_CAU_SB ||
	    mem_group_id == MEM_GROUP_CAU_PI)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_CAU);
	if (mem_group_id == MEM_GROUP_QM_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_QM);
	if (mem_group_id == MEM_GROUP_CONN_CFC_MEM ||
	    mem_group_id == MEM_GROUP_TASK_CFC_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_CFC);
	if (mem_group_id == MEM_GROUP_IGU_MEM || mem_group_id ==
	    MEM_GROUP_IGU_MSIX)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_IGU);
	if (mem_group_id == MEM_GROUP_MULD_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_MULD);
	if (mem_group_id == MEM_GROUP_PRS_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_PRS);
	if (mem_group_id == MEM_GROUP_DMAE_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_DMAE);
	if (mem_group_id == MEM_GROUP_TM_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_TM);
	if (mem_group_id == MEM_GROUP_SDM_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_SDM);
	if (mem_group_id == MEM_GROUP_TDIF_CTX || mem_group_id ==
	    MEM_GROUP_RDIF_CTX)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_DIF);
	if (mem_group_id == MEM_GROUP_CM_MEM)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_CM);
	if (mem_group_id == MEM_GROUP_IOR)
		return qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_IOR);
	return true;
}

/* Stalls all Storms */
static void qed_grc_stall_storms(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt, bool stall)
{
	u8 reg_val = stall ? 1 : 0;
	u8 storm_id;

	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (qed_grc_is_storm_included(p_hwfn,
					      (enum dbg_storms)storm_id)) {
			u32 reg_addr =
			    s_storm_defs[storm_id].sem_fast_mem_addr +
			    SEM_FAST_REG_STALL_0;
			qed_wr(p_hwfn, p_ptt, reg_addr, reg_val);
		}
	}
	msleep(STALL_DELAY_MS);
}

/* Takes all blocks out of reset */
static void qed_grc_unreset_blocks(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 i;
	u32 reg_val[MAX_DBG_RESET_REGS] = { 0 };

	/* fill reset regs values */
	for (i = 0; i < MAX_BLOCK_ID; i++)
		if (s_block_defs[i]->has_reset_bit && s_block_defs[i]->unreset)
			reg_val[s_block_defs[i]->reset_reg] |=
			    BIT(s_block_defs[i]->reset_bit_offset);
	/* write reset registers */
	for (i = 0; i < MAX_DBG_RESET_REGS; i++) {
		if (s_reset_regs_defs[i].exists[dev_data->chip_id]) {
			reg_val[i] |= s_reset_regs_defs[i].unreset_val;
			if (reg_val[i])
				qed_wr(p_hwfn,
				       p_ptt,
				       s_reset_regs_defs[i].addr +
				       RESET_REG_UNRESET_OFFSET, reg_val[i]);
		}
	}
}

/* returns the attention name offsets of the specified block */
static const struct dbg_attn_block_type_data *qed_get_block_attn_data(enum
								      block_id
								      block_id,
								      enum
								      dbg_attn_type
								      attn_type)
{
	const struct dbg_attn_block *base_attn_block_arr =
	    (const struct dbg_attn_block *)
	    s_dbg_arrays[BIN_BUF_DBG_ATTN_BLOCKS].ptr;

	return &base_attn_block_arr[block_id].per_type_data[attn_type];
}

/* returns the attention registers of the specified block */
static const struct dbg_attn_reg *qed_get_block_attn_regs(enum block_id
							  block_id,
							  enum dbg_attn_type
							  attn_type,
							  u8 * num_attn_regs)
{
	const struct dbg_attn_block_type_data *block_type_data =
	    qed_get_block_attn_data(block_id, attn_type);

	*num_attn_regs = block_type_data->num_regs;
	return &((const struct dbg_attn_reg *)
		 s_dbg_arrays[BIN_BUF_DBG_ATTN_REGS].
		 ptr)[block_type_data->regs_offset];
}

/* for each block, clear the status of all parities */
static void qed_grc_clear_all_prty(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 block_id;
	u8 reg_idx, num_attn_regs;

	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++) {
		if (!dev_data->block_in_reset[block_id]) {
			const struct dbg_attn_reg *attn_reg_arr =
			    qed_get_block_attn_regs((enum block_id)block_id,
						    ATTN_TYPE_PARITY,
						    &num_attn_regs);
			for (reg_idx = 0; reg_idx < num_attn_regs; reg_idx++) {
				const struct dbg_attn_reg *reg_data =
				    &attn_reg_arr[reg_idx];
				// check mode
				bool eval_mode = GET_FIELD(reg_data->mode.data,
							   DBG_MODE_HDR_EVAL_MODE)
				    > 0;
				u16 modes_buf_offset =
				    GET_FIELD(reg_data->mode.data,
					      DBG_MODE_HDR_MODES_BUF_OFFSET);
				if (!eval_mode
				    || qed_is_mode_match(p_hwfn,
							 &modes_buf_offset))
					// mode match - read parity status read-clear register
					qed_rd(p_hwfn, p_ptt,
					       DWORDS_TO_BYTES
					       (reg_data->sts_clr_address));
			}
		}
	}
}

/* Dumps GRC registers section header. Returns the dumped size in dwords.
 * the following parameters are dumped:
 * - 'count' = num_dumped_entries
 * - 'split' = split_type
 * - 'id'	 = split_id (dumped only if split_id >= 0)
 * - 'param_name' = param_val (user param, dumped only if param_name != NULL and param_val != NULL)
 */
static u32 qed_grc_dump_regs_hdr(u32 * dump_buf,
				 bool dump,
				 u32 num_reg_entries,
				 const char *split_type,
				 int split_id,
				 const char *param_name, const char *param_val)
{
	u8 num_params = 2 + (split_id >= 0 ? 1 : 0) + (param_name ? 1 : 0);
	u32 offset = 0;

	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "grc_regs", num_params);
	offset += qed_dump_num_param(dump_buf + offset,
				     dump, "count", num_reg_entries);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "split", split_type);
	if (split_id >= 0)
		offset += qed_dump_num_param(dump_buf + offset,
					     dump, "id", split_id);
	if (param_name && param_val)
		offset += qed_dump_str_param(dump_buf + offset,
					     dump, param_name, param_val);
	return offset;
}

/* Dumps GRC register/memory. Returns the dumped size in dwords. */
static u32 qed_grc_dump_reg_entry(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 * dump_buf, bool dump, u32 addr,	/* in dwords */
				  u32 len)
{				/* in dwords */
	u32 offset = 0, i;

	if (dump) {
		*(dump_buf + offset++) = addr | (len << REG_DUMP_LEN_SHIFT);
		for (i = 0; i < len; i++, addr++, offset++)
			*(dump_buf + offset) = qed_rd(p_hwfn,
						      p_ptt,
						      DWORDS_TO_BYTES(addr));
	} else {
		offset += len + 1;
	}
	return offset;
}

/* Dumps GRC registers entries. Returns the dumped size in dwords. */
static u32 qed_grc_dump_regs_entries(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     struct dbg_array input_regs_arr,
				     u32 * dump_buf,
				     bool dump,
				     bool block_enable[MAX_BLOCK_ID],
				     u32 * num_dumped_reg_entries)
{
	u32 i, offset = 0, input_offset = 0;
	bool mode_match = true;

	*num_dumped_reg_entries = 0;
	while (input_offset < input_regs_arr.size_in_dwords) {
		const struct dbg_dump_cond_hdr *cond_hdr =
		    (const struct dbg_dump_cond_hdr *)&input_regs_arr.
		    ptr[input_offset++];
		bool eval_mode = GET_FIELD(cond_hdr->mode.data,
					   DBG_MODE_HDR_EVAL_MODE) > 0;
		// check mode/block
		if (eval_mode) {
			u16 modes_buf_offset = GET_FIELD(cond_hdr->mode.data,
							 DBG_MODE_HDR_MODES_BUF_OFFSET);
			mode_match = qed_is_mode_match(p_hwfn,
						       &modes_buf_offset);
		}
		if (mode_match && block_enable[cond_hdr->block_id]) {
			for (i = 0; i < cond_hdr->data_size;
			     i++, input_offset++) {
				const struct dbg_dump_reg *reg =
				    (const struct dbg_dump_reg *)
				    &input_regs_arr.ptr[input_offset];
				offset +=
				    qed_grc_dump_reg_entry(p_hwfn, p_ptt,
							   dump_buf + offset,
							   dump,
							   GET_FIELD(reg->data,
								     DBG_DUMP_REG_ADDRESS),
							   GET_FIELD(reg->data,
								     DBG_DUMP_REG_LENGTH));
				(*num_dumped_reg_entries)++;
			}
		} else {
			input_offset += cond_hdr->data_size;
		}
	}
	return offset;
}

/* Dumps GRC registers entries. Returns the dumped size in dwords. */
static u32 qed_grc_dump_split_data(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   struct dbg_array input_regs_arr,
				   u32 * dump_buf,
				   bool dump,
				   bool block_enable[MAX_BLOCK_ID],
				   const char *split_type_name,
				   u32 split_id,
				   const char *param_name,
				   const char *param_val)
{
	u32 num_dumped_reg_entries, offset;

	// calculate register dump header size (and skip it for now)
	offset = qed_grc_dump_regs_hdr(dump_buf,
				       false,
				       0,
				       split_type_name,
				       split_id, param_name, param_val);
	// dump registers
	offset += qed_grc_dump_regs_entries(p_hwfn,
					    p_ptt,
					    input_regs_arr,
					    dump_buf + offset,
					    dump,
					    block_enable,
					    &num_dumped_reg_entries);
	// write register dump header
	if (dump && num_dumped_reg_entries > 0)
		qed_grc_dump_regs_hdr(dump_buf,
				      dump,
				      num_dumped_reg_entries,
				      split_type_name,
				      split_id, param_name, param_val);
	return num_dumped_reg_entries > 0 ? offset : 0;
}

/* Dumps registers according to the input registers array. Returns the dumped size in dwords. */
static u32 qed_grc_dump_registers(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  u32 * dump_buf,
				  bool dump,
				  bool block_enable[MAX_BLOCK_ID],
				  const char *param_name, const char *param_val)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u8 port_id, pf_id;
	u32 offset = 0, input_offset = 0;

	if (dump)
		DP_VERBOSE(p_hwfn, QED_MSG_DEBUG, "Dumping registers...\n");
	while (input_offset < s_dbg_arrays[BIN_BUF_DBG_DUMP_REG].size_in_dwords) {
		const struct dbg_dump_split_hdr *split_hdr =
		    (const struct dbg_dump_split_hdr *)
		    &s_dbg_arrays[BIN_BUF_DBG_DUMP_REG].ptr[input_offset++];
		u8 split_type_id = GET_FIELD(split_hdr->hdr,
					     DBG_DUMP_SPLIT_HDR_SPLIT_TYPE_ID);
		u32 split_data_size =
		    GET_FIELD(split_hdr->hdr, DBG_DUMP_SPLIT_HDR_DATA_SIZE);
		struct dbg_array curr_input_regs_arr =
		    { &s_dbg_arrays[BIN_BUF_DBG_DUMP_REG].ptr[input_offset],
			split_data_size
		};
		switch (split_type_id) {
		case SPLIT_TYPE_NONE:
		case SPLIT_TYPE_VF:
			offset += qed_grc_dump_split_data(p_hwfn,
							  p_ptt,
							  curr_input_regs_arr,
							  dump_buf + offset,
							  dump,
							  block_enable,
							  "eng",
							  (u32) (-1),
							  param_name,
							  param_val);
			break;
		case SPLIT_TYPE_PORT:
			for (port_id = 0;
			     port_id <
			     s_chip_defs[dev_data->chip_id].
			     per_platform[dev_data->platform_id].num_ports;
			     port_id++) {
				if (dump)
					qed_port_pretend(p_hwfn, p_ptt,
							 port_id);
				offset +=
				    qed_grc_dump_split_data(p_hwfn, p_ptt,
							    curr_input_regs_arr,
							    dump_buf + offset,
							    dump, block_enable,
							    "port", port_id,
							    param_name,
							    param_val);
			}
			break;
		case SPLIT_TYPE_PF:
		case SPLIT_TYPE_PORT_PF:
			for (pf_id = 0;
			     pf_id <
			     s_chip_defs[dev_data->chip_id].
			     per_platform[dev_data->platform_id].num_pfs;
			     pf_id++) {
				if (dump)
					qed_fid_pretend(p_hwfn, p_ptt, pf_id);
				offset += qed_grc_dump_split_data(p_hwfn,
								  p_ptt,
								  curr_input_regs_arr,
								  dump_buf +
								  offset,
								  dump,
								  block_enable,
								  "pf",
								  pf_id,
								  param_name,
								  param_val);
			}
			break;
		default:
			break;
		}
		input_offset += split_data_size;
	}
	/* pretend to original PF */
	if (dump)
		qed_fid_pretend(p_hwfn, p_ptt, p_hwfn->rel_pf_id);
	return offset;
}

/* Dump reset registers. Returns the dumped size in dwords. */
static u32 qed_grc_dump_reset_regs(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 i, offset = 0, num_regs = 0;

	/* calculate header size */
	offset += qed_grc_dump_regs_hdr(dump_buf,
					false, 0, "eng", -1, NULL, NULL);
	/* write reset registers */
	for (i = 0; i < MAX_DBG_RESET_REGS; i++) {
		if (s_reset_regs_defs[i].exists[dev_data->chip_id]) {
			offset += qed_grc_dump_reg_entry(p_hwfn,
							 p_ptt,
							 dump_buf + offset,
							 dump,
							 BYTES_TO_DWORDS
							 (s_reset_regs_defs[i].
							  addr), 1);
			num_regs++;
		}
	}
	/* write header */
	if (dump)
		qed_grc_dump_regs_hdr(dump_buf,
				      true, num_regs, "eng", -1, NULL, NULL);
	return offset;
}

/* Dump registers that are modified during GRC Dump and therefore must be dumped first. Returns the dumped size in dwords. */
static u32 qed_grc_dump_modified_regs(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0, num_reg_entries = 0, block_id;
	u8 storm_id, reg_idx, num_attn_regs;

	/* calculate header size */
	offset += qed_grc_dump_regs_hdr(dump_buf,
					false, 0, "eng", -1, NULL, NULL);
	/* write parity registers */
	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++) {
		if (!dev_data->block_in_reset[block_id] || !dump) {
			const struct dbg_attn_reg *attn_reg_arr =
			    qed_get_block_attn_regs((enum block_id)block_id,
						    ATTN_TYPE_PARITY,
						    &num_attn_regs);
			for (reg_idx = 0; reg_idx < num_attn_regs; reg_idx++) {
				const struct dbg_attn_reg *reg_data =
				    &attn_reg_arr[reg_idx];
				// check mode
				bool eval_mode = GET_FIELD(reg_data->mode.data,
							   DBG_MODE_HDR_EVAL_MODE)
				    > 0;
				u16 modes_buf_offset =
				    GET_FIELD(reg_data->mode.data,
					      DBG_MODE_HDR_MODES_BUF_OFFSET);
				if (!eval_mode
				    || qed_is_mode_match(p_hwfn,
							 &modes_buf_offset)) {
					// mode match - read and dump registers
					offset +=
					    qed_grc_dump_reg_entry(p_hwfn,
								   p_ptt,
								   dump_buf
								   + offset,
								   dump,
								   reg_data->
								   mask_address,
								   1);
					offset +=
					    qed_grc_dump_reg_entry(p_hwfn,
								   p_ptt,
								   dump_buf +
								   offset, dump,
								   GET_FIELD
								   (reg_data->
								    data,
								    DBG_ATTN_REG_STS_ADDRESS),
								   1);
					num_reg_entries += 2;
				}
			}
		}
	}
	/* write Storm stall status registers */
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (!dev_data->block_in_reset[s_storm_defs[storm_id].block_id]
		    || !dump) {
			offset += qed_grc_dump_reg_entry(p_hwfn,
							 p_ptt,
							 dump_buf + offset,
							 dump,
							 BYTES_TO_DWORDS
							 (s_storm_defs
							  [storm_id].sem_fast_mem_addr
							  +
							  SEM_FAST_REG_STALLED),
							 1);
			num_reg_entries++;
		}
	}
	/* write header */
	if (dump)
		qed_grc_dump_regs_hdr(dump_buf,
				      true,
				      num_reg_entries, "eng", -1, NULL, NULL);
	return offset;
}

/* Dumps a GRC memory header (section and params). The following parameters are dumped:
 * name			- name is dumped only if it's not NULL.
 * addr			- byte_addr is dumped only if name is NULL.
 * len			- dword_len is always dumped.
 * width		- bit_width is dumped if it's not zero.
 * packed		- packed=1 is dumped if it's not false.
 * mem_group	- mem_group is always dumped.
 * is_storm		- true only if the memory is related to a Storm.
 * storm_letter	- storm letter (valid only if is_storm is true).
 * Returns the dumped size in dwords.
 */
static u32 qed_grc_dump_mem_hdr(struct qed_hwfn *p_hwfn,
				u32 * dump_buf,
				bool dump,
				const char *name,
				u32 byte_addr,
				u32 dword_len,
				u32 bit_width,
				bool packed,
				const char *mem_group,
				bool is_storm, char storm_letter)
{
	char buf[64];
	u8 num_params = 3;
	u32 offset = 0;

	if (dword_len == 0)
		DP_NOTICE(p_hwfn,
			  "Unexpected GRC Dump error: dumped memory size must be non-zero");
	if (bit_width)
		num_params++;
	if (packed)
		num_params++;
	/* dump section header */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "grc_mem", num_params);
	if (name) {
		/* dump name */
		if (is_storm) {
			strcpy(buf, "?STORM_");
			buf[0] = storm_letter;
			strcpy(buf + strlen(buf), name);
		} else {
			strcpy(buf, name);
		}
		offset += qed_dump_str_param(dump_buf + offset,
					     dump, "name", buf);
		if (dump)
			DP_VERBOSE(p_hwfn,
				   QED_MSG_DEBUG,
				   "Dumping %d registers from %s...\n",
				   dword_len, buf);
	} else {
		/* dump address */
		offset += qed_dump_num_param(dump_buf + offset,
					     dump, "addr", byte_addr);
		if (dump && dword_len > 64)
			DP_VERBOSE(p_hwfn,
				   QED_MSG_DEBUG,
				   "Dumping %d registers from address 0x%x...\n",
				   dword_len, byte_addr);
	}
	/* dump len */
	offset += qed_dump_num_param(dump_buf + offset, dump, "len", dword_len);
	/* dump bit width */
	if (bit_width)
		offset += qed_dump_num_param(dump_buf + offset,
					     dump, "width", bit_width);
	/* dump packed */
	if (packed)
		offset += qed_dump_num_param(dump_buf + offset,
					     dump, "packed", 1);
	/* dump reg type */
	if (is_storm) {
		strcpy(buf, "?STORM_");
		buf[0] = storm_letter;
		strcpy(buf + strlen(buf), mem_group);
	} else {
		strcpy(buf, mem_group);
	}
	offset += qed_dump_str_param(dump_buf + offset, dump, "type", buf);
	return offset;
}

/* Dumps a single GRC memory. If name is NULL, the memory is stored by address. Returns the dumped size in dwords. */
static u32 qed_grc_dump_mem(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt,
			    u32 * dump_buf,
			    bool dump,
			    const char *name,
			    u32 byte_addr,
			    u32 dword_len,
			    u32 bit_width,
			    bool packed,
			    const char *mem_group,
			    bool is_storm, char storm_letter)
{
	u32 offset = 0;

	offset += qed_grc_dump_mem_hdr(p_hwfn,
				       dump_buf + offset,
				       dump,
				       name,
				       byte_addr,
				       dword_len,
				       bit_width,
				       packed,
				       mem_group, is_storm, storm_letter);
	if (dump) {
		u32 i;
		for (i = 0; i < dword_len;
		     i++, byte_addr += BYTES_IN_DWORD, offset++)
			*(dump_buf + offset) = qed_rd(p_hwfn, p_ptt, byte_addr);
	} else {
		offset += dword_len;
	}
	return offset;
}

/* Dumps GRC memories entries. Returns the dumped size in dwords. */
static u32 qed_grc_dump_mem_entries(struct qed_hwfn *p_hwfn,
				    struct qed_ptt *p_ptt,
				    struct dbg_array input_mems_arr,
				    u32 * dump_buf, bool dump)
{
	u32 i, offset = 0, input_offset = 0;
	bool mode_match = true;

	while (input_offset < input_mems_arr.size_in_dwords) {
		const struct dbg_dump_cond_hdr *cond_hdr =
		    (const struct dbg_dump_cond_hdr *)&input_mems_arr.
		    ptr[input_offset++];
		bool eval_mode = GET_FIELD(cond_hdr->mode.data,
					   DBG_MODE_HDR_EVAL_MODE) > 0;
		// check required mode
		if (eval_mode) {
			u16 modes_buf_offset = GET_FIELD(cond_hdr->mode.data,
							 DBG_MODE_HDR_MODES_BUF_OFFSET);
			mode_match = qed_is_mode_match(p_hwfn,
						       &modes_buf_offset);
		}
		if (mode_match) {
			u32 num_entries = cond_hdr->data_size /
			    MEM_DUMP_ENTRY_SIZE_DWORDS;
			for (i = 0; i < num_entries;
			     i++, input_offset += MEM_DUMP_ENTRY_SIZE_DWORDS) {
				const struct dbg_dump_mem *mem
				    =
				    (const struct dbg_dump_mem *)
				    &input_mems_arr.ptr[input_offset];
				u8 mem_group_id = GET_FIELD(mem->dword0,
							    DBG_DUMP_MEM_MEM_GROUP_ID);
				if (mem_group_id >= MEM_GROUPS_NUM) {
					DP_NOTICE(p_hwfn,
						  "Invalid mem_group_id");
					return 0;
				}
				if (qed_grc_is_mem_included(p_hwfn,
							    (enum block_id)
							    cond_hdr->block_id,
							    mem_group_id)) {
					u32 mem_byte_addr =
					    DWORDS_TO_BYTES(GET_FIELD
							    (mem->dword0,
							     DBG_DUMP_MEM_ADDRESS));
					u32 mem_len = GET_FIELD(mem->dword1,
								DBG_DUMP_MEM_LENGTH);
					bool is_storm = false;
					char storm_letter = 'a';
					// update memory length for CCFC/TCFC memories according to number of LCIDs/LTIDs
					if (mem_group_id ==
					    MEM_GROUP_CONN_CFC_MEM)
						mem_len =
						    qed_grc_get_param(p_hwfn,
								      DBG_GRC_PARAM_NUM_LCIDS)
						    * (mem_len / MAX_LCIDS);
					else if (mem_group_id ==
						 MEM_GROUP_TASK_CFC_MEM)
						mem_len =
						    qed_grc_get_param(p_hwfn,
								      DBG_GRC_PARAM_NUM_LTIDS)
						    * (mem_len / MAX_LTIDS);
					// if memory is associated with Storm, udpate Storm details
					if (s_block_defs
					    [cond_hdr->
					     block_id]->associated_to_storm) {
						is_storm = true;
						storm_letter =
						    s_storm_defs[s_block_defs
								 [cond_hdr->block_id]->
								 storm_id].letter;
					}
					// dump memory
					offset += qed_grc_dump_mem(p_hwfn,
								   p_ptt,
								   dump_buf +
								   offset,
								   dump,
								   NULL,
								   mem_byte_addr,
								   mem_len,
								   0,
								   false,
								   s_mem_group_names
								   [mem_group_id],
								   is_storm,
								   storm_letter);
				}
			}
		} else {
			input_offset += cond_hdr->data_size;
		}
	}
	return offset;
}

/* Dumps GRC memories according to the input array dump_mem. Returns the dumped size in dwords. */
static u32 qed_grc_dump_memories(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 u32 * dump_buf, bool dump)
{
	u32 offset = 0, input_offset = 0;

	while (input_offset < s_dbg_arrays[BIN_BUF_DBG_DUMP_MEM].size_in_dwords) {
		const struct dbg_dump_split_hdr *split_hdr =
		    (const struct dbg_dump_split_hdr *)
		    &s_dbg_arrays[BIN_BUF_DBG_DUMP_MEM].ptr[input_offset++];
		u8 split_type_id = GET_FIELD(split_hdr->hdr,
					     DBG_DUMP_SPLIT_HDR_SPLIT_TYPE_ID);
		u32 split_data_size =
		    GET_FIELD(split_hdr->hdr, DBG_DUMP_SPLIT_HDR_DATA_SIZE);
		struct dbg_array curr_input_mems_arr =
		    { &s_dbg_arrays[BIN_BUF_DBG_DUMP_MEM].ptr[input_offset],
			split_data_size
		};
		switch (split_type_id) {
		case SPLIT_TYPE_NONE:
			offset += qed_grc_dump_mem_entries(p_hwfn,
							   p_ptt,
							   curr_input_mems_arr,
							   dump_buf + offset,
							   dump);
			break;
		default:
			DP_NOTICE(p_hwfn,
				  "Dumping split memories is currently not supported");
			break;
		}
		input_offset += split_data_size;
	}
	return offset;
}

/* Dumps GRC context data for the specified Storm. Returns the dumped size in dwords. */
static u32 qed_grc_dump_ctx_data(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 * dump_buf, bool dump, const char *name, u32 num_lids, u32 lid_size,	/* in quad-regs */
				 u32 rd_reg_addr, u8 storm_id)
{
	u32 i, lid, total_size;
	u32 offset = 0;

	if (!lid_size)
		return 0;
	lid_size *= BYTES_IN_DWORD;
	total_size = num_lids * lid_size;
	offset += qed_grc_dump_mem_hdr(p_hwfn,
				       dump_buf + offset,
				       dump,
				       name,
				       0,
				       total_size,
				       lid_size * 32,
				       false,
				       name,
				       true, s_storm_defs[storm_id].letter);
	/* dump context data */
	if (dump) {
		for (lid = 0; lid < num_lids; lid++) {
			for (i = 0; i < lid_size; i++, offset++) {
				qed_wr(p_hwfn,
				       p_ptt,
				       s_storm_defs[storm_id].cm_ctx_wr_addr,
				       (i << 9) | lid);
				*(dump_buf + offset) = qed_rd(p_hwfn,
							      p_ptt,
							      rd_reg_addr);
			}
		}
	} else {
		offset += total_size;
	}
	return offset;
}

/* Dumps GRC contexts. Returns the dumped size in dwords. */
static u32 qed_grc_dump_ctx(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	u8 storm_id;
	u32 offset = 0;

	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (qed_grc_is_storm_included(p_hwfn,
					      (enum dbg_storms)storm_id)) {
			/* dump Conn AG context size */
			offset += qed_grc_dump_ctx_data(p_hwfn,
							p_ptt,
							dump_buf + offset,
							dump,
							"CONN_AG_CTX",
							qed_grc_get_param
							(p_hwfn,
							 DBG_GRC_PARAM_NUM_LCIDS),
							s_storm_defs
							[storm_id].cm_conn_ag_ctx_lid_size,
							s_storm_defs
							[storm_id].cm_conn_ag_ctx_rd_addr,
							storm_id);
			/* dump Conn ST context size */
			offset += qed_grc_dump_ctx_data(p_hwfn,
							p_ptt,
							dump_buf + offset,
							dump,
							"CONN_ST_CTX",
							qed_grc_get_param
							(p_hwfn,
							 DBG_GRC_PARAM_NUM_LCIDS),
							s_storm_defs
							[storm_id].cm_conn_st_ctx_lid_size,
							s_storm_defs
							[storm_id].cm_conn_st_ctx_rd_addr,
							storm_id);
			/* dump Task AG context size */
			offset += qed_grc_dump_ctx_data(p_hwfn,
							p_ptt,
							dump_buf + offset,
							dump,
							"TASK_AG_CTX",
							qed_grc_get_param
							(p_hwfn,
							 DBG_GRC_PARAM_NUM_LTIDS),
							s_storm_defs
							[storm_id].cm_task_ag_ctx_lid_size,
							s_storm_defs
							[storm_id].cm_task_ag_ctx_rd_addr,
							storm_id);
			/* dump Task ST context size */
			offset += qed_grc_dump_ctx_data(p_hwfn,
							p_ptt,
							dump_buf + offset,
							dump,
							"TASK_ST_CTX",
							qed_grc_get_param
							(p_hwfn,
							 DBG_GRC_PARAM_NUM_LTIDS),
							s_storm_defs
							[storm_id].cm_task_st_ctx_lid_size,
							s_storm_defs
							[storm_id].cm_task_st_ctx_rd_addr,
							storm_id);
		}
	}
	return offset;
}

/* Dumps GRC IORs data. Returns the dumped size in dwords. */
static u32 qed_grc_dump_iors(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	u8 storm_id, set_id;
	u32 offset = 0;
	char buf[10] = "IOR_SET_?";

	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (qed_grc_is_storm_included(p_hwfn,
					      (enum dbg_storms)storm_id)) {
			for (set_id = 0; set_id < NUM_IOR_SETS; set_id++) {
				u32 addr =
				    s_storm_defs[storm_id].sem_fast_mem_addr +
				    SEM_FAST_REG_STORM_REG_FILE +
				    DWORDS_TO_BYTES(IOR_SET_OFFSET(set_id));
				buf[strlen(buf) - 1] = '0' + set_id;
				offset += qed_grc_dump_mem(p_hwfn,
							   p_ptt,
							   dump_buf + offset,
							   dump,
							   buf,
							   addr,
							   IORS_PER_SET,
							   32,
							   false,
							   "ior",
							   true,
							   s_storm_defs
							   [storm_id].letter);
			}
		}
	}
	return offset;
}

/* Dump VFC CAM. Returns the dumped size in dwords. */
static u32 qed_grc_dump_vfc_cam(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				u32 * dump_buf, bool dump, u8 storm_id)
{
	u32 row, i;
	u32 cam_cmd[VFC_CAM_CMD_DWORDS] = { 0 };
	u32 cam_addr[VFC_CAM_ADDR_DWORDS] = { 0 };
	u32 total_size = VFC_CAM_NUM_ROWS * VFC_CAM_RESP_DWORDS;
	u32 offset = 0;

	offset += qed_grc_dump_mem_hdr(p_hwfn,
				       dump_buf + offset,
				       dump,
				       "vfc_cam",
				       0,
				       total_size,
				       256,
				       false,
				       "vfc_cam",
				       true, s_storm_defs[storm_id].letter);
	if (dump) {
		/* prepare CAM address */
		SET_VAR_FIELD(cam_addr, VFC_CAM_ADDR, OP, VFC_OPCODE_CAM_RD);
		for (row = 0; row < VFC_CAM_NUM_ROWS;
		     row++, offset += VFC_CAM_RESP_DWORDS) {
			/* write VFC CAM command */
			SET_VAR_FIELD(cam_cmd, VFC_CAM_CMD, ROW, row);
			ARR_REG_WR(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_DATA_WR,
				   cam_cmd, VFC_CAM_CMD_DWORDS);
			/* write VFC CAM address */
			ARR_REG_WR(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_ADDR,
				   cam_addr, VFC_CAM_ADDR_DWORDS);
			/* read VFC CAM read response */
			ARR_REG_RD(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_DATA_RD,
				   dump_buf + offset, VFC_CAM_RESP_DWORDS);
		}
	} else {
		offset += total_size;
	}
	return offset;
}

/* Dump VFC RAM. Returns the dumped size in dwords. */
static u32 qed_grc_dump_vfc_ram(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				u32 * dump_buf,
				bool dump,
				u8 storm_id, struct vfc_ram_defs *ram_defs)
{
	u32 row, i;
	u32 ram_cmd[VFC_RAM_CMD_DWORDS] = { 0 };
	u32 ram_addr[VFC_RAM_ADDR_DWORDS] = { 0 };
	u32 total_size = ram_defs->num_rows * VFC_RAM_RESP_DWORDS;
	u32 offset = 0;

	offset += qed_grc_dump_mem_hdr(p_hwfn,
				       dump_buf + offset,
				       dump,
				       ram_defs->mem_name,
				       0,
				       total_size,
				       256,
				       false,
				       ram_defs->type_name,
				       true, s_storm_defs[storm_id].letter);
	/* prepare RAM address */
	SET_VAR_FIELD(ram_addr, VFC_RAM_ADDR, OP, VFC_OPCODE_RAM_RD);
	if (dump) {
		for (row = ram_defs->base_row;
		     row < ram_defs->base_row + ram_defs->num_rows;
		     row++, offset += VFC_RAM_RESP_DWORDS) {
			/* write VFC RAM command */
			ARR_REG_WR(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_DATA_WR,
				   ram_cmd, VFC_RAM_CMD_DWORDS);
			/* write VFC RAM address */
			SET_VAR_FIELD(ram_addr, VFC_RAM_ADDR, ROW, row);
			ARR_REG_WR(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_ADDR,
				   ram_addr, VFC_RAM_ADDR_DWORDS);
			/* read VFC RAM read response */
			ARR_REG_RD(p_hwfn,
				   p_ptt,
				   s_storm_defs[storm_id].sem_fast_mem_addr +
				   SEM_FAST_REG_VFC_DATA_RD,
				   dump_buf + offset, VFC_RAM_RESP_DWORDS);
		}
	} else {
		offset += total_size;
	}
	return offset;
}

/* Dumps GRC VFC data. Returns the dumped size in dwords. */
static u32 qed_grc_dump_vfc(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u8 storm_id, i;
	u32 offset = 0;

	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		if (qed_grc_is_storm_included(p_hwfn,
					      (enum dbg_storms)storm_id) &&
		    s_storm_defs[storm_id].has_vfc &&
		    (storm_id != DBG_PSTORM_ID || dev_data->platform_id ==
		     PLATFORM_ASIC)) {
			/* read CAM */
			offset += qed_grc_dump_vfc_cam(p_hwfn,
						       p_ptt,
						       dump_buf + offset,
						       dump, storm_id);
			/* read RAM */
			for (i = 0; i < NUM_VFC_RAM_TYPES; i++)
				offset += qed_grc_dump_vfc_ram(p_hwfn,
							       p_ptt,
							       dump_buf +
							       offset,
							       dump,
							       storm_id,
							       &s_vfc_ram_defs
							       [i]);
		}
	}
	return offset;
}

/* Dumps GRC RSS data. Returns the dumped size in dwords. */
static u32 qed_grc_dump_rss(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u8 rss_mem_id;
	u32 offset = 0;

	for (rss_mem_id = 0; rss_mem_id < NUM_RSS_MEM_TYPES; rss_mem_id++) {
		u32 i, j;
		struct rss_mem_defs *rss_defs = &s_rss_mem_defs[rss_mem_id];
		u32 addr = rss_defs->addr;
		u32 num_entries = rss_defs->num_entries[dev_data->chip_id];
		u32 entry_width = rss_defs->entry_width[dev_data->chip_id];
		u32 total_size = (num_entries * entry_width) / 32;
		bool packed = (entry_width == 16);
		offset += qed_grc_dump_mem_hdr(p_hwfn,
					       dump_buf + offset,
					       dump,
					       rss_defs->mem_name,
					       addr,
					       total_size,
					       entry_width,
					       packed,
					       rss_defs->type_name, false, 0);
		/* dump RSS data */
		if (dump) {
			for (i = 0; i < BYTES_TO_DWORDS(total_size);
			     i++, addr++) {
				qed_wr(p_hwfn,
				       p_ptt, RSS_REG_RSS_RAM_ADDR, addr);
				for (j = 0; j < BYTES_IN_DWORD; j++, offset++)
					*(dump_buf + offset) = qed_rd(p_hwfn,
								      p_ptt,
								      RSS_REG_RSS_RAM_DATA
								      +
								      DWORDS_TO_BYTES
								      (j));
			}
		} else {
			offset += total_size;
		}
	}
	return offset;
}

/* Dumps GRC Big RAM. Returns the dumped size in dwords. */
static u32 qed_grc_dump_big_ram(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				u32 * dump_buf, bool dump, u8 big_ram_id)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0, i, j;
	u32 total_blocks =
	    s_big_ram_defs[big_ram_id].num_of_blocks[dev_data->chip_id];
	u32 ram_size = total_blocks * BIG_RAM_BLOCK_SIZE_DWORDS;
	char type_name[8] = "???_RAM";
	char mem_name[12] = "???_BIG_RAM";

	strncpy(type_name, s_big_ram_defs[big_ram_id].instance_name,
		strlen(s_big_ram_defs[big_ram_id].instance_name));
	strncpy(mem_name, s_big_ram_defs[big_ram_id].instance_name,
		strlen(s_big_ram_defs[big_ram_id].instance_name));
	/* dump memory header */
	offset += qed_grc_dump_mem_hdr(p_hwfn,
				       dump_buf + offset,
				       dump,
				       mem_name,
				       0,
				       ram_size,
				       BIG_RAM_BLOCK_SIZE_BYTES * 8,
				       false, type_name, false, 0);
	/* read and dump Big RAM data */
	if (dump) {
		/* check if BB A0 workaround is needed */
		bool hw_workaround = QED_IS_BB_A0(p_hwfn->cdev)
		    && qed_rd(p_hwfn,
			      p_ptt,
			      MISCS_REG_BLOCK_256B_EN) == 0;
		if (hw_workaround) {
			qed_wr(p_hwfn, p_ptt, MISCS_REG_BLOCK_256B_EN, 1);
			qed_wr(p_hwfn, p_ptt, MISC_REG_BLOCK_256B_EN, 1);
		}
		/* dump Big RAM */
		for (i = 0; i < total_blocks / 2; i++) {
			qed_wr(p_hwfn,
			       p_ptt,
			       s_big_ram_defs[big_ram_id].addr_reg_addr, i);
			for (j = 0; j < 2 * BIG_RAM_BLOCK_SIZE_DWORDS;
			     j++, offset++)
				*(dump_buf + offset) = qed_rd(p_hwfn,
							      p_ptt,
							      s_big_ram_defs
							      [big_ram_id].data_reg_addr
							      +
							      DWORDS_TO_BYTES
							      (j));
		}
		/* revert workaround if necessary */
		if (hw_workaround) {
			qed_wr(p_hwfn, p_ptt, MISCS_REG_BLOCK_256B_EN, 0);
			qed_wr(p_hwfn, p_ptt, MISC_REG_BLOCK_256B_EN, 0);
		}
	} else {
		offset += ram_size;
	}
	return offset;
}

static u32 qed_grc_dump_mcp(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	u32 offset = 0;
	bool halted = false;
	bool block_enable[MAX_BLOCK_ID] = { 0 };

	// halt MCP
	if (dump) {
		halted = (qed_mcp_halt(p_hwfn, p_ptt) == 0);
		if (!halted)
			DP_NOTICE(p_hwfn, "MCP halt failed!\n");
	}
	// dump MCP scratchpad
	offset += qed_grc_dump_mem(p_hwfn,
				   p_ptt,
				   dump_buf + offset,
				   dump,
				   NULL,
				   MCP_REG_SCRATCH,
				   MCP_REG_SCRATCH_SIZE,
				   0, false, "MCP", false, 0);
	// dump MCP cpu_reg_file
	offset += qed_grc_dump_mem(p_hwfn,
				   p_ptt,
				   dump_buf + offset,
				   dump,
				   NULL,
				   MCP_REG_CPU_REG_FILE,
				   MCP_REG_CPU_REG_FILE_SIZE,
				   0, false, "MCP", false, 0);
	// dump MCP registers
	block_enable[BLOCK_MCP] = true;
	offset += qed_grc_dump_registers(p_hwfn,
					 p_ptt,
					 dump_buf + offset,
					 dump, block_enable, "block", "MCP");
	// dump required non-MCP registers
	offset += qed_grc_dump_regs_hdr(dump_buf + offset,
					dump, 1, "eng", -1, "block", "MCP");
	offset += qed_grc_dump_reg_entry(p_hwfn,
					 p_ptt,
					 dump_buf + offset,
					 dump,
					 BYTES_TO_DWORDS
					 (MISC_REG_SHARED_MEM_ADDR), 1);
	// release MCP
	if (halted && qed_mcp_resume(p_hwfn, p_ptt) != 0)
		DP_NOTICE(p_hwfn, "Failed to resume MCP after halt!\n");
	return offset;
}

/* Dumps the tbus indirect memory for all PHYs. */
static u32 qed_grc_dump_phy(struct qed_hwfn *p_hwfn,
			    struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	u8 phy_id;
	u32 offset = 0, tbus_lo_offset, tbus_hi_offset;
	char mem_name[32];

	for (phy_id = 0; phy_id < ARRAY_SIZE(s_phy_defs); phy_id++) {
		struct phy_defs *phy_defs = &s_phy_defs[phy_id];
		int printed_chars = snprintf(mem_name,
					     sizeof(mem_name),
					     "tbus_%s",
					     phy_defs->phy_name);
		if (printed_chars < 0 || printed_chars >= sizeof(mem_name))
			DP_NOTICE(p_hwfn,
				  "Unexpected debug error: invalid PHY memory name");
		offset += qed_grc_dump_mem_hdr(p_hwfn,
					       dump_buf + offset,
					       dump,
					       mem_name,
					       0,
					       PHY_DUMP_SIZE_DWORDS,
					       16, true, mem_name, false, 0);
		if (dump) {
			u32 addr_lo_addr = phy_defs->base_addr +
			    phy_defs->tbus_addr_lo_addr;
			u32 addr_hi_addr = phy_defs->base_addr +
			    phy_defs->tbus_addr_hi_addr;
			u32 data_lo_addr = phy_defs->base_addr +
			    phy_defs->tbus_data_lo_addr;
			u32 data_hi_addr = phy_defs->base_addr +
			    phy_defs->tbus_data_hi_addr;
			u8 *bytes_buf = (u8 *) (dump_buf + offset);
			for (tbus_hi_offset = 0;
			     tbus_hi_offset < (NUM_PHY_TBUS_ADDRESSES >> 8);
			     tbus_hi_offset++) {
				qed_wr(p_hwfn,
				       p_ptt, addr_hi_addr, tbus_hi_offset);
				for (tbus_lo_offset = 0; tbus_lo_offset < 256;
				     tbus_lo_offset++) {
					qed_wr(p_hwfn,
					       p_ptt,
					       addr_lo_addr, tbus_lo_offset);
					*(bytes_buf++) = (u8) qed_rd(p_hwfn,
								     p_ptt,
								     data_lo_addr);
					*(bytes_buf++) = (u8) qed_rd(p_hwfn,
								     p_ptt,
								     data_hi_addr);
				}
			}
		}
		offset += PHY_DUMP_SIZE_DWORDS;
	}
	return offset;
}

static void qed_config_dbg_line(struct qed_hwfn *p_hwfn,
				struct qed_ptt *p_ptt,
				enum block_id block_id,
				u8 line_id,
				u8 cycle_en,
				u8 right_shift, u8 force_valid, u8 force_frame)
{
	qed_wr(p_hwfn, p_ptt, s_block_defs[block_id]->dbg_select_addr, line_id);
	qed_wr(p_hwfn,
	       p_ptt, s_block_defs[block_id]->dbg_cycle_enable_addr, cycle_en);
	qed_wr(p_hwfn,
	       p_ptt, s_block_defs[block_id]->dbg_shift_addr, right_shift);
	qed_wr(p_hwfn,
	       p_ptt,
	       s_block_defs[block_id]->dbg_force_valid_addr, force_valid);
	qed_wr(p_hwfn,
	       p_ptt,
	       s_block_defs[block_id]->dbg_force_frame_addr, force_frame);
}

/* Dumps Static Debug data. Returns the dumped size in dwords. */
static u32 qed_grc_dump_static_debug(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0, block_id, line_id, addr, i;
	u32 block_dwords = NUM_DBG_BUS_LINES * STATIC_DEBUG_LINE_DWORDS;

	if (dump) {
		DP_VERBOSE(p_hwfn,
			   QED_MSG_DEBUG, "Dumping static debug data...\n");
		/* disable all blocks debug output */
		for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++)
			if (s_block_defs[block_id]->
			    has_dbg_bus[dev_data->chip_id])
				qed_wr(p_hwfn, p_ptt,
				       s_block_defs
				       [block_id]->dbg_cycle_enable_addr, 0);
		qed_bus_reset_dbg_block(p_hwfn, p_ptt);
		qed_bus_set_framing_mode(p_hwfn,
					 p_ptt, DBG_BUS_FRAME_MODE_8HW_0ST);
		qed_wr(p_hwfn,
		       p_ptt, DBG_REG_DEBUG_TARGET, DBG_BUS_TARGET_ID_INT_BUF);
		qed_wr(p_hwfn, p_ptt, DBG_REG_FULL_MODE, 1);
		qed_bus_enable_dbg_block(p_hwfn, p_ptt, true);
	}
	/* dump all static debug lines for each relevant block */
	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++) {
		if (s_block_defs[block_id]->has_dbg_bus[dev_data->chip_id]) {
			/* dump static section params */
			offset += qed_grc_dump_mem_hdr(p_hwfn,
						       dump_buf + offset,
						       dump,
						       s_block_defs
						       [block_id]->name, 0,
						       block_dwords, 32, false,
						       "STATIC", false, 0);
			if (dump && !dev_data->block_in_reset[block_id]) {
				/* enable block's client */
				qed_bus_enable_clients(p_hwfn,
						       p_ptt,
						       1 <<
						       s_block_defs
						       [block_id]->dbg_client_id
						       [dev_data->chip_id]);
				for (line_id = 0; line_id < NUM_DBG_BUS_LINES;
				     line_id++) {
					/* configure debug line ID */
					qed_config_dbg_line(p_hwfn,
							    p_ptt,
							    (enum block_id)
							    block_id,
							    (u8) line_id,
							    0xf, 0, 0, 0);
					/* read debug line info */
					for (i = 0,
					     addr = DBG_REG_CALENDAR_OUT_DATA;
					     i < STATIC_DEBUG_LINE_DWORDS;
					     i++, offset++, addr +=
					     BYTES_IN_DWORD)
						dump_buf[offset] =
						    qed_rd(p_hwfn, p_ptt, addr);
				}
				/* disable block's client and debug output */
				qed_bus_enable_clients(p_hwfn, p_ptt, 0);
				qed_wr(p_hwfn,
				       p_ptt,
				       s_block_defs
				       [block_id]->dbg_cycle_enable_addr, 0);
			} else {
				/* all lines are invalid - dump zeros */
				if (dump)
					memset(dump_buf + offset,
					       0,
					       DWORDS_TO_BYTES(block_dwords));
				offset += block_dwords;
			}
		}
	}
	if (dump) {
		qed_bus_enable_dbg_block(p_hwfn, p_ptt, false);
		qed_bus_enable_clients(p_hwfn, p_ptt, 0);
	}
	return offset;
}

/* performs GRC Dump to the specified buffer. Returns the dumped size in dwords. */
static enum dbg_status qed_grc_dump(struct qed_hwfn *p_hwfn,
				    struct qed_ptt *p_ptt,
				    u32 * dump_buf,
				    bool dump, u32 * num_dumped_dwords)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	bool is_emul = dev_data->platform_id ==
	    PLATFORM_EMUL_FULL || dev_data->platform_id ==
	    PLATFORM_EMUL_REDUCED;
	u32 offset = 0;
	u8 i, port_mode = 0;
	bool parities_masked = false;

	*num_dumped_dwords = 0;
	;
	// fill GRC parameters that were not set by the user with their default value
	qed_dbg_grc_set_params_default(p_hwfn);
	// find port mode
	if (dump) {
		switch (qed_rd(p_hwfn, p_ptt, MISC_REG_PORT_MODE)) {
		case 0:
			port_mode = 1;
			break;
		case 1:
			port_mode = 2;
			break;
		case 2:
			port_mode = 4;
			break;
		}
	}
	/* update reset state */
	if (dump)
		qed_update_blocks_reset_state(p_hwfn, p_ptt);
	/* dump global params */
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 4);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "grc-dump");
	offset += qed_dump_num_param(dump_buf + offset,
				     dump,
				     "num-lcids",
				     qed_grc_get_param(p_hwfn,
						       DBG_GRC_PARAM_NUM_LCIDS));
	offset += qed_dump_num_param(dump_buf + offset,
				     dump,
				     "num-ltids",
				     qed_grc_get_param(p_hwfn,
						       DBG_GRC_PARAM_NUM_LTIDS));
	offset += qed_dump_num_param(dump_buf + offset,
				     dump, "num-ports", port_mode);
	/* dump reset registers (dumped before taking blocks out of reset ) */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_REGS))
		offset += qed_grc_dump_reset_regs(p_hwfn,
						  p_ptt,
						  dump_buf + offset, dump);
	/* take all blocks out of reset (using reset registers) */
	if (dump) {
		qed_grc_unreset_blocks(p_hwfn, p_ptt);
		qed_update_blocks_reset_state(p_hwfn, p_ptt);
	}
	/* disable all parities using MFW command */
	if (dump && !is_emul) {
		parities_masked =
		    (qed_mcp_mask_parities(p_hwfn, p_ptt, 1) == 0);
		if (!parities_masked) {
			if (qed_grc_get_param
			    (p_hwfn, DBG_GRC_PARAM_PARITY_SAFE))
				return DBG_STATUS_MCP_COULD_NOT_MASK_PRTY;
			else
				DP_NOTICE(p_hwfn,
					  "Failed to mask parities using MFW\n");
		}
	}
	/* dump modified registers (dumped before modifying them) */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_REGS))
		offset += qed_grc_dump_modified_regs(p_hwfn,
						     p_ptt,
						     dump_buf + offset, dump);
	/* stall storms */
	if (dump &&
	    (qed_grc_is_included(p_hwfn,
				 DBG_GRC_PARAM_DUMP_IOR) ||
	     qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_VFC)))
		qed_grc_stall_storms(p_hwfn, p_ptt, true);
	/* dump all regs  */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_REGS)) {
		// dump all blocks except MCP
		bool block_enable[MAX_BLOCK_ID];
		for (i = 0; i < MAX_BLOCK_ID; i++)
			block_enable[i] = true;
		block_enable[BLOCK_MCP] = false;
		offset += qed_grc_dump_registers(p_hwfn,
						 p_ptt,
						 dump_buf +
						 offset,
						 dump,
						 block_enable, NULL, NULL);
	}
	/* dump memories */
	offset += qed_grc_dump_memories(p_hwfn, p_ptt, dump_buf + offset, dump);
	/* dump MCP */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_MCP))
		offset += qed_grc_dump_mcp(p_hwfn,
					   p_ptt, dump_buf + offset, dump);
	/* dump context */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_CM_CTX))
		offset += qed_grc_dump_ctx(p_hwfn,
					   p_ptt, dump_buf + offset, dump);
	/* dump RSS memories */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_RSS))
		offset += qed_grc_dump_rss(p_hwfn,
					   p_ptt, dump_buf + offset, dump);
	/* dump Big RAM */
	for (i = 0; i < NUM_BIG_RAM_TYPES; i++)
		if (qed_grc_is_included(p_hwfn, s_big_ram_defs[i].grc_param))
			offset += qed_grc_dump_big_ram(p_hwfn,
						       p_ptt,
						       dump_buf + offset,
						       dump, i);
	/* dump IORs */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_IOR))
		offset += qed_grc_dump_iors(p_hwfn,
					    p_ptt, dump_buf + offset, dump);
	/* dump VFC */
	if (qed_grc_is_included(p_hwfn, DBG_GRC_PARAM_DUMP_VFC))
		offset += qed_grc_dump_vfc(p_hwfn,
					   p_ptt, dump_buf + offset, dump);
	/* dump PHY tbus */
	if (qed_grc_is_included(p_hwfn,
				DBG_GRC_PARAM_DUMP_PHY) && dev_data->chip_id ==
	    CHIP_K2 && dev_data->platform_id == PLATFORM_ASIC)
		offset += qed_grc_dump_phy(p_hwfn,
					   p_ptt, dump_buf + offset, dump);
	/* dump static debug data  */
	if (qed_grc_is_included(p_hwfn,
				DBG_GRC_PARAM_DUMP_STATIC) &&
	    dev_data->bus.state == DBG_BUS_STATE_IDLE)
		offset += qed_grc_dump_static_debug(p_hwfn,
						    p_ptt,
						    dump_buf + offset, dump);
	/* dump last section */
	offset += qed_dump_last_section(dump_buf, offset, dump);
	if (dump) {
		/* unstall storms */
		if (qed_grc_get_param(p_hwfn, DBG_GRC_PARAM_UNSTALL))
			qed_grc_stall_storms(p_hwfn, p_ptt, false);
		/* clear parity status */
		if (!is_emul)
			qed_grc_clear_all_prty(p_hwfn, p_ptt);
		/* enable all parities using MFW command */
		if (parities_masked)
			qed_mcp_mask_parities(p_hwfn, p_ptt, 0);
	}
	*num_dumped_dwords = offset;
	;
	return DBG_STATUS_OK;
}

/* writes the specified failing Idle Check rule to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_idle_chk_dump_failure(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     u32 *
				     dump_buf,
				     bool dump,
				     u16 rule_id,
				     const struct dbg_idle_chk_rule *rule,
				     u16 fail_entry_id, u32 * cond_reg_values)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	struct dbg_idle_chk_result_hdr *hdr =
	    (struct dbg_idle_chk_result_hdr *)dump_buf;
	const union dbg_idle_chk_reg *regs =
	    &((const union dbg_idle_chk_reg *)
	      s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_REGS].ptr)[rule->reg_offset];
	const struct dbg_idle_chk_cond_reg *cond_regs = &regs[0].cond_reg;
	const struct dbg_idle_chk_info_reg *info_regs =
	    &regs[rule->num_cond_regs].info_reg;
	u32 next_reg_offset = 0, i, offset = 0;
	u8 reg_id;

	// dump rule data
	if (dump) {
		memset(hdr, 0, sizeof(struct dbg_idle_chk_result_hdr));
		hdr->rule_id = rule_id;
		hdr->mem_entry_id = fail_entry_id;
		hdr->severity = rule->severity;
		hdr->num_dumped_cond_regs = rule->num_cond_regs;
	}
	offset += IDLE_CHK_RESULT_HDR_DWORDS;
	// dump condition register values
	for (reg_id = 0; reg_id < rule->num_cond_regs; reg_id++) {
		const struct dbg_idle_chk_cond_reg *reg = &cond_regs[reg_id];
		// write register header
		if (dump) {
			struct dbg_idle_chk_result_reg_hdr *reg_hdr =
			    (struct dbg_idle_chk_result_reg_hdr *)(dump_buf
								   + offset);
			offset += IDLE_CHK_RESULT_REG_HDR_DWORDS;
			memset(reg_hdr, 0,
			       sizeof(struct dbg_idle_chk_result_reg_hdr));
			reg_hdr->start_entry = reg->start_entry;
			reg_hdr->size = reg->entry_size;
			SET_FIELD(reg_hdr->data,
				  DBG_IDLE_CHK_RESULT_REG_HDR_IS_MEM,
				  reg->num_entries > 1 || reg->start_entry >
				  0 ? 1 : 0);
			SET_FIELD(reg_hdr->data,
				  DBG_IDLE_CHK_RESULT_REG_HDR_REG_ID, reg_id);
			// write register values
			for (i = 0; i < reg_hdr->size;
			     i++, next_reg_offset++, offset++)
				dump_buf[offset] =
				    cond_reg_values[next_reg_offset];
		} else {
			offset += IDLE_CHK_RESULT_REG_HDR_DWORDS +
			    reg->entry_size;
		}
	}
	// dump info register values
	for (reg_id = 0; reg_id < rule->num_info_regs; reg_id++) {
		const struct dbg_idle_chk_info_reg *reg = &info_regs[reg_id];
		// check if register's block is in reset
		if (dump) {
			u32 block_id = GET_FIELD(reg->data,
						 DBG_IDLE_CHK_INFO_REG_BLOCK_ID);
			if (block_id >= MAX_BLOCK_ID) {
				DP_NOTICE(p_hwfn, "Invalid block_id");
				return 0;
			}
			if (!dev_data->block_in_reset[block_id]) {
				bool eval_mode = GET_FIELD(reg->mode.data,
							   DBG_MODE_HDR_EVAL_MODE)
				    > 0;
				bool mode_match = true;
				// check mode
				if (eval_mode) {
					u16 modes_buf_offset =
					    GET_FIELD(reg->mode.data,
						      DBG_MODE_HDR_MODES_BUF_OFFSET);
					mode_match = qed_is_mode_match(p_hwfn,
								       &modes_buf_offset);
				}
				if (mode_match) {
					u32 grc_addr =
					    DWORDS_TO_BYTES(GET_FIELD(reg->data,
								      DBG_IDLE_CHK_INFO_REG_ADDRESS));
					// write register header
					struct dbg_idle_chk_result_reg_hdr
					*reg_hdr =
					    (struct
					     dbg_idle_chk_result_reg_hdr
					     *)(dump_buf + offset);
					offset +=
					    IDLE_CHK_RESULT_REG_HDR_DWORDS;
					hdr->num_dumped_info_regs++;
					memset(reg_hdr, 0,
					       sizeof(struct
						      dbg_idle_chk_result_reg_hdr));
					reg_hdr->size = reg->size;
					SET_FIELD(reg_hdr->data,
						  DBG_IDLE_CHK_RESULT_REG_HDR_REG_ID,
						  rule->num_cond_regs + reg_id);
					// write register values
					for (i = 0; i < reg->size;
					     i++, offset++, grc_addr += 4)
						dump_buf[offset] =
						    qed_rd(p_hwfn, p_ptt,
							   grc_addr);
				}
			}
		} else {
			offset += IDLE_CHK_RESULT_REG_HDR_DWORDS + reg->size;
		}
	}
	return offset;
}

/* Dumps idle check rule entries. Returns the dumped size in dwords. */
static u32 qed_idle_chk_dump_rule_entries(struct qed_hwfn *p_hwfn, struct qed_ptt
					  *p_ptt, u32 * dump_buf, bool dump, const struct dbg_idle_chk_rule
					  *input_rules, u32 num_input_rules)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 i, j, offset = 0;
	u32 cond_reg_values[IDLE_CHK_MAX_ENTRIES_SIZE];
	u16 entry_id;
	u8 reg_id;

	for (i = 0; i < num_input_rules; i++) {
		const struct dbg_idle_chk_rule *rule = &input_rules[i];
		const union dbg_idle_chk_reg *regs =
		    &((const union dbg_idle_chk_reg *)
		      s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_REGS].
		      ptr)[rule->reg_offset];
		const struct dbg_idle_chk_cond_reg *cond_regs =
		    &regs[0].cond_reg;
		const u32 *imm_values =
		    &s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_IMMS].
		    ptr[rule->imm_offset];
		u16 num_reg_entries = 1;
		bool check_rule = true;
		// check if all condition register blocks are out of reset, and find maximal number of entries
		// (all condition registers that are memories must have the same size, which is > 1)
		for (reg_id = 0; reg_id < rule->num_cond_regs && check_rule;
		     reg_id++) {
			u32 block_id = GET_FIELD(cond_regs[reg_id].data,
						 DBG_IDLE_CHK_COND_REG_BLOCK_ID);
			if (block_id >= MAX_BLOCK_ID) {
				DP_NOTICE(p_hwfn, "Invalid block_id");
				return 0;
			}
			check_rule = !dev_data->block_in_reset[block_id];
			if (cond_regs[reg_id].num_entries > num_reg_entries)
				num_reg_entries = cond_regs[reg_id].num_entries;
		}
		if (check_rule || !dump) {
			bool rule_failed = false;
			// go over all register entries (number of entries is the same for all condition registers)
			for (entry_id = 0;
			     entry_id < num_reg_entries && !rule_failed;
			     entry_id++) {
				// read current entry of all condition registers
				if (dump) {
					u32 next_reg_offset = 0;
					for (reg_id = 0;
					     reg_id < rule->num_cond_regs;
					     reg_id++) {
						const struct
						dbg_idle_chk_cond_reg *reg
						    = &cond_regs[reg_id];
						// find GRC address (if it's a memory, the address of the specific entry is calculated)
						u32 grc_addr =
						    DWORDS_TO_BYTES(GET_FIELD
								    (reg->data,
								     DBG_IDLE_CHK_COND_REG_ADDRESS));
						if (reg->num_entries > 1
						    || reg->start_entry > 0) {
							u32 padded_entry_size =
							    reg->entry_size >
							    1 ?
							    qed_get_near_pow2
							    (reg->entry_size)
							    : 1;
							grc_addr +=
							    DWORDS_TO_BYTES((reg->start_entry + entry_id)
									    *
									    padded_entry_size);
						}
						// read registers
						if (next_reg_offset +
						    reg->entry_size >=
						    IDLE_CHK_MAX_ENTRIES_SIZE) {
							DP_NOTICE(p_hwfn,
								  "idle check registers entry is too large");
							return 0;
						}
						for (j = 0; j < reg->entry_size;
						     j++, next_reg_offset++,
						     grc_addr += 4)
							cond_reg_values
							    [next_reg_offset] =
							    qed_rd(p_hwfn,
								   p_ptt,
								   grc_addr);
					}
				}
				// call rule's condition function - a return value of true indicates failure
				if ((*cond_arr[rule->cond_id]) (cond_reg_values,
								imm_values) ||
				    !dump) {
					offset +=
					    qed_idle_chk_dump_failure(p_hwfn,
								      p_ptt,
								      dump_buf
								      + offset,
								      dump,
								      rule->
								      rule_id,
								      rule,
								      entry_id,
								      cond_reg_values);
					rule_failed = true;
				}
			}
		}
	}
	return offset;
}

/* performs Idle Check Dump to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_idle_chk_dump(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	u32 offset = 0, input_offset = 0;

	/* dump global params */
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "idle-chk");
	/* dump idle check section header */
	offset += qed_dump_section_hdr(dump_buf + offset, dump, "idle_chk", 0);
	if (dump)
		DP_VERBOSE(p_hwfn, QED_MSG_DEBUG, "Dumping idle check...\n");
	while (input_offset <
	       s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_RULES].size_in_dwords) {
		const struct dbg_idle_chk_cond_hdr *cond_hdr =
		    (const struct dbg_idle_chk_cond_hdr *)
		    &s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_RULES].
		    ptr[input_offset++];
		bool eval_mode = GET_FIELD(cond_hdr->mode.data,
					   DBG_MODE_HDR_EVAL_MODE) > 0;
		bool mode_match = true;
		// check mode
		if (eval_mode) {
			u16 modes_buf_offset = GET_FIELD(cond_hdr->mode.data,
							 DBG_MODE_HDR_MODES_BUF_OFFSET);
			mode_match = qed_is_mode_match(p_hwfn,
						       &modes_buf_offset);
		}
		if (mode_match)
			offset += qed_idle_chk_dump_rule_entries(p_hwfn,
								 p_ptt,
								 dump_buf +
								 offset,
								 dump,
								 (const struct
								  dbg_idle_chk_rule
								  *)
								 &s_dbg_arrays
								 [BIN_BUF_DBG_IDLE_CHK_RULES].
								 ptr
								 [input_offset],
								 cond_hdr->data_size
								 /
								 IDLE_CHK_RULE_SIZE_DWORDS);
		input_offset += cond_hdr->data_size;
	}
	return offset;
}

// finds the meta data image in NVRAM.
static enum dbg_status qed_find_nvram_image(struct qed_hwfn *p_hwfn,
					    struct qed_ptt *p_ptt,
					    u32 image_type,
					    u32 *
					    nvram_offset_bytes,
					    u32 * nvram_size_bytes)
{
	u32 ret_mcp_resp, ret_mcp_param, ret_txn_size;
	struct mcp_file_att file_att;

	// call NVRAM get file command
	if (qed_mcp_nvm_rd_cmd(p_hwfn, p_ptt, DRV_MSG_CODE_NVM_GET_FILE_ATT,
			       image_type, &ret_mcp_resp, &ret_mcp_param,
			       &ret_txn_size, (u32 *) & file_att) != 0)
		return DBG_STATUS_NVRAM_GET_IMAGE_FAILED;
	// check response
	if ((ret_mcp_resp & FW_MSG_CODE_MASK) != FW_MSG_CODE_NVM_OK)
		return DBG_STATUS_NVRAM_GET_IMAGE_FAILED;
	// update return values
	*nvram_offset_bytes = file_att.nvm_start_addr;
	*nvram_size_bytes = file_att.len;
	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "find_nvram_image: found NVRAM image of type %d in NVRAM offset %d bytes with size %d bytes\n",
		   image_type, *nvram_offset_bytes, *nvram_size_bytes);
	// check alignment
	if (*nvram_size_bytes & 0x3)
		return DBG_STATUS_NON_ALIGNED_NVRAM_IMAGE;
	return DBG_STATUS_OK;
}

static enum dbg_status qed_nvram_read(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 nvram_offset_bytes,
				      u32 nvram_size_bytes, u32 * ret_buf)
{
	u32 ret_mcp_resp, ret_mcp_param, ret_read_size;
	u32 bytes_to_copy, read_offset = 0;
	s32 bytes_left = nvram_size_bytes;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "nvram_read: reading image of size %d bytes from NVRAM\n",
		   nvram_size_bytes);
	do {
		bytes_to_copy =
		    (bytes_left >
		     MCP_DRV_NVM_BUF_LEN) ? MCP_DRV_NVM_BUF_LEN : bytes_left;
		// call NVRAM read command
		if (qed_mcp_nvm_rd_cmd(p_hwfn, p_ptt,
				       DRV_MSG_CODE_NVM_READ_NVRAM,
				       (nvram_offset_bytes +
					read_offset) |
				       (bytes_to_copy <<
					DRV_MB_PARAM_NVM_LEN_SHIFT),
				       &ret_mcp_resp, &ret_mcp_param,
				       &ret_read_size,
				       (u32 *) ((u8 *) ret_buf +
						read_offset)) != 0)
			return DBG_STATUS_NVRAM_READ_FAILED;
		// check response
		if ((ret_mcp_resp & FW_MSG_CODE_MASK) != FW_MSG_CODE_NVM_OK)
			return DBG_STATUS_NVRAM_READ_FAILED;
		// update read offset
		read_offset += ret_read_size;
		bytes_left -= ret_read_size;
	} while (bytes_left > 0);
	return DBG_STATUS_OK;
}

// get info on the MCP Trace data in the scratchpad:
// - trace_data_grc_addr - the GRC address of the trace data
// - trace_data_size_bytes - the size in bytes of the MCP Trace data (without the header)
static enum dbg_status qed_mcp_trace_get_data_info(struct qed_hwfn *p_hwfn,
						   struct qed_ptt *p_ptt,
						   u32 *
						   trace_data_grc_addr,
						   u32 * trace_data_size_bytes)
{
	u32 signature;
	// read MCP trace section offsize structure from MCP scratchpad
	u32 spad_trace_offsize = qed_rd(p_hwfn,
					p_ptt,
					MCP_SPAD_TRACE_OFFSIZE_ADDR);

	// extract MCP trace section GRC address from offsize structure (within scratchpad)
	*trace_data_grc_addr =
	    MCP_REG_SCRATCH + SECTION_OFFSET(spad_trace_offsize);
	// read signature from MCP trace section
	signature =
	    qed_rd(p_hwfn, p_ptt, *trace_data_grc_addr +
		   offsetof(struct mcp_trace, signature));
	if (signature != MFW_TRACE_SIGNATURE)
		return DBG_STATUS_INVALID_TRACE_SIGNATURE;
	// read trace size from MCP trace section
	*trace_data_size_bytes = qed_rd(p_hwfn,
					p_ptt,
					*trace_data_grc_addr +
					offsetof(struct mcp_trace, size));
	return DBG_STATUS_OK;
}

// reads MCP trace meta data image from NVRAM.
// - running_bundle_id (OUT) - the running bundle ID (invalid when loaded from file)
// - trace_meta_offset_bytes (OUT) - the NVRAM offset in bytes in which the MCP Trace meta data starts (invalid when loaded from file)
// - trace_meta_size_bytes (OUT) - the size in bytes of the MCP Trace meta data
static enum dbg_status qed_mcp_trace_get_meta_info(struct qed_hwfn *p_hwfn,
						   struct qed_ptt *p_ptt,
						   u32
						   trace_data_size_bytes,
						   u32 *
						   running_bundle_id,
						   u32 *
						   trace_meta_offset_bytes,
						   u32 * trace_meta_size_bytes)
{
	u32 nvram_image_type;
	// read MCP trace section offsize structure from MCP scratchpad
	u32 spad_trace_offsize = qed_rd(p_hwfn,
					p_ptt,
					MCP_SPAD_TRACE_OFFSIZE_ADDR);
	enum dbg_status status;
	// find running bundle ID
	u32 running_mfw_addr =
	    MCP_REG_SCRATCH + SECTION_OFFSET(spad_trace_offsize) +
	    QED_SECTION_SIZE(spad_trace_offsize) + trace_data_size_bytes;

	*running_bundle_id = qed_rd(p_hwfn, p_ptt, running_mfw_addr);
	if (*running_bundle_id > 1)
		return DBG_STATUS_INVALID_NVRAM_BUNDLE;
	// find image in NVRAM
	nvram_image_type =
	    (*running_bundle_id ==
	     DIR_ID_1) ? NVM_TYPE_MFW_TRACE1 : NVM_TYPE_MFW_TRACE2;
	status = qed_find_nvram_image(p_hwfn,
				      p_ptt,
				      nvram_image_type,
				      trace_meta_offset_bytes,
				      trace_meta_size_bytes);
	if (status != DBG_STATUS_OK)
		return status;
	return DBG_STATUS_OK;
}

// Reads the MCP Trace data from the specified GRC address into the specified buffer
static void qed_mcp_trace_read_data(struct qed_hwfn *p_hwfn,
				    struct qed_ptt *p_ptt,
				    u32 grc_addr, u32 size_in_dwords, u32 * buf)
{
	u32 i;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "mcp_trace_read_data: reading trace data of size %d dwords from GRC address 0x%x\n",
		   size_in_dwords, grc_addr);
	for (i = 0; i < size_in_dwords; i++, grc_addr += BYTES_IN_DWORD)
		buf[i] = qed_rd(p_hwfn, p_ptt, grc_addr);
}

// Reads the MCP Trace meta data (from NVRAM or buffer) into the specified buffer
static enum dbg_status qed_mcp_trace_read_meta(struct qed_hwfn *p_hwfn,
					       struct qed_ptt *p_ptt,
					       u32
					       nvram_offset_in_bytes,
					       u32 size_in_bytes, u32 * buf)
{
	u32 signature;
	u8 modules_num, i;
	u8 *byte_buf = (u8 *) buf;
	// read meta data from NVRAM
	enum dbg_status status = qed_nvram_read(p_hwfn,
						p_ptt,
						nvram_offset_in_bytes,
						size_in_bytes,
						buf);

	if (status != DBG_STATUS_OK)
		return status;
	// extract and check first signature
	signature = qed_read_unaligned_dword(byte_buf);
	byte_buf += sizeof(u32);
	if (signature != MCP_TRACE_META_IMAGE_SIGNATURE)
		return DBG_STATUS_INVALID_TRACE_SIGNATURE;
	// extract number of modules
	modules_num = *(byte_buf++);
	// skip all modules
	for (i = 0; i < modules_num; i++) {
		u8 module_len = *(byte_buf++);
		byte_buf += module_len;
	}
	// extract and check second signature
	signature = qed_read_unaligned_dword(byte_buf);
	byte_buf += sizeof(u32);
	if (signature != MCP_TRACE_META_IMAGE_SIGNATURE)
		return DBG_STATUS_INVALID_TRACE_SIGNATURE;
	return DBG_STATUS_OK;
}

// Dump MCP Trace
enum dbg_status qed_mcp_trace_dump(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   u32 * dump_buf,
				   bool dump, u32 * num_dumped_dwords)
{
	u32 offset = 0, trace_data_grc_addr, trace_data_size_bytes,
	    trace_data_size_dwords;
	u32 running_bundle_id, trace_meta_offset_bytes,
	    trace_meta_size_bytes, trace_meta_size_dwords;
	int halted = 0;
	enum dbg_status status;

	*num_dumped_dwords = 0;
	// get trace data info
	status = qed_mcp_trace_get_data_info(p_hwfn,
					     p_ptt,
					     &trace_data_grc_addr,
					     &trace_data_size_bytes);
	if (status != DBG_STATUS_OK)
		return status;
	// dump global params
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "mcp-trace");
	// halt MCP while reading from scratchpad so the read data will be consistent
	// if halt fails, MCP trace is taken anyway, with a small risk that it may be corrupt
	if (dump) {
		halted = (qed_mcp_halt(p_hwfn, p_ptt) == 0);
		if (!halted)
			DP_NOTICE(p_hwfn, "MCP halt failed!\n");
	}
	// find trace data size
	trace_data_size_dwords =
	    DIV_ROUND_UP(trace_data_size_bytes + sizeof(struct mcp_trace),
			 BYTES_IN_DWORD);
	/* dump trace data section header and param */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "mcp_trace_data", 1);
	offset += qed_dump_num_param(dump_buf + offset,
				     dump, "size", trace_data_size_dwords);
	// read trace data from scratchpad into dump buffer
	if (dump)
		qed_mcp_trace_read_data(p_hwfn,
					p_ptt,
					trace_data_grc_addr,
					trace_data_size_dwords,
					dump_buf + offset);
	offset += trace_data_size_dwords;
	// resume MCP (only if halt succeeded)
	if (halted && qed_mcp_resume(p_hwfn, p_ptt) != 0)
		DP_NOTICE(p_hwfn, "Failed to resume MCP after halt!\n");
	/* dump trace meta section header */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "mcp_trace_meta", 1);
	// read trace meta only if NVRAM access is enabled
	if (1) {
		// read trace meta info
		status = qed_mcp_trace_get_meta_info(p_hwfn,
						     p_ptt,
						     trace_data_size_bytes,
						     &running_bundle_id,
						     &trace_meta_offset_bytes,
						     &trace_meta_size_bytes);
		if (status != DBG_STATUS_OK)
			return status;
		/* dump trace meta size param */
		trace_meta_size_dwords = BYTES_TO_DWORDS(trace_meta_size_bytes);	// trace_meta_size_bytes is always dword-aligned
		offset += qed_dump_num_param(dump_buf + offset,
					     dump,
					     "size", trace_meta_size_dwords);
		// read trace meta image into dump buffer
		if (dump) {
			status = qed_mcp_trace_read_meta(p_hwfn,
							 p_ptt,
							 trace_meta_offset_bytes,
							 trace_meta_size_bytes,
							 dump_buf + offset);
			if (status != DBG_STATUS_OK)
				return status;
		}
		offset += trace_meta_size_dwords;
	} else {
		/* dump trace meta size param (empty) */
		offset +=
		    qed_dump_num_param(dump_buf + offset, dump, "size", 0);
	}
	*num_dumped_dwords = offset;
	return DBG_STATUS_OK;
}

// Dump GRC FIFO
enum dbg_status qed_reg_fifo_dump(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  u32 * dump_buf,
				  bool dump, u32 * num_dumped_dwords)
{
	bool fifo_has_data;
	u32 offset = 0, dwords_read, size_param_offset;

	*num_dumped_dwords = 0;
	// dump global params
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "reg-fifo");
	/* dump fifo data section header and param. The size param is 0 for now,
	 * and is overwritten after reading the FIFO. */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "reg_fifo_data", 1);
	size_param_offset = offset;
	offset += qed_dump_num_param(dump_buf + offset, dump, "size", 0);
	if (dump) {
		fifo_has_data = qed_rd(p_hwfn,
				       p_ptt,
				       GRC_REG_TRACE_FIFO_VALID_DATA) > 0;
		/* Pull available data from fifo. Use DMAE since this is widebus memory and must be accessed atomically.
		 * Test for dwords_read not passing buffer size since more entries could be added to the buffer as we are emptying it.
		 */
		for (dwords_read = 0;
		     fifo_has_data && dwords_read < REG_FIFO_DEPTH_DWORDS;
		     dwords_read += REG_FIFO_ELEMENT_DWORDS, offset +=
		     REG_FIFO_ELEMENT_DWORDS) {
			if (qed_dmae_grc2host(p_hwfn, p_ptt, GRC_REG_TRACE_FIFO,
					      (u64) (uintptr_t) (&dump_buf
								 [offset]),
					      REG_FIFO_ELEMENT_DWORDS, 0))
				return DBG_STATUS_DMAE_FAILED;
			fifo_has_data = qed_rd(p_hwfn,
					       p_ptt,
					       GRC_REG_TRACE_FIFO_VALID_DATA) >
			    0;
		}
		qed_dump_num_param(dump_buf + size_param_offset,
				   dump, "size", dwords_read);
	} else {
		/* FIFO max size is REG_FIFO_DEPTH_DWORDS. There is no way to test how much data is available, except for reading it */
		offset += REG_FIFO_DEPTH_DWORDS;
	}
	*num_dumped_dwords = offset;
	return DBG_STATUS_OK;
}

// Dump IGU FIFO
enum dbg_status qed_igu_fifo_dump(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  u32 * dump_buf,
				  bool dump, u32 * num_dumped_dwords)
{
	bool fifo_has_data;
	u32 offset = 0, dwords_read, size_param_offset;

	*num_dumped_dwords = 0;
	// dump global params
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "igu-fifo");
	/* dump fifo data section header and param. The size param is 0 for now,
	 * and is overwritten after reading the FIFO. */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "igu_fifo_data", 1);
	size_param_offset = offset;
	offset += qed_dump_num_param(dump_buf + offset, dump, "size", 0);
	if (dump) {
		fifo_has_data = qed_rd(p_hwfn,
				       p_ptt,
				       IGU_REG_ERROR_HANDLING_DATA_VALID) > 0;
		/* Pull available data from fifo. Use DMAE since this is widebus memory and must be accessed atomically.
		 * Test for dwords_read not passing buffer size since more entries could be added to the buffer as we are emptying it.
		 */
		for (dwords_read = 0;
		     fifo_has_data && dwords_read < IGU_FIFO_DEPTH_DWORDS;
		     dwords_read += IGU_FIFO_ELEMENT_DWORDS, offset +=
		     IGU_FIFO_ELEMENT_DWORDS) {
			if (qed_dmae_grc2host(p_hwfn, p_ptt,
					      IGU_REG_ERROR_HANDLING_MEMORY,
					      (u64) (uintptr_t) (&dump_buf
								 [offset]),
					      IGU_FIFO_ELEMENT_DWORDS, 0))
				return DBG_STATUS_DMAE_FAILED;
			fifo_has_data = qed_rd(p_hwfn,
					       p_ptt,
					       IGU_REG_ERROR_HANDLING_DATA_VALID)
			    > 0;
		}
		qed_dump_num_param(dump_buf + size_param_offset,
				   dump, "size", dwords_read);
	} else {
		/* FIFO max size is IGU_FIFO_DEPTH_DWORDS. There is no way to test how much data is available, except for reading it */
		offset += IGU_FIFO_DEPTH_DWORDS;
	}
	*num_dumped_dwords = offset;
	return DBG_STATUS_OK;
}

// Protection Override dump
enum dbg_status qed_protection_override_dump(struct qed_hwfn *p_hwfn,
					     struct qed_ptt *p_ptt,
					     u32 * dump_buf,
					     bool dump, u32 * num_dumped_dwords)
{
	u32 offset = 0, size_param_offset, override_window_dwords;

	*num_dumped_dwords = 0;
	// dump global params
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "protection-override");
	/* dump data section header and param. The size param is 0 for now, and is overwritten after reading the data. */
	offset += qed_dump_section_hdr(dump_buf + offset,
				       dump, "protection_override_data", 1);
	size_param_offset = offset;
	offset += qed_dump_num_param(dump_buf + offset, dump, "size", 0);
	if (dump) {
		/* add override window info to buffer */
		override_window_dwords = qed_rd(p_hwfn,
						p_ptt,
						GRC_REG_NUMBER_VALID_OVERRIDE_WINDOW)
		    * PROTECTION_OVERRIDE_ELEMENT_DWORDS;
		if (qed_dmae_grc2host(p_hwfn, p_ptt,
				      GRC_REG_PROTECTION_OVERRIDE_WINDOW,
				      (u64) (uintptr_t) (dump_buf + offset),
				      override_window_dwords, 0))
			return DBG_STATUS_DMAE_FAILED;
		offset += override_window_dwords;
		qed_dump_num_param(dump_buf + size_param_offset,
				   dump, "size", override_window_dwords);
	} else {
		offset += PROTECTION_OVERRIDE_DEPTH_DWORDS;
	}
	*num_dumped_dwords = offset;
	return DBG_STATUS_OK;
}

/* performs FW Asserts Dump to the specified buffer. Returns the dumped size in dwords. */
static u32 qed_fw_asserts_dump(struct qed_hwfn *p_hwfn,
			       struct qed_ptt *p_ptt, u32 * dump_buf, bool dump)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	struct fw_info fw_info;
	char storm_letter_str[2] = "?";
	u32 offset = 0, i;
	u8 storm_id;

	/* dump global params */
	offset += qed_dump_common_global_params(p_hwfn,
						p_ptt,
						dump_buf + offset, dump, 1);
	offset += qed_dump_str_param(dump_buf + offset,
				     dump, "dump-type", "fw-asserts");
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		/* find Storm dump size */
		if (!dev_data->block_in_reset[s_storm_defs[storm_id].block_id]) {
			/* read FW info for the current Storm  */
			qed_read_fw_info(p_hwfn, p_ptt, storm_id, &fw_info);
			/* dump FW Asserts section header and params */
			storm_letter_str[0] = s_storm_defs[storm_id].letter;
			offset += qed_dump_section_hdr(dump_buf + offset,
						       dump, "fw_asserts", 2);
			offset += qed_dump_str_param(dump_buf + offset,
						     dump,
						     "storm", storm_letter_str);
			offset += qed_dump_num_param(dump_buf + offset,
						     dump,
						     "size",
						     fw_info.
						     fw_asserts_section.list_element_dword_size);
			/* read and dump FW Asserts data */
			if (dump) {
				u32 fw_asserts_section_addr =
				    s_storm_defs[storm_id].sem_fast_mem_addr +
				    SEM_FAST_REG_INT_RAM +
				    RAM_LINES_TO_BYTES(fw_info.
						       fw_asserts_section.section_ram_line_offset);
				u32 next_list_idx_addr =
				    fw_asserts_section_addr +
				    DWORDS_TO_BYTES(fw_info.
						    fw_asserts_section.list_next_index_dword_offset);
				u32 next_list_idx = qed_rd(p_hwfn,
							   p_ptt,
							   next_list_idx_addr);
				u32 last_list_idx =
				    (next_list_idx >
				     0 ? next_list_idx :
				     fw_info.fw_asserts_section.list_num_elements)
				    - 1;
				u32 element_addr =
				    fw_asserts_section_addr +
				    DWORDS_TO_BYTES(fw_info.
						    fw_asserts_section.list_dword_offset)
				    +
				    last_list_idx *
				    DWORDS_TO_BYTES(fw_info.
						    fw_asserts_section.list_element_dword_size);
				for (i = 0;
				     i <
				     fw_info.
				     fw_asserts_section.list_element_dword_size;
				     i++, offset++, element_addr +=
				     BYTES_IN_DWORD)
					dump_buf[offset] =
					    qed_rd(p_hwfn, p_ptt, element_addr);
			} else {
				offset +=
				    fw_info.
				    fw_asserts_section.list_element_dword_size;
			}
		}
	}
	/* dump last section */
	offset += qed_dump_section_hdr(dump_buf + offset, dump, "last", 0);
	return offset;
}

/***************************** Public Functions *******************************/
enum dbg_status qed_dbg_set_bin_ptr(const u8 * const bin_ptr)
{
	// convert binary data to debug arrays
	u32 num_of_buffers = *(u32 *) bin_ptr;
	struct bin_buffer_hdr *buf_array =
	    (struct bin_buffer_hdr *)((u32 *) bin_ptr + 1);
	u8 buf_id;

	for (buf_id = 0; buf_id < num_of_buffers; buf_id++) {
		s_dbg_arrays[buf_id].ptr =
		    (u32 *) (bin_ptr + buf_array[buf_id].offset);
		s_dbg_arrays[buf_id].size_in_dwords =
		    BYTES_TO_DWORDS(buf_array[buf_id].length);
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_set_app_ver(u32 ver)
{
	if (ver < TOOLS_VERSION)
		return DBG_STATUS_UNSUPPORTED_APP_VERSION;
	s_app_ver = ver;
	return DBG_STATUS_OK;
}

u32 qed_dbg_get_fw_func_ver(void)
{
	return TOOLS_VERSION;
}

enum dbg_status qed_dbg_bus_reset(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  bool one_shot_en,
				  u8 force_hw_dwords,
				  bool unify_inputs, bool grc_input_en)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	enum dbg_status status = qed_dbg_dev_init(p_hwfn,
						  p_ptt);

	if (status != DBG_STATUS_OK)
		return status;
	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_reset: one_shot_en = %d, force_hw_dwords = %d, unify_inputs = %d, grc_input_en = %d\n",
		   one_shot_en, force_hw_dwords, unify_inputs, grc_input_en);
	if (force_hw_dwords != 0 &&
	    force_hw_dwords != 4 && force_hw_dwords != 8)
		return DBG_STATUS_INVALID_ARGS;
	/* update reset state of all blocks */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	/* disable all debug inputs */
	status = qed_bus_disable_inputs(p_hwfn, p_ptt, false);
	if (status != DBG_STATUS_OK)
		return status;
	/* reset DBG block */
	qed_bus_reset_dbg_block(p_hwfn, p_ptt);
	/* set one-shot / wrap-around */
	qed_wr(p_hwfn, p_ptt, DBG_REG_FULL_MODE, one_shot_en ? 0 : 1);
	/* init state params */
	memset(&dev_data->bus, 0, sizeof(dev_data->bus));
	dev_data->bus.target = DBG_BUS_TARGET_ID_INT_BUF;
	dev_data->bus.state = DBG_BUS_STATE_READY;
	dev_data->bus.one_shot_en = one_shot_en;
	dev_data->bus.hw_dwords = force_hw_dwords;
	dev_data->bus.grc_input_en = grc_input_en;
	dev_data->bus.unify_inputs = unify_inputs;
	dev_data->bus.next_hw_id = unify_inputs ? 0 : 1;
	dev_data->bus.num_enabled_blocks = grc_input_en ? 1 : 0;
	/* init special DBG block */
	if (grc_input_en) {
		dev_data->bus.blocks[BLOCK_DBG].enabled = true;
		dev_data->bus.blocks[BLOCK_DBG].hw_id = 0;
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_set_pci_output(struct qed_hwfn *p_hwfn,
					   struct qed_ptt *p_ptt,
					   u16 buf_size_kb)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	void *pci_buf;
	dma_addr_t pci_buf_phys_addr;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_set_pci_output: buf_size_kb = %d\n", buf_size_kb);
	if (dev_data->bus.target != DBG_BUS_TARGET_ID_INT_BUF)
		return DBG_STATUS_OUTPUT_ALREADY_SET;
	if (dev_data->bus.state != DBG_BUS_STATE_READY ||
	    dev_data->bus.pci_buf.size > 0)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	dev_data->bus.target = DBG_BUS_TARGET_ID_PCI;
	dev_data->bus.pci_buf.size = buf_size_kb * 1024;
	if (dev_data->bus.pci_buf.size % PCI_PKT_SIZE_IN_BYTES)
		return DBG_STATUS_INVALID_ARGS;
	pci_buf = dma_alloc_coherent(&p_hwfn->cdev->pdev->dev,
				     dev_data->bus.pci_buf.size,
				     &pci_buf_phys_addr, GFP_KERNEL);
	if (!pci_buf)
		return DBG_STATUS_PCI_BUF_ALLOC_FAILED;
	memcpy(&dev_data->bus.pci_buf.phys_addr, &pci_buf_phys_addr,
	       sizeof(pci_buf_phys_addr));
	dev_data->bus.pci_buf.virt_addr.lo = (u32) ((u64) (uintptr_t) pci_buf);
	dev_data->bus.pci_buf.virt_addr.hi =
	    (u32) ((u64) (uintptr_t) pci_buf >> 32);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_PCI_EXT_BUFFER_STRT_ADDR_LSB,
	       dev_data->bus.pci_buf.phys_addr.lo);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_PCI_EXT_BUFFER_STRT_ADDR_MSB,
	       dev_data->bus.pci_buf.phys_addr.hi);
	qed_wr(p_hwfn,
	       p_ptt, DBG_REG_TARGET_PACKET_SIZE, PCI_PKT_SIZE_IN_CHUNKS);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_PCI_EXT_BUFFER_SIZE,
	       dev_data->bus.pci_buf.size / PCI_PKT_SIZE_IN_BYTES);
	qed_wr(p_hwfn, p_ptt, DBG_REG_PCI_FUNC_NUM,
	       OPAQUE_FID(p_hwfn->rel_pf_id));
	qed_wr(p_hwfn, p_ptt, DBG_REG_PCI_LOGIC_ADDR, PCI_PHYS_ADDR_TYPE);
	qed_wr(p_hwfn, p_ptt, DBG_REG_PCI_REQ_CREDIT, PCI_REQ_CREDIT);
	qed_wr(p_hwfn, p_ptt, DBG_REG_DEBUG_TARGET, DBG_BUS_TARGET_ID_PCI);
	qed_wr(p_hwfn, p_ptt, DBG_REG_OUTPUT_ENABLE, TARGET_EN_MASK_PCI);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_set_nw_output(struct qed_hwfn *p_hwfn,
					  struct qed_ptt *p_ptt,
					  u8 port_id,
					  u32 dest_addr_lo32,
					  u16 dest_addr_hi16,
					  u16
					  data_limit_size_kb,
					  bool
					  send_to_other_engine,
					  bool rcv_from_other_engine)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_set_nw_output: port_id = %d, dest_addr_lo32 = 0x%x, dest_addr_hi16 = 0x%x, data_limit_size_kb = %d, send_to_other_engine = %d, rcv_from_other_engine = %d\n",
		   port_id,
		   dest_addr_lo32,
		   dest_addr_hi16,
		   data_limit_size_kb,
		   send_to_other_engine, rcv_from_other_engine);
	if (dev_data->bus.target != DBG_BUS_TARGET_ID_INT_BUF)
		return DBG_STATUS_OUTPUT_ALREADY_SET;
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (port_id >=
	    s_chip_defs[dev_data->chip_id].per_platform[dev_data->
							platform_id].num_ports
	    || (send_to_other_engine && rcv_from_other_engine))
		return DBG_STATUS_INVALID_ARGS;
	dev_data->bus.target = DBG_BUS_TARGET_ID_NIG;
	dev_data->bus.rcv_from_other_engine = rcv_from_other_engine;
	qed_wr(p_hwfn, p_ptt, DBG_REG_OUTPUT_ENABLE, TARGET_EN_MASK_NIG);
	qed_wr(p_hwfn, p_ptt, DBG_REG_DEBUG_TARGET, DBG_BUS_TARGET_ID_NIG);
	if (send_to_other_engine)
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_OTHER_ENGINE_MODE,
		       DBG_BUS_OTHER_ENGINE_MODE_CROSS_ENGINE_TX);
	else
		qed_wr(p_hwfn, p_ptt, NIG_REG_DEBUG_PORT, port_id);
	if (rcv_from_other_engine) {
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_OTHER_ENGINE_MODE,
		       DBG_BUS_OTHER_ENGINE_MODE_CROSS_ENGINE_RX);
	} else {
		qed_wr(p_hwfn, p_ptt, DBG_REG_ETHERNET_HDR_WIDTH, 0);	/* 14 bytes */
		qed_wr(p_hwfn, p_ptt, DBG_REG_ETHERNET_HDR_7, dest_addr_lo32);
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_ETHERNET_HDR_6,
		       (u32) SRC_MAC_ADDR_LO16 | ((u32) dest_addr_hi16 << 16));
		qed_wr(p_hwfn, p_ptt, DBG_REG_ETHERNET_HDR_5,
		       SRC_MAC_ADDR_HI32);
		qed_wr(p_hwfn, p_ptt, DBG_REG_ETHERNET_HDR_4,
		       (u32) ETH_TYPE << 16);
		qed_wr(p_hwfn, p_ptt, DBG_REG_TARGET_PACKET_SIZE,
		       NIG_PKT_SIZE_IN_CHUNKS);
		if (data_limit_size_kb)
			qed_wr(p_hwfn,
			       p_ptt,
			       DBG_REG_NIG_DATA_LIMIT_SIZE,
			       (data_limit_size_kb *
				1024) / CHUNK_SIZE_IN_BYTES);
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_enable_block(struct qed_hwfn *p_hwfn,
					 struct qed_ptt *p_ptt,
					 enum block_id block,
					 u8 line_num,
					 u8 cycle_en,
					 u8 right_shift,
					 u8 force_valid, u8 force_frame)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_enable_block: block = %d, line_num = %d, cycle_en = 0x%x, right_shift = %d, force_valid = 0x%x, force_frame = 0x%x\n",
		   block,
		   line_num, cycle_en, right_shift, force_valid, force_frame);
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (block >= MAX_BLOCK_ID)
		return DBG_STATUS_INVALID_ARGS;
	if (dev_data->bus.blocks[block].enabled)
		return DBG_STATUS_BLOCK_ALREADY_ENABLED;
	if (!s_block_defs[block]->has_dbg_bus[dev_data->chip_id] ||
	    cycle_en > MAX_CYCLE_UNITS_MASK ||
	    force_valid > MAX_CYCLE_UNITS_MASK ||
	    force_frame > MAX_CYCLE_UNITS_MASK ||
	    right_shift > UNITS_PER_CYCLE - 1)
		return DBG_STATUS_INVALID_ARGS;
	if ((dev_data->bus.grc_input_en || dev_data->bus.timestamp_input_en) &&
	    (((cycle_en & 0x1) && right_shift == 0) ||
	     ((cycle_en & 0x2) && right_shift == 1) ||
	     ((cycle_en & 0x4) && right_shift == 2) ||
	     ((cycle_en & 0x8) && right_shift == 3)))
		return DBG_STATUS_INPUT_OVERLAP;
	if (dev_data->block_in_reset[block])
		return DBG_STATUS_BLOCK_IN_RESET;
	dev_data->bus.blocks[block].enabled = true;
	dev_data->bus.blocks[block].hw_id = dev_data->bus.next_hw_id;
	dev_data->bus.blocks[block].line_num = line_num;
	dev_data->bus.blocks[block].cycle_en = cycle_en;
	dev_data->bus.blocks[block].right_shift = right_shift;
	dev_data->bus.blocks[block].force_valid = force_valid;
	dev_data->bus.blocks[block].force_frame = force_frame;
	dev_data->bus.num_enabled_blocks++;
	if (!dev_data->bus.unify_inputs) {
		dev_data->bus.next_hw_id++;
		if (dev_data->bus.next_hw_id == NUM_HW_IDS)
			return DBG_STATUS_TOO_MANY_INPUTS;
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_enable_storm(struct qed_hwfn *p_hwfn,
					 enum dbg_storms storm,
					 enum dbg_bus_storm_modes storm_mode)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_enable_storm: storm = %d, storm_mode = %d\n",
		   storm, storm_mode);
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (dev_data->bus.hw_dwords >= 4)
		return DBG_STATUS_HW_ONLY_RECORDING;
	if (storm >= MAX_DBG_STORMS)
		return DBG_STATUS_INVALID_ARGS;
	if (storm_mode >= MAX_DBG_BUS_STORM_MODES)
		return DBG_STATUS_INVALID_ARGS;
	/* temporary assert, can be removed when HW supports recording slow and fast channels siumltaneously */
	if (dev_data->bus.storms[storm].fast_enabled ||
	    dev_data->bus.storms[storm].slow_enabled)
		return DBG_STATUS_STORM_ALREADY_ENABLED;
	if (s_storm_mode_defs[storm_mode].is_fast_dbg) {
		dev_data->bus.storms[storm].fast_enabled = true;
		dev_data->bus.storms[storm].fast_mode = (u8) storm_mode;
	} else {
		dev_data->bus.storms[storm].slow_enabled = true;
		dev_data->bus.storms[storm].slow_mode = (u8) storm_mode;
	}
	dev_data->bus.storms[storm].hw_id = dev_data->bus.next_hw_id;
	dev_data->bus.num_enabled_storms++;
	if (!dev_data->bus.unify_inputs) {
		dev_data->bus.next_hw_id++;
		if (dev_data->bus.next_hw_id == NUM_HW_IDS)
			return DBG_STATUS_TOO_MANY_INPUTS;
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_enable_timestamp(struct qed_hwfn *p_hwfn,
					     struct qed_ptt *p_ptt,
					     u8 valid_en,
					     u8 frame_en, u32 tick_len)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_enable_timestamp: valid_en = 0x%x, frame_en = 0x%x, tick_len = %d\n",
		   valid_en, frame_en, tick_len);
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (valid_en > 0x7 || frame_en > 0x7)
		return DBG_STATUS_INVALID_ARGS;
	if (dev_data->bus.grc_input_en)
		return DBG_STATUS_INPUT_OVERLAP;
	dev_data->bus.timestamp_input_en = true;
	if (!dev_data->bus.blocks[BLOCK_DBG].enabled) {
		dev_data->bus.blocks[BLOCK_DBG].enabled = true;
		dev_data->bus.blocks[BLOCK_DBG].hw_id = 0;
		dev_data->bus.num_enabled_blocks++;
	}
	qed_wr(p_hwfn, p_ptt, DBG_REG_TIMESTAMP_VALID_EN, valid_en);
	qed_wr(p_hwfn, p_ptt, DBG_REG_TIMESTAMP_FRAME_EN, frame_en);
	qed_wr(p_hwfn, p_ptt, DBG_REG_TIMESTAMP_TICK, tick_len);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_add_eid_range_sem_filter(struct qed_hwfn *p_hwfn,
						     enum dbg_storms storm,
						     u8 min_eid, u8 max_eid)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_add_eid_range_sem_filter: storm = %d, min_eid = 0x%x, max_eid = 0x%x\n",
		   storm, min_eid, max_eid);
	if (storm >= MAX_DBG_STORMS)
		return DBG_STATUS_INVALID_ARGS;
	if (min_eid > max_eid)
		return DBG_STATUS_INVALID_ARGS;
	if (!dev_data->bus.storms[storm].fast_enabled &&
	    !dev_data->bus.storms[storm].slow_enabled)
		return DBG_STATUS_STORM_NOT_ENABLED;
	dev_data->bus.storms[storm].eid_filter_en = 1;
	dev_data->bus.storms[storm].eid_range_not_mask = 1;
	dev_data->bus.storms[storm].eid_filter_params.range.min = min_eid;
	dev_data->bus.storms[storm].eid_filter_params.range.max = max_eid;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_add_eid_mask_sem_filter(struct qed_hwfn *p_hwfn,
						    enum dbg_storms storm,
						    u8 eid_val, u8 eid_mask)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_add_eid_mask_sem_filter: storm = %d, eid_val = 0x%x, eid_mask = 0x%x\n",
		   storm, eid_val, eid_mask);
	if (storm >= MAX_DBG_STORMS)
		return DBG_STATUS_INVALID_ARGS;
	if (!dev_data->bus.storms[storm].fast_enabled &&
	    !dev_data->bus.storms[storm].slow_enabled)
		return DBG_STATUS_STORM_NOT_ENABLED;
	dev_data->bus.storms[storm].eid_filter_en = 1;
	dev_data->bus.storms[storm].eid_range_not_mask = 0;
	dev_data->bus.storms[storm].eid_filter_params.mask.val = eid_val;
	dev_data->bus.storms[storm].eid_filter_params.mask.mask = eid_mask;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_add_cid_sem_filter(struct qed_hwfn *p_hwfn,
					       enum dbg_storms storm, u32 cid)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_add_cid_sem_filter: storm = %d, cid = 0x%x\n",
		   storm, cid);
	if (storm >= MAX_DBG_STORMS)
		return DBG_STATUS_INVALID_ARGS;
	if (!dev_data->bus.storms[storm].fast_enabled &&
	    !dev_data->bus.storms[storm].slow_enabled)
		return DBG_STATUS_STORM_NOT_ENABLED;
	dev_data->bus.storms[storm].cid_filter_en = 1;
	dev_data->bus.storms[storm].cid = cid;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_enable_filter(struct qed_hwfn *p_hwfn,
					  struct qed_ptt *p_ptt,
					  enum block_id block, u8 const_msg_len)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_enable_filter: block = %d, const_msg_len = %d\n",
		   block, const_msg_len);
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (dev_data->bus.filter_en)
		return DBG_STATUS_FILTER_ALREADY_ENABLED;
	if (dev_data->bus.hw_dwords == 8)
		return DBG_STATUS_NO_FILTER_TRIGGER_64B;
	if (block >= MAX_BLOCK_ID)
		return DBG_STATUS_INVALID_ARGS;
	if (!dev_data->bus.blocks[block].enabled)
		return DBG_STATUS_BLOCK_NOT_ENABLED;
	dev_data->bus.filter_en = true;
	dev_data->bus.next_constraint_id = 0;
	dev_data->bus.adding_filter = true;
	qed_wr(p_hwfn,
	       p_ptt, DBG_REG_FILTER_ID_NUM, dev_data->bus.blocks[block].hw_id);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_FILTER_MSG_LENGTH_ENABLE, const_msg_len > 0 ? 1 : 0);
	if (const_msg_len > 0)
		qed_wr(p_hwfn,
		       p_ptt, DBG_REG_FILTER_MSG_LENGTH, const_msg_len - 1);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_enable_trigger(struct qed_hwfn *p_hwfn,
					   struct qed_ptt *p_ptt,
					   bool rec_pre_trigger,
					   u8 pre_chunks,
					   bool
					   rec_post_trigger,
					   u32 post_cycles,
					   bool
					   filter_pre_trigger,
					   bool filter_post_trigger)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	enum dbg_bus_pre_trigger_types pre_trigger_type =
	    DBG_BUS_PRE_TRIGGER_DROP;
	enum dbg_bus_post_trigger_types post_trigger_type =
	    DBG_BUS_POST_TRIGGER_DROP;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_enable_trigger: rec_pre_trigger = %d, pre_chunks = %d, rec_post_trigger = %d, post_cycles = %d, filter_pre_trigger = %d, filter_post_trigger = %d\n",
		   rec_pre_trigger,
		   pre_chunks,
		   rec_post_trigger,
		   post_cycles, filter_pre_trigger, filter_post_trigger);
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	if (dev_data->bus.trigger_en)
		return DBG_STATUS_TRIGGER_ALREADY_ENABLED;
	if (dev_data->bus.hw_dwords == 8)
		return DBG_STATUS_NO_FILTER_TRIGGER_64B;
	if (rec_pre_trigger && pre_chunks >= INT_BUF_SIZE_IN_CHUNKS)
		return DBG_STATUS_INVALID_ARGS;
	dev_data->bus.trigger_en = true;
	dev_data->bus.filter_pre_trigger = filter_pre_trigger;
	dev_data->bus.filter_post_trigger = filter_post_trigger;
	if (rec_pre_trigger) {
		pre_trigger_type =
		    pre_chunks ? DBG_BUS_PRE_TRIGGER_NUM_CHUNKS :
		    DBG_BUS_PRE_TRIGGER_START_FROM_ZERO;
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_RCRD_ON_WINDOW_PRE_NUM_CHUNKS, pre_chunks);
	}
	if (rec_post_trigger) {
		post_trigger_type = DBG_BUS_POST_TRIGGER_RECORD;
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_RCRD_ON_WINDOW_POST_NUM_CYCLES,
		       post_cycles ? post_cycles : 0xffffffff);
	}
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_RCRD_ON_WINDOW_PRE_TRGR_EVNT_MODE, pre_trigger_type);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_RCRD_ON_WINDOW_POST_TRGR_EVNT_MODE, post_trigger_type);
	qed_wr(p_hwfn, p_ptt, DBG_REG_TRIGGER_ENABLE, 1);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_add_trigger_state(struct qed_hwfn *p_hwfn,
					      struct qed_ptt *p_ptt,
					      enum block_id block,
					      u8 const_msg_len,
					      u16 count_to_next)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u8 reg_offset;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_add_trigger_state: block = %d, const_msg_len = %d, count_to_next = %d\n",
		   block, const_msg_len, count_to_next);
	if (!dev_data->bus.trigger_en)
		return DBG_STATUS_TRIGGER_NOT_ENABLED;
	if (dev_data->bus.next_trigger_state == FINAL_TRIGGER_STATE)
		return DBG_STATUS_TOO_MANY_TRIGGER_STATES;
	if (block >= MAX_BLOCK_ID)
		return DBG_STATUS_INVALID_ARGS;
	if (!dev_data->bus.blocks[block].enabled)
		return DBG_STATUS_BLOCK_NOT_ENABLED;
	if (count_to_next == 0)
		return DBG_STATUS_INVALID_ARGS;
	dev_data->bus.next_constraint_id = 0;
	dev_data->bus.adding_filter = false;
	/* set trigger state registers */
	reg_offset = dev_data->bus.next_trigger_state * BYTES_IN_DWORD;
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_TRIGGER_STATE_ID_0 + reg_offset,
	       dev_data->bus.blocks[block].hw_id);
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_TRIGGER_STATE_MSG_LENGTH_ENABLE_0 + reg_offset,
	       const_msg_len > 0 ? 1 : 0);
	if (const_msg_len > 0)
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_TRIGGER_STATE_MSG_LENGTH_0 + reg_offset,
		       const_msg_len - 1);
	/* set trigger set registers */
	reg_offset = dev_data->bus.next_trigger_state *
	    TRIGGER_SETS_PER_STATE * BYTES_IN_DWORD;
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_TRIGGER_STATE_SET_COUNT_0 + reg_offset, count_to_next);
	/* set next state to final state, and overwrite previous next state (if any) */
	qed_wr(p_hwfn,
	       p_ptt,
	       DBG_REG_TRIGGER_STATE_SET_NXT_STATE_0 + reg_offset,
	       FINAL_TRIGGER_STATE);
	if (dev_data->bus.next_trigger_state > 0) {
		reg_offset =
		    (dev_data->bus.next_trigger_state -
		     1) * TRIGGER_SETS_PER_STATE * BYTES_IN_DWORD;
		qed_wr(p_hwfn,
		       p_ptt,
		       DBG_REG_TRIGGER_STATE_SET_NXT_STATE_0 + reg_offset,
		       dev_data->bus.next_trigger_state);
	}
	dev_data->bus.next_trigger_state++;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_add_constraint(struct qed_hwfn *p_hwfn,
					   struct qed_ptt *p_ptt,
					   enum dbg_bus_constraint_ops
					   constraint_op,
					   u32
					   data_val,
					   u32
					   data_mask,
					   bool
					   compare_frame,
					   u8
					   frame_bit,
					   u8
					   cycle_offset,
					   u8 dword_offset, bool is_mandatory)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u16 offset = cycle_offset * UNITS_PER_CYCLE + dword_offset;
	u16 range = 0;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_add_constraint: op = %d, data_val = 0x%x, data_mask = 0x%x, compare_frame = %d, frame_bit = %d, cycle_offset = %d, dword_offset = %d, is_mandatory = %d\n",
		   constraint_op,
		   data_val,
		   data_mask,
		   compare_frame,
		   frame_bit, cycle_offset, dword_offset, is_mandatory);
	if (!dev_data->bus.filter_en && !dev_data->bus.trigger_en)
		return DBG_STATUS_CANT_ADD_CONSTRAINT;
	if (dev_data->bus.trigger_en && !dev_data->bus.adding_filter &&
	    dev_data->bus.next_trigger_state == 0)
		return DBG_STATUS_CANT_ADD_CONSTRAINT;
	if (dev_data->bus.next_constraint_id >= MAX_CONSTRAINTS)
		return DBG_STATUS_TOO_MANY_CONSTRAINTS;
	if (constraint_op >= MAX_DBG_BUS_CONSTRAINT_OPS || frame_bit > 1 ||
	    dword_offset > 3 ||
	    (dev_data->bus.adding_filter && cycle_offset > 3))
		return DBG_STATUS_INVALID_ARGS;
	if (compare_frame &&
	    constraint_op != DBG_BUS_CONSTRAINT_OP_EQ &&
	    constraint_op != DBG_BUS_CONSTRAINT_OP_NE)
		return DBG_STATUS_INVALID_ARGS;
	/* prepare data mask and range */
	if (constraint_op == DBG_BUS_CONSTRAINT_OP_EQ ||
	    constraint_op == DBG_BUS_CONSTRAINT_OP_NE) {
		data_mask = ~data_mask;
	} else {
		/* extract lsb and width from mask */
		u8 lsb, width;
		if (!data_mask)
			return DBG_STATUS_INVALID_ARGS;
		for (lsb = 0; lsb < 32 && !(data_mask & 1);
		     lsb++, data_mask >>= 1) ;
		for (width = 0;
		     width < 32 - lsb && (data_mask & 1);
		     width++, data_mask >>= 1) ;
		if (data_mask)
			return DBG_STATUS_INVALID_ARGS;
		range = (lsb << 5) | (width - 1);
	}
	qed_bus_set_constraint(p_hwfn,
			       p_ptt,
			       dev_data->bus.adding_filter ? 1 : 0,
			       dev_data->bus.next_constraint_id,
			       s_constraint_op_defs[constraint_op].hw_op_val,
			       data_val,
			       data_mask,
			       frame_bit,
			       compare_frame ? 0 : 1,
			       offset,
			       range,
			       s_constraint_op_defs[constraint_op].is_cyclic ?
			       1 : 0, is_mandatory ? 1 : 0);
	/* if first constraint, fill other 3 constraints with dummy
	 * constraints that always match (using the same offset) */
	if (dev_data->bus.next_constraint_id == 0) {
		u8 i;
		for (i = 1; i < MAX_CONSTRAINTS; i++)
			qed_bus_set_constraint(p_hwfn,
					       p_ptt,
					       dev_data->bus.adding_filter ? 1
					       : 0,
					       i,
					       DBG_BUS_CONSTRAINT_OP_EQ,
					       0,
					       0xffffffff,
					       0, 1, offset, 0, 0, 1);
	}
	dev_data->bus.next_constraint_id++;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_start(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u16 hw_id_mask = 0;
	u32 client_mask = 0;
	enum dbg_bus_frame_modes dbg_framing_mode = DBG_BUS_FRAME_MODE_0HW_4ST;
	enum dbg_bus_filter_types filter_type = DBG_BUS_FILTER_TYPE_ON;
	u32 block_id, i;
	u8 storm_id;

	DP_VERBOSE(p_hwfn, QED_MSG_DEBUG, "dbg_bus_start\n");
	if (dev_data->bus.state != DBG_BUS_STATE_READY)
		return DBG_STATUS_DBG_BLOCK_NOT_RESET;
	/* check if any input was enabled */
	if (!dev_data->bus.num_enabled_storms &&
	    !dev_data->bus.num_enabled_blocks &&
	    !dev_data->bus.rcv_from_other_engine)
		return DBG_STATUS_NO_INPUT_ENABLED;
	/* check if too many input types were enabled (storm+dbgmux) */
	if (dev_data->bus.num_enabled_storms &&
	    dev_data->bus.num_enabled_blocks)
		return DBG_STATUS_TOO_MANY_INPUTS;
	/* check if too many input types were enabled (storm fast+slow), and if SEMI sync FIFO is empty */
	if (dev_data->bus.num_enabled_storms) {
		for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
			if (dev_data->bus.storms[storm_id].fast_enabled &&
			    dev_data->bus.storms[storm_id].slow_enabled)
				return DBG_STATUS_TOO_MANY_INPUTS;
			if ((dev_data->bus.storms[storm_id].fast_enabled ||
			     dev_data->bus.storms[storm_id].slow_enabled) &&
			    !qed_rd(p_hwfn, p_ptt,
				    s_storm_defs
				    [storm_id].sem_sync_dbg_empty_addr))
				return DBG_STATUS_SEMI_FIFO_NOT_EMPTY;
		}
	}
	/* check if more than one block is enabled, a filter is enabled, and inputs are not unified (can't be done due to a HW bug) */
	if (dev_data->bus.num_enabled_blocks > 1 && dev_data->bus.filter_en &&
	    !dev_data->bus.unify_inputs)
		return DBG_STATUS_MULTI_BLOCKS_WITH_FILTER;
	/* choose framing mode */
	if (dev_data->bus.hw_dwords == 0 && dev_data->bus.num_enabled_blocks)
		dev_data->bus.hw_dwords = 4;
	switch (dev_data->bus.hw_dwords) {
	case 0:
		dbg_framing_mode = DBG_BUS_FRAME_MODE_0HW_4ST;
		break;
	case 4:
		dbg_framing_mode = DBG_BUS_FRAME_MODE_4HW_0ST;
		break;
	case 8:
		dbg_framing_mode = DBG_BUS_FRAME_MODE_8HW_0ST;
		break;
	}
	qed_bus_set_framing_mode(p_hwfn, p_ptt, dbg_framing_mode);
	/* disable storm stall if recording to internal buffer in one-shot */
	qed_wr(p_hwfn, p_ptt, DBG_REG_NO_GRANT_ON_FULL,
	       (dev_data->bus.target == DBG_BUS_TARGET_ID_INT_BUF &&
		dev_data->bus.one_shot_en) ? 0 : 1);
	/* find filter type */
	if (dev_data->bus.trigger_en) {
		if (dev_data->bus.filter_pre_trigger)
			filter_type = dev_data->bus.filter_post_trigger ?
			    DBG_BUS_FILTER_TYPE_ON : DBG_BUS_FILTER_TYPE_PRE;
		else
			filter_type = dev_data->bus.filter_post_trigger ?
			    DBG_BUS_FILTER_TYPE_POST : DBG_BUS_FILTER_TYPE_OFF;
	}
	/* prepare debug bus for the enabled Storms */
	if (dev_data->bus.num_enabled_storms) {
		u32 storm_id_mask = 0;
		u8 next_storm_id = 0;
		for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
			if (dev_data->bus.storms[storm_id].fast_enabled ||
			    dev_data->bus.storms[storm_id].slow_enabled) {
				client_mask |=
				    BIT(s_storm_defs[storm_id].dbg_client_id
					[dev_data->chip_id]);
				storm_id_mask |=
				    (dev_data->bus.storms[storm_id].
				     hw_id << (storm_id * HW_ID_BITS));
			}
		}
		qed_wr(p_hwfn, p_ptt, DBG_REG_STORM_ID_NUM, storm_id_mask);
		/* configure calendar */
		for (i = 0; i < NUM_CALENDAR_SLOTS;
		     i++, next_storm_id =
		     (next_storm_id + 1) % MAX_DBG_STORMS) {
			/* find next enabled Storm */
			for (;
			     !dev_data->bus.storms[next_storm_id].fast_enabled
			     &&
			     !dev_data->bus.storms[next_storm_id].slow_enabled;
			     next_storm_id =
			     (next_storm_id + 1) % MAX_DBG_STORMS) ;
			/* configure calendar slot */
			qed_wr(p_hwfn,
			       p_ptt,
			       DBG_REG_CALENDAR_SLOT0 + DWORDS_TO_BYTES(i),
			       next_storm_id);
		}
	}
	/* prepare debug bus for the enabled blocks */
	if (dev_data->bus.num_enabled_blocks) {
		for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++) {
			if (dev_data->bus.blocks[block_id].enabled &&
			    block_id != BLOCK_DBG) {
				u8 unit_id;
				u8 shifted_cycle_en =
				    dev_data->bus.blocks[block_id].cycle_en
				    >>
				    dev_data->bus.blocks[block_id].right_shift;
				// check for  wrap-around
				if (!shifted_cycle_en)
					shifted_cycle_en =
					    dev_data->bus.
					    blocks[block_id].cycle_en <<
					    (UNITS_PER_CYCLE -
					     dev_data->bus.
					     blocks[block_id].right_shift);
				client_mask |=
				    BIT(s_block_defs[block_id]->dbg_client_id
					[dev_data->chip_id]);
				if (dev_data->bus.blocks[block_id].hw_id > 0)
					for (unit_id = 0;
					     unit_id < UNITS_PER_CYCLE;
					     unit_id++)
						if (shifted_cycle_en &
						    BIT(unit_id))
							hw_id_mask |=
							    (dev_data->
							     bus.blocks
							     [block_id].
							     hw_id << (unit_id *
								       HW_ID_BITS));
			}
		}
	}
	/* configure GRC input */
	if (dev_data->bus.grc_input_en)
		client_mask |= BIT(DBG_BUS_CLIENT_CPU);
	/* configure timestamp input */
	if (dev_data->bus.timestamp_input_en)
		client_mask |= BIT(DBG_BUS_CLIENT_TIMESTAMP);
	/* configure debug block */
	qed_wr(p_hwfn, p_ptt, DBG_REG_HW_ID_NUM, hw_id_mask);
	qed_wr(p_hwfn, p_ptt, DBG_REG_FILTER_ENABLE,
	       (u8) (dev_data->bus.filter_en ? filter_type :
		     DBG_BUS_FILTER_TYPE_OFF));
	qed_bus_enable_clients(p_hwfn, p_ptt, client_mask);
	qed_wr(p_hwfn, p_ptt, DBG_REG_TIMESTAMP, 0);
	/* configure enabled blocks */
	if (dev_data->bus.num_enabled_blocks) {
		for (i = 0; i < MAX_BLOCK_ID; i++)
			if (dev_data->bus.blocks[i].enabled && i != BLOCK_DBG) {
				qed_config_dbg_line(p_hwfn,
						    p_ptt,
						    (enum block_id)i,
						    dev_data->bus.
						    blocks[i].line_num,
						    dev_data->bus.
						    blocks[i].cycle_en,
						    dev_data->bus.
						    blocks[i].right_shift,
						    dev_data->bus.
						    blocks[i].force_valid,
						    dev_data->bus.
						    blocks[i].force_frame);
			}
	}
	/* configure additional K2 PCIE registers */
	if (dev_data->chip_id == CHIP_K2 &&
	    (dev_data->bus.blocks[BLOCK_PCIE].enabled ||
	     dev_data->bus.blocks[BLOCK_PHY_PCIE].enabled)) {
		qed_wr(p_hwfn, p_ptt, PCIE_REG_DBG_SAMPLING_INTERVAL, 1);
		qed_wr(p_hwfn, p_ptt, PCIE_REG_DBG_REPEAT_THRESHOLD_COUNT, 1);
		qed_wr(p_hwfn, p_ptt, PCIE_REG_DBG_FW_TRIGGER_ENABLE, 1);
	}
	/* enable debug block */
	qed_bus_enable_dbg_block(p_hwfn, p_ptt, 1);
	/* configure enabled Storms */
	if (dev_data->bus.num_enabled_storms)
		for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++)
			if (dev_data->bus.storms[storm_id].fast_enabled ||
			    dev_data->bus.storms[storm_id].slow_enabled)
				qed_bus_enable_storm(p_hwfn,
						     p_ptt,
						     (enum dbg_storms)storm_id,
						     filter_type);
	dev_data->bus.state = DBG_BUS_STATE_RECORDING;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_stop(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	enum dbg_status status = DBG_STATUS_OK;

	DP_VERBOSE(p_hwfn, QED_MSG_DEBUG, "dbg_bus_stop\n");
	if (dev_data->bus.state != DBG_BUS_STATE_RECORDING)
		return DBG_STATUS_RECORDING_NOT_STARTED;
	status = qed_bus_disable_inputs(p_hwfn, p_ptt, true);
	if (status != DBG_STATUS_OK)
		return status;
	qed_wr(p_hwfn, p_ptt, DBG_REG_CPU_TIMEOUT, 1);
	msleep(FLUSH_DELAY_MS);
	qed_bus_enable_dbg_block(p_hwfn, p_ptt, false);
	/* check if trigger worked */
	if (dev_data->bus.trigger_en) {
		u32 trigger_state = qed_rd(p_hwfn,
					   p_ptt,
					   DBG_REG_TRIGGER_STATUS_CUR_STATE);
		if (trigger_state != FINAL_TRIGGER_STATE)
			return DBG_STATUS_DATA_DIDNT_TRIGGER;
	}
	dev_data->bus.state = DBG_BUS_STATE_STOPPED;
	return status;
}

enum dbg_status qed_dbg_bus_get_dump_buf_size(struct qed_hwfn *p_hwfn,
					      struct qed_ptt *p_ptt,
					      u32 * buf_size)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	enum dbg_status status = qed_dbg_dev_init(p_hwfn,
						  p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	/* add dump header */
	*buf_size = (u32) qed_bus_dump_hdr(p_hwfn, p_ptt, NULL, false);
	switch (dev_data->bus.target) {
	case DBG_BUS_TARGET_ID_INT_BUF:
		*buf_size += INT_BUF_SIZE_IN_DWORDS;
		break;
	case DBG_BUS_TARGET_ID_PCI:
		*buf_size += BYTES_TO_DWORDS(dev_data->bus.pci_buf.size);
		break;
	default:
		break;
	}
	/* add last section */
	*buf_size += qed_dump_last_section(NULL, 0, false);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_bus_dump(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 u32 * dump_buf,
				 u32 buf_size_in_dwords,
				 u32 * num_dumped_dwords)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 offset = 0, min_buf_size_in_dwords, block_id;
	u8 storm_id;
	enum dbg_status status = qed_dbg_bus_get_dump_buf_size(p_hwfn,
							       p_ptt,
							       &min_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_bus_dump: dump_buf = 0x%p, buf_size_in_dwords = %d\n",
		   dump_buf, buf_size_in_dwords);
	if (dev_data->bus.state != DBG_BUS_STATE_RECORDING &&
	    dev_data->bus.state != DBG_BUS_STATE_STOPPED)
		return DBG_STATUS_RECORDING_NOT_STARTED;
	if (dev_data->bus.state == DBG_BUS_STATE_RECORDING) {
		enum dbg_status stop_state = qed_dbg_bus_stop(p_hwfn, p_ptt);
		if (stop_state != DBG_STATUS_OK)
			return stop_state;
	}
	if (buf_size_in_dwords < min_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	if (dev_data->bus.target == DBG_BUS_TARGET_ID_PCI &&
	    !dev_data->bus.pci_buf.size)
		return DBG_STATUS_PCI_BUF_NOT_ALLOCATED;
	/* dump header */
	offset += qed_bus_dump_hdr(p_hwfn, p_ptt, dump_buf + offset, true);
	if (dev_data->bus.target != DBG_BUS_TARGET_ID_NIG) {
		/* dump recorded data */
		u32 recorded_dwords = qed_bus_dump_data(p_hwfn,
							p_ptt,
							dump_buf + offset,
							true);
		if (recorded_dwords == 0)
			return DBG_STATUS_NO_DATA_RECORDED;
		if (recorded_dwords % CHUNK_SIZE_IN_DWORDS != 0)
			return DBG_STATUS_DUMP_NOT_CHUNK_ALIGNED;
		offset += recorded_dwords;
	}
	/* dump last section */
	offset += qed_dump_last_section(dump_buf, offset, true);
	// if recorded to PCI buffer - free the buffer
	qed_bus_free_pci_buf(p_hwfn);
	/* clear debug bus parameters */
	dev_data->bus.state = DBG_BUS_STATE_IDLE;
	dev_data->bus.num_enabled_blocks = 0;
	dev_data->bus.num_enabled_storms = 0;
	dev_data->bus.filter_en = dev_data->bus.trigger_en = 0;
	for (block_id = 0; block_id < MAX_BLOCK_ID; block_id++)
		dev_data->bus.blocks[block_id].enabled = false;
	for (storm_id = 0; storm_id < MAX_DBG_STORMS; storm_id++) {
		dev_data->bus.storms[storm_id].fast_enabled =
		    dev_data->bus.storms[storm_id].slow_enabled = false;
		dev_data->bus.storms[storm_id].eid_filter_en =
		    dev_data->bus.storms[storm_id].cid_filter_en = 0;
	}
	*num_dumped_dwords = offset;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_grc_config(struct qed_hwfn *p_hwfn,
				   enum dbg_grc_params grc_param, u32 val)
{
	int i;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_DEBUG,
		   "dbg_grc_config: paramId = %d, val = %d\n", grc_param, val);
	if (grc_param >= MAX_DBG_GRC_PARAMS)
		return DBG_STATUS_INVALID_ARGS;
	if (val < s_grc_param_defs[grc_param].min ||
	    val > s_grc_param_defs[grc_param].max)
		return DBG_STATUS_INVALID_ARGS;
	if (s_grc_param_defs[grc_param].is_preset) {
		/* preset param */
		if (val) {
			/* update all params with the preset values */
			for (i = 0; i < MAX_DBG_GRC_PARAMS; i++) {
				u32 preset_val;
				if (grc_param == DBG_GRC_PARAM_EXCLUDE_ALL)
					preset_val =
					    s_grc_param_defs
					    [i].exclude_all_preset_val;
				else if (grc_param == DBG_GRC_PARAM_CRASH)
					preset_val =
					    s_grc_param_defs
					    [i].crash_preset_val;
				else
					return DBG_STATUS_INVALID_ARGS;
				qed_grc_set_param(p_hwfn,
						  (enum dbg_grc_params)i,
						  preset_val);
			}
		}
	} else {
		/* regular param - set its value */
		qed_grc_set_param(p_hwfn, grc_param, val);
	}
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_grc_get_dump_buf_size(struct qed_hwfn *p_hwfn,
					      struct qed_ptt *p_ptt,
					      u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (!s_dbg_arrays[BIN_BUF_DBG_MODE_TREE].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_DUMP_REG].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_DUMP_MEM].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_ATTN_BLOCKS].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_ATTN_REGS].ptr)
		return DBG_STATUS_DBG_ARRAY_NOT_SET;
	return qed_grc_dump(p_hwfn, p_ptt, NULL, false, buf_size);
}

enum dbg_status qed_dbg_grc_dump(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 u32 * dump_buf,
				 u32 buf_size_in_dwords,
				 u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_grc_get_dump_buf_size(p_hwfn,
							       p_ptt,
							       &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* doesn't do anything, needed for compile time asserts */
	qed_static_asserts();
	/* GRC Dump */
	status = qed_grc_dump(p_hwfn, p_ptt, dump_buf, true, num_dumped_dwords);
	/* clear all GRC params */
	qed_dbg_grc_clear_params(p_hwfn);
	return status;
}

enum dbg_status qed_dbg_idle_chk_get_dump_buf_size(struct qed_hwfn *p_hwfn,
						   struct qed_ptt *p_ptt,
						   u32 * buf_size)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	enum dbg_status status = qed_dbg_dev_init(p_hwfn,
						  p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (!s_dbg_arrays[BIN_BUF_DBG_MODE_TREE].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_REGS].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_IMMS].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_IDLE_CHK_RULES].ptr)
		return DBG_STATUS_DBG_ARRAY_NOT_SET;
	if (!dev_data->idle_chk.buf_size_set) {
		dev_data->idle_chk.buf_size = qed_idle_chk_dump(p_hwfn,
								p_ptt,
								NULL, false);
		dev_data->idle_chk.buf_size_set = true;
	}
	*buf_size = dev_data->idle_chk.buf_size;
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_idle_chk_dump(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 * dump_buf,
				      u32 buf_size_in_dwords,
				      u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_idle_chk_get_dump_buf_size(p_hwfn,
								    p_ptt,
								    &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	/* Idle Check Dump */
	*num_dumped_dwords = qed_idle_chk_dump(p_hwfn, p_ptt, dump_buf, true);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_mcp_trace_get_dump_buf_size(struct qed_hwfn *p_hwfn,
						    struct qed_ptt *p_ptt,
						    u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	return qed_mcp_trace_dump(p_hwfn, p_ptt, NULL, false, buf_size);
}

enum dbg_status qed_dbg_mcp_trace_dump(struct qed_hwfn *p_hwfn,
				       struct qed_ptt *p_ptt,
				       u32 * dump_buf,
				       u32 buf_size_in_dwords,
				       u32 * num_dumped_dwords)
{
	// validate buffer size
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_mcp_trace_get_dump_buf_size(p_hwfn,
								     p_ptt,
								     &needed_buf_size_in_dwords);

	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	// perform dump
	return qed_mcp_trace_dump(p_hwfn,
				  p_ptt, dump_buf, true, num_dumped_dwords);
}

enum dbg_status qed_dbg_reg_fifo_get_dump_buf_size(struct qed_hwfn *p_hwfn,
						   struct qed_ptt *p_ptt,
						   u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	return qed_reg_fifo_dump(p_hwfn, p_ptt, NULL, false, buf_size);
}

enum dbg_status qed_dbg_reg_fifo_dump(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 * dump_buf,
				      u32 buf_size_in_dwords,
				      u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_reg_fifo_get_dump_buf_size(p_hwfn,
								    p_ptt,
								    &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	return qed_reg_fifo_dump(p_hwfn,
				 p_ptt, dump_buf, true, num_dumped_dwords);
}

enum dbg_status qed_dbg_igu_fifo_get_dump_buf_size(struct qed_hwfn *p_hwfn,
						   struct qed_ptt *p_ptt,
						   u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	return qed_igu_fifo_dump(p_hwfn, p_ptt, NULL, false, buf_size);
}

enum dbg_status qed_dbg_igu_fifo_dump(struct qed_hwfn *p_hwfn,
				      struct qed_ptt *p_ptt,
				      u32 * dump_buf,
				      u32 buf_size_in_dwords,
				      u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_igu_fifo_get_dump_buf_size(p_hwfn,
								    p_ptt,
								    &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	return qed_igu_fifo_dump(p_hwfn,
				 p_ptt, dump_buf, true, num_dumped_dwords);
}

enum dbg_status qed_dbg_protection_override_get_dump_buf_size(struct qed_hwfn
							      *p_hwfn,
							      struct qed_ptt
							      *p_ptt,
							      u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	return qed_protection_override_dump(p_hwfn,
					    p_ptt, NULL, false, buf_size);
}

enum dbg_status qed_dbg_protection_override_dump(struct qed_hwfn *p_hwfn,
						 struct qed_ptt *p_ptt,
						 u32 *
						 dump_buf,
						 u32
						 buf_size_in_dwords,
						 u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status =
	    qed_dbg_protection_override_get_dump_buf_size(p_hwfn,
							  p_ptt,
							  &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	return qed_protection_override_dump(p_hwfn,
					    p_ptt,
					    dump_buf, true, num_dumped_dwords);
}

enum dbg_status qed_dbg_fw_asserts_get_dump_buf_size(struct qed_hwfn *p_hwfn,
						     struct qed_ptt *p_ptt,
						     u32 * buf_size)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);

	*buf_size = 0;
	if (status != DBG_STATUS_OK)
		return status;
	/* update reset state */
	qed_update_blocks_reset_state(p_hwfn, p_ptt);
	*buf_size = qed_fw_asserts_dump(p_hwfn, p_ptt, NULL, false);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_fw_asserts_dump(struct qed_hwfn *p_hwfn,
					struct qed_ptt *p_ptt,
					u32 * dump_buf,
					u32 buf_size_in_dwords,
					u32 * num_dumped_dwords)
{
	u32 needed_buf_size_in_dwords;
	enum dbg_status status = qed_dbg_fw_asserts_get_dump_buf_size(p_hwfn,
								      p_ptt,
								      &needed_buf_size_in_dwords);

	*num_dumped_dwords = 0;
	if (status != DBG_STATUS_OK)
		return status;
	if (buf_size_in_dwords < needed_buf_size_in_dwords)
		return DBG_STATUS_DUMP_BUF_TOO_SMALL;
	*num_dumped_dwords = qed_fw_asserts_dump(p_hwfn, p_ptt, dump_buf, true);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_read_attn(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt,
				  enum block_id block,
				  enum dbg_attn_type attn_type,
				  bool clear_status,
				  struct dbg_attn_block_result *results)
{
	enum dbg_status status = qed_dbg_dev_init(p_hwfn, p_ptt);
	const struct dbg_attn_reg *attn_reg_arr;
	u8 reg_idx, num_attn_regs, num_result_regs = 0;

	if (status != DBG_STATUS_OK)
		return status;
	if (!s_dbg_arrays[BIN_BUF_DBG_MODE_TREE].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_ATTN_BLOCKS].ptr ||
	    !s_dbg_arrays[BIN_BUF_DBG_ATTN_REGS].ptr)
		return DBG_STATUS_DBG_ARRAY_NOT_SET;
	attn_reg_arr =
	    qed_get_block_attn_regs(block, attn_type, &num_attn_regs);
	for (reg_idx = 0; reg_idx < num_attn_regs; reg_idx++) {
		const struct dbg_attn_reg *reg_data = &attn_reg_arr[reg_idx];
		// check mode
		bool eval_mode = GET_FIELD(reg_data->mode.data,
					   DBG_MODE_HDR_EVAL_MODE) > 0;
		u16 modes_buf_offset = GET_FIELD(reg_data->mode.data,
						 DBG_MODE_HDR_MODES_BUF_OFFSET);
		if (!eval_mode || qed_is_mode_match(p_hwfn, &modes_buf_offset)) {
			// mode match - read attention status register
			u32 sts_addr =
			    DWORDS_TO_BYTES(clear_status ?
					    reg_data->sts_clr_address :
					    GET_FIELD(reg_data->data,
						      DBG_ATTN_REG_STS_ADDRESS));
			u32 sts_val = qed_rd(p_hwfn,
					     p_ptt,
					     sts_addr);
			if (sts_val) {
				// attention status register with non-zero value - add to results
				struct dbg_attn_reg_result *reg_result =
				    &results->reg_results[num_result_regs];
				SET_FIELD(reg_result->data,
					  DBG_ATTN_REG_RESULT_STS_ADDRESS,
					  sts_addr);
				SET_FIELD(reg_result->data,
					  DBG_ATTN_REG_RESULT_NUM_ATTN_IDX,
					  GET_FIELD(reg_data->data,
						    DBG_ATTN_REG_NUM_ATTN_IDX));
				reg_result->attn_idx_offset =
				    reg_data->attn_idx_offset;
				reg_result->sts_val = sts_val;
				reg_result->mask_val = qed_rd(p_hwfn,
							      p_ptt,
							      DWORDS_TO_BYTES
							      (reg_data->
							       mask_address));
				num_result_regs++;
			}
		}
	}
	results->block_id = (u8) block;
	results->names_offset =
	    qed_get_block_attn_data(block, attn_type)->names_offset;
	SET_FIELD(results->data, DBG_ATTN_BLOCK_RESULT_ATTN_TYPE, attn_type);
	SET_FIELD(results->data,
		  DBG_ATTN_BLOCK_RESULT_NUM_REGS, num_result_regs);
	return DBG_STATUS_OK;
}

enum dbg_status qed_dbg_print_attn(struct qed_hwfn *p_hwfn,
				   struct dbg_attn_block_result *results)
{
	u8 num_regs = GET_FIELD(results->data,
				DBG_ATTN_BLOCK_RESULT_NUM_REGS);
	enum dbg_attn_type attn_type =
	    (enum dbg_attn_type)GET_FIELD(results->data,
					  DBG_ATTN_BLOCK_RESULT_ATTN_TYPE);
	u8 i = 0;

	for (i = 0; i < num_regs; i++) {
		struct dbg_attn_reg_result *reg_result =
		    &results->reg_results[i];
		const char *attn_type_str =
		    (attn_type == ATTN_TYPE_INTERRUPT ? "interrupt" : "parity");
		u32 sts_addr = GET_FIELD(reg_result->data,
					 DBG_ATTN_REG_RESULT_STS_ADDRESS);
		DP_NOTICE(p_hwfn,
			  "%s: address 0x%08x, status 0x%08x, mask 0x%08x\n",
			  attn_type_str,
			  sts_addr, reg_result->sts_val, reg_result->mask_val);
	}
	return DBG_STATUS_OK;
}

bool qed_is_block_in_reset(struct qed_hwfn * p_hwfn,
			   struct qed_ptt * p_ptt, enum block_id block)
{
	struct dbg_tools_data *dev_data = &(p_hwfn->dbg_info);
	u32 reset_reg = s_block_defs[block]->reset_reg;

	if (!s_block_defs[block]->has_reset_bit)
		return false;
	return s_reset_regs_defs[reset_reg].exists[dev_data->chip_id] ?
	    (qed_rd(p_hwfn, p_ptt,
		    s_reset_regs_defs[reset_reg].addr) &
	     BIT(s_block_defs[block]->reset_bit_offset)) == 0 : true;
}
