#ifndef _QED_ISCSI_H
#define _QED_ISCSI_H
#include <linux/types.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include "tcp_common.h"
#include "qed.h"
#include "qed_chain.h"
#include "qed_hsi.h"
#include "qed_mcp.h"
#include "qed_sp.h"
#include "qed_iscsi_if.h"

struct qed_iscsi_conn {
	struct list_head list_entry;
	bool free_on_delete;

	u16 conn_id;
	u32 icid;
	u32 fw_cid;

	u8 layer_code;
	u8 offl_flags;
	u8 connect_mode;
	u32 initial_ack;
	dma_addr_t sq_pbl_addr;
	struct qed_chain r2tq;
	struct qed_chain xhq;
	struct qed_chain uhq;

	struct tcp_upload_params *tcp_upload_params_virt_addr;
	dma_addr_t tcp_upload_params_phys_addr;
	struct scsi_terminate_extra_params *queue_cnts_virt_addr;
	dma_addr_t queue_cnts_phys_addr;
	dma_addr_t syn_phy_addr;

	u16 syn_ip_payload_length;
	u8 local_mac[6];
	u8 remote_mac[6];
	u16 vlan_id;
	u8 tcp_flags;
	u8 ip_version;
	u32 remote_ip[4];
	u32 local_ip[4];
	u8 ka_max_probe_cnt;
	u8 dup_ack_theshold;
	u32 rcv_next;
	u32 snd_una;
	u32 snd_next;
	u32 snd_max;
	u32 snd_wnd;
	u32 rcv_wnd;
	u32 snd_wl1;
	u32 cwnd;
	u32 ss_thresh;
	u16 srtt;
	u16 rtt_var;
	u32 ts_time;
	u32 ts_recent;
	u32 ts_recent_age;
	u32 total_rt;
	u32 ka_timeout_delta;
	u32 rt_timeout_delta;
	u8 dup_ack_cnt;
	u8 snd_wnd_probe_cnt;
	u8 ka_probe_cnt;
	u8 rt_cnt;
	u32 flow_label;
	u32 ka_timeout;
	u32 ka_interval;
	u32 max_rt_time;
	u32 initial_rcv_wnd;
	u8 ttl;
	u8 tos_or_tc;
	u16 remote_port;
	u16 local_port;
	u16 mss;
	u8 snd_wnd_scale;
	u8 rcv_wnd_scale;
	u32 ts_ticks_per_second;
	u16 da_timeout_value;
	u8 ack_frequency;

	u8 update_flag;
#define QED_ISCSI_CONN_HD_EN            0x01
#define QED_ISCSI_CONN_DD_EN            0x02
#define QED_ISCSI_CONN_INITIAL_R2T      0x04
#define QED_ISCSI_CONN_IMMEDIATE_DATA   0x08

	u8 default_cq;
	u32 max_seq_size;
	u32 max_recv_pdu_length;
	u32 max_send_pdu_length;
	u32 first_seq_length;
	u32 exp_stat_sn;
	u32 stat_sn;
	u16 physical_q0;
	u16 physical_q1;
	u8 abortive_dsconnect;
};

/**
 * @brief qed_iscsi_acquire_connection - allocate resources,
 *        provides connecion handle (CID)as out parameter.
 *
 * @param p_path
 * @param p_conn  partially initialized incoming container of
 *                iSCSI connection data
 * @return int
 */
int
qed_iscsi_acquire_connection(struct qed_hwfn *p_hwfn,
			     struct qed_iscsi_conn *p_in_conn,
			     struct qed_iscsi_conn **p_out_conn);

void __iomem *qed_iscsi_get_db_addr(struct qed_hwfn *p_hwfn, u32 cid);

void __iomem *qed_iscsi_get_global_cmdq_cons(struct qed_hwfn *p_hwfn,
					     u8 relative_q_id);

void __iomem *qed_iscsi_get_primary_bdq_prod(struct qed_hwfn *p_hwfn,
					     u8 bdq_id);

void __iomem *qed_iscsi_get_secondary_bdq_prod(struct qed_hwfn *p_hwfn,
					       u8 bdq_id);

/**
 * @brief qed_iscsi_offload_connection - offload previously
 *        allocated iSCSI connection
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 *
 * @return int
 */
int
qed_iscsi_offload_connection(struct qed_hwfn *p_hwfn,
			     struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_iscsi_release_connection - deletes connecton
 *        resources (incliding container of iSCSI connection
 *        data)
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 */
void qed_iscsi_release_connection(struct qed_hwfn *p_hwfn,
				  struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_iscsi_terminate_connection - destroys previously
 *        offloaded iSCSI connection
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 *
 * @return int
 */
int
qed_iscsi_terminate_connection(struct qed_hwfn *p_hwfn,
			       struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_iscsi_update_connection - updates previously
 *        offloaded iSCSI connection
 *
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 *
 * @return int
 */
int
qed_iscsi_update_connection(struct qed_hwfn *p_hwfn,
			    struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_iscsi_mac_update_connection - updates remote MAC for previously
 *        offloaded iSCSI connection
 *
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 *
 * @return int
 */
int
qed_iscsi_update_remote_mac(struct qed_hwfn *p_hwfn,
			    struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_iscsi_clear_connection_sq - clear SQ
 *        offloaded iSCSI connection
 *
 *
 * @param p_path
 * @param p_conn  container of iSCSI connection data
 *
 * @return int
 */
int
qed_iscsi_clear_connection_sq(struct qed_hwfn *p_hwfn,
			      struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_sp_iscsi_func_start
 *
 * This ramrod inits iSCSI functionality in FW
 *
 * @param p_path
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_func_start(struct qed_hwfn *p_hwfn,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_addr,
			void *async_event_context,
			iscsi_event_cb_t async_event_cb);

int
qed_sp_iscsi_func_stop(struct qed_hwfn *p_hwfn,
		       enum spq_mode comp_mode,
		       struct qed_spq_comp_cb *p_comp_addr);

int qed_iscsi_get_stats(struct qed_hwfn *p_hwfn, struct qed_iscsi_stats *stats);

struct qed_iscsi_info {
	spinlock_t lock;
	struct list_head free_list;
	u16 max_num_outstanding_tasks;
	void *event_context;
	iscsi_event_cb_t event_cb;
};

struct qed_iscsi_info *qed_iscsi_alloc(struct qed_hwfn *p_hwfn);

void qed_iscsi_setup(struct qed_hwfn *p_hwfn,
		     struct qed_iscsi_info *p_iscsi_info);

void qed_iscsi_free(struct qed_hwfn *p_hwfn,
		    struct qed_iscsi_info *p_iscsi_info);

void qed_iscsi_free_connection(struct qed_hwfn *p_hwfn,
			       struct qed_iscsi_conn *p_conn);

/**
 * @brief qed_sp_iscsi_conn_offload - iSCSI connection offload
 *
 * This ramrod offloads iSCSI connection to FW
 *
 * @param p_path
 * @param p_conn
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_conn_offload(struct qed_hwfn *p_hwfn,
			  struct qed_iscsi_conn *p_conn,
			  enum spq_mode comp_mode,
			  struct qed_spq_comp_cb *p_comp_addr);

/**
 * @brief qed_sp_iscsi_conn_update - iSCSI connection update
 *
 * This ramrod updatess iSCSI ofloadedconnection in FW
 *
 * @param p_path
 * @param p_conn
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_conn_update(struct qed_hwfn *p_hwfn,
			 struct qed_iscsi_conn *p_conn,
			 enum spq_mode comp_mode,
			 struct qed_spq_comp_cb *p_comp_addr);

/**
 * @brief qed_sp_iscsi_mac_update - iSCSI connection's MAC update
 *
 * This ramrod updates remote MAC for iSCSI offloaded connection in FW
 *
 * @param p_path
 * @param p_conn
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_mac_update(struct qed_hwfn *p_hwfn,
			struct qed_iscsi_conn *p_conn,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_addr);

/**
 * @brief qed_sp_iscsi_conn_terminate - iSCSI connection
 *        terminate
 *
 * This ramrod deletes iSCSI offloaded connection in FW
 *
 * @param p_path
 * @param p_conn
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_conn_terminate(struct qed_hwfn *p_hwfn,
			    struct qed_iscsi_conn *p_conn,
			    enum spq_mode comp_mode,
			    struct qed_spq_comp_cb *p_comp_addr);

/**
 * @brief qed_sp_iscsi_conn_clear_sq - iSCSI connection
 *        clear SQ
 *
 * This ramrod clears connection's SQ in FW
 *
 * @param p_path
 * @param p_conn
 * @param comp_mode
 * @param comp_addr
 *
 * @return int
 */
int
qed_sp_iscsi_conn_clear_sq(struct qed_hwfn *p_hwfn,
			   struct qed_iscsi_conn *p_conn,
			   enum spq_mode comp_mode,
			   struct qed_spq_comp_cb *p_comp_addr);

#ifdef CONFIG_QED_LL2
extern const struct qed_common_ops qed_common_ops_pass;
extern const struct qed_ll2_ops qed_ll2_ops_pass;
#endif

/**
 * @brief - Fills provided statistics struct with statistics.
 *
 * @param cdev
 * @param stats - points to struct that will be filled with statistics.
 */
void qed_get_protocol_stats_iscsi(struct qed_dev *cdev,
				  struct qed_mcp_iscsi_stats *stats);
#endif
