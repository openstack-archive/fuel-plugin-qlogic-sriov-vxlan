/* Copyright 2013 QLogic Corporation
 *
 * Unless you and QLogic execute a separate written software license agreement
 * governing use of this software, this software is licensed to you under the
 * terms of the GNU General Public License version 2 (the "GPL"), available at
 * http://www.gnu.org/licenses/gpl-2.0.html, with the following added to such
 * license:
 *
 * As a special exception, the copyright holders of this software give you
 * permission to link this software with independent modules, and to copy and
 * distribute the resulting executable under terms of your choice, provided that
 * you also meet, for each linked independent module, the terms and conditions
 * of the license of that module.  An independent module is a module which is
 * not derived from this software.  The special exception does not apply to any
 * modifications of the software.
 */

#ifndef _QED_TESTS_H
#define _QED_TESTS_H

#include "qed.h"
#include "qed_hsi.h"
#include "qed_sp.h"

int qed_qm_reconf_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 ofload_tc, u8 non_offload_tc, u8 num_tc);

int qed_ets_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_phony_dcbx_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_mcp_halt_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_mcp_resume_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_mcp_mask_parities_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_mcp_unmask_parities_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_test_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 rc);

int qed_gen_process_kill_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      u8 is_common_block);

int qed_gen_system_kill_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_trigger_recovery_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/* Mask/Unmask a specific MSI-X vector; Required for integration test of the 'interrupt_test'. */
int qed_msix_vector_mask_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 vector, u8 b_mask);

/* Mask/Unmask the MSI-X pci capability; Required for integration test of the `interrupt_test'. */
int qed_msix_mask_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 b_mask);

/* Disable/Enable the MSI-X pci capability; Required for integration of the `interrupt_test'. */
int qed_msix_disable_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 b_disable);

/* Configure OBFF FSM; Required for integration of the 'OBFF test'. */
int qed_config_obff_fsm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/* Print OBFF statistics; Required for integration of the 'OBFF test'. */
int qed_dump_obff_stats_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/* Set OBFF state; Required for integration of the 'OBFF test'. */
int qed_set_obff_state_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 state);

int qed_ramrod_flood_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 ramrod_amount);

int qed_gen_fan_failure_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			     u8 is_over_temp);

int qed_bist_register_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_bist_clock_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_bist_nvm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_get_temperature_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

int qed_get_mba_versions_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

#endif
