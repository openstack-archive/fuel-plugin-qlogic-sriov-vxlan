/* Copyright 2013 QLogic Corporation
 *
 * Unless you and QLogic execute a separate written software license agreement
 * governing use of this software, this software is licensed to you under the
 * terms of the GNU General Public License version 2 (the "GPL"), available at
 * http://www.gnu.org/licenses/gpl-2.0.html, with the following added to such
 * license:
 *
 * As a special exception, the copyright holders of this software give you
 * permission to link this software with independent modules, and to copy and
 * distribute the resulting executable under terms of your choice, provided that
 * you also meet, for each linked independent module, the terms and conditions
 * of the license of that module.  An independent module is a module which is
 * not derived from this software.  The special exception does not apply to any
 * modifications of the software.
 */

#define __PREVENT_INT_ATTN__
#define __PREVENT_CHIP_NAMES__
#define __PREVENT_REG_TYPE_NAMES__
#define __PREVENT_DUMP_MEM_ARR__
#define __PREVENT_PXP_GLOBAL_WIN__
#define __PREVENT_COND_ARR__

#include <linux/msi.h>
#include "qed_tests.h"
#include "qed_hw.h"
#include "qed_mcp.h"
#include "qed_reg_addr.h"
#include "qed_chain.h"
#include "qed_selftest_api.h"

extern int qed_qm_reconf(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

extern void qed_dp_qm_pf_info(struct qed_hwfn *p_hwfn);

 
int qed_qm_reconf_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 offload_tc, u8 non_offload_tc, u8 num_tc)
{

	/* qed_dp_qm_pf_info(p_hwfn);

	p_hwfn->hw_info.offload_tc = offload_tc;
	p_hwfn->hw_info.non_offload_tc = non_offload_tc;
	p_hwfn->hw_info.num_tc = num_tc;

	qed_qm_reconf(p_hwfn, p_ptt);
	qed_dp_qm_pf_info(p_hwfn); */

	return 0;
}

int qed_ets_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	struct init_ets_req ets;
	int i;

	for (i = 0; i < NUM_OF_TCS; i++){
		ets.tc_req[i].use_sp = 0;
		ets.tc_req[i].use_wfq = 1;
		ets.tc_req[i].weight = 1;
	}

	ets.tc_req[1].weight = 4;
	/* qed_init_nig_ets(p_hwfn, p_ptt, &ets, false); */

	return 0;
}

int qed_phony_dcbx_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	u32 load_code, param;

	qed_mcp_cmd(p_hwfn, p_hwfn->p_main_ptt,
		    DRV_MSG_CODE_SET_DCBX,
		1 << DRV_MB_PARAM_DCBX_NOTIFY_SHIFT,
		&load_code, &param);

	return 0;
}

int qed_mcp_halt_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	qed_mcp_halt(p_hwfn, p_ptt);
	return 0;
}

int qed_mcp_resume_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	qed_mcp_resume(p_hwfn, p_ptt);
	return 0;
}

int qed_mcp_mask_parities_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	return qed_mcp_mask_parities(p_hwfn, p_ptt, 1);
}

int qed_mcp_unmask_parities_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	return qed_mcp_mask_parities(p_hwfn, p_ptt, 0);
}

int qed_test_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 rc)
{
	printk("test");
	return rc;
}

int qed_gen_process_kill_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      u8 is_common_block)
{
	if (is_common_block) {
		/* The DCBX nvm option should be set to CEE (2) to enable LLDP traffic */
		qed_wr(p_hwfn, p_ptt,
		       0x540420 /* BMB_REG_MEM001_RF_ECC_ERROR_CONNECT */,
		       0x20300);
	} else {
		/* Traffic should be run after this register write */
		qed_wr(p_hwfn, p_ptt,
		       0x340420 /* BRB_REG_MEM001_RF_ECC_ERROR_CONNECT */,
		       0x20300);
	}

	return 0;
}

int qed_gen_system_kill_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	qed_wr(p_hwfn, p_ptt, 0x2b0204 /* ATC_REG_PRTY_MASK_H_0 */, 0x0);
	qed_rd(p_hwfn, p_ptt, 0x2b4800 /* first DWORD of ATC_REG_ATC_GPA_ARRAY_ACCESS_STATE */);

	return 0;
}

int qed_trigger_recovery_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	qed_start_recovery_process(p_hwfn, p_ptt);

	return 0;
}

/* Mask/Unmask a specific MSI-X vectorr; Required for integration test of the 'interrupt_test'. */
int qed_msix_vector_mask_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 vector, u8 b_mask)
{
#ifndef CONFIG_XEN
	struct msi_desc *entry = NULL;
	u32 __iomem *ptr, val, new_val;
#ifdef _HAS_MSI_LIST /* ! QED_UPSTREAM */
	struct pci_dev *pdev = p_hwfn->cdev->pdev;

	entry = list_first_entry(&pdev->msi_list, struct msi_desc, list);
#endif
	if (!entry)
		return -EINVAL;

	ptr = entry->mask_base + vector * 4 * sizeof(u32);
	val = ptr[3];
	new_val = ptr[3] & 0xfffffffe;

	if (b_mask)
		new_val |= 0x1;

	printk(KERN_ERR "MSI-X[%d]: %08x:%08x:%08x:%08x -> %08x:%08x:%08x:%08x\n",
	       vector, ptr[0], ptr[1], ptr[2], val, ptr[0], ptr[1], ptr[2], new_val);

	ptr[3] = new_val;		
#endif
	return 0;
}

/* Copied from drivers/pci/pci.h */
static inline void pci_msix_clear_and_set_ctrl(struct pci_dev *dev, u16 clear, u16 set)
{
	u16 msix_cap = pci_find_capability(dev, PCI_CAP_ID_MSIX);
	u16 ctrl;

	pci_read_config_word(dev, msix_cap + PCI_MSIX_FLAGS, &ctrl);
	ctrl &= ~clear;
	ctrl |= set;
	pci_write_config_word(dev, msix_cap + PCI_MSIX_FLAGS, ctrl);
}

/* Mask/Unmask the MSI-X pci capability; Required for integration test of the `interrupt_test'. */
int qed_msix_mask_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 b_mask)
{
	struct pci_dev *pdev = p_hwfn->cdev->pdev;

	if (b_mask)
		pci_msix_clear_and_set_ctrl(pdev, 0, PCI_MSIX_FLAGS_MASKALL);
	else
		pci_msix_clear_and_set_ctrl(pdev, PCI_MSIX_FLAGS_MASKALL, 0);

	DP_NOTICE(p_hwfn, "%s MSI-X interrupts\n", b_mask ? "Masked" : "Unmasked");

	return 0;
}

/* Disable/Enable the MSI-X pci capability; Required for integration of the `interrupt_test'. */
int qed_msix_disable_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 b_disable)
{
	struct pci_dev *pdev = p_hwfn->cdev->pdev;

	if (b_disable)
		pci_msix_clear_and_set_ctrl(pdev, PCI_MSIX_FLAGS_ENABLE, 0);
	else
		pci_msix_clear_and_set_ctrl(pdev, 0, PCI_MSIX_FLAGS_ENABLE);

	DP_NOTICE(p_hwfn, "%s MSI-X interrupts\n", b_disable ? "Disabled" : "Enabled");

	return 0;
}

/* Configure OBFF FSM; Required for integration of the 'OBFF test'. */
int qed_config_obff_fsm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	u32 val;

	/* Read register CPMU_REG_OBFF_MODE_CONTROL, modify bit 1 (OBFF_ENGINE_IDLE_EN) to 0 */
	val = qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_MODE_CONTROL); 
	val &= ~(0x1 << 1);

	/* When the OBFF state changes to OBFF/IDLE, are there already VQs which are not empty?
	 * If yes, these VQs prevent the FSM from getting into the STALL state.
	 * Write value of 0 to bits 8 and 9 of the CPMU_REG_OBFF_MODE_CONTROL register to not to
	 * condition the FSM transfer to stall state with VOs not empty. 
	 */
	val &= ~(0x11 << 9);

	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_MODE_CONTROL, val);

	/* Write 0xFFFF_FFFF to registers
	 *  CPMU_REG_OBFF_MEM_TIMER_SHORT_THRESHOLD (Offset: 0x22C; Width: 32)
	 *  CPMU_REG_OBFF_MEM_TIMER_LONG_THRESHOLD (Offset: 0x230; Width: 32)
	 *  CPMU_REG_OBFF_INT_TIMER_SHORT_THRESHOLD (Offset: 0x234; Width: 32)
	 *  CPMU_REG_OBFF_INT_TIMER_LONG_THRESHOLD (Offset: 0x238; Width: 32)
	 *  	[Set the thresholds to infinite value]
	 */
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_MEM_TIMER_SHORT_THRESHOLD, 0xFFFFFFFF);
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_MEM_TIMER_LONG_THRESHOLD, 0xFFFFFFFF);
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_INT_TIMER_SHORT_THRESHOLD, 0xFFFFFFFF);
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_INT_TIMER_LONG_THRESHOLD, 0xFFFFFFFF);

	/* Write 0xFFFF_FFFF to registers
	 *  CPMU_REG_OBFF_STALL_ON_IDLE_STATE_0 (Offset: 0x244; Width: 32)
	 *  CPMU_REG_OBFF_STALL_ON_IDLE_STATE_1 (Offset: 0x248; Width: 32)
	 *  [Causes all VQs in IDLE state to use the counters with the infinite values].
	 */
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_ON_IDLE_STATE_0, 0xFFFFFFFF);
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_ON_IDLE_STATE_1, 0xFFFFFFFF);

	/* Write to 0x20_0000 to register CPMU_REG_OBFF_STALL_ON_OBFF_STATE_0(Offset: 0x23C;
	 *  Width: 32) [Causes IGU VQ #0x15 in OBFF state to use the counter with the infinite
	 *  values; all other VQs the stall state is removed immediately (if VQ not empty].
	 */
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_ON_OBFF_STATE_0, 0x200000);

	/* Write 0x1 to register CPMU_REG_OBFF_MODE_CONFIG (Offset: 0x220; Width: 32)
	 * [enable OBFF].
	 */
	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_MODE_CONFIG, 0x1);

	/* Read register BRB_REG_OUT_IF_ENABLE (Offset: 0xF2C; Width: 32), modify bit 25
	 *  (PM_OUT_IF_EN) to 0 [Disables BRB above threshold indication].
	 */ 
	val = qed_rd(p_hwfn, p_ptt, BRB_REG_OUT_IF_ENABLE); 
	val &= ~(0x1 << 25);
	qed_wr(p_hwfn, p_ptt, BRB_REG_OUT_IF_ENABLE, val);

	DP_NOTICE(p_hwfn, "Configured OBFF FSM\n");

	return 0;
}

/* Print OBFF statistics; Required for integration of the 'OBFF test'. */
int qed_dump_obff_stats_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{

	DP_NOTICE(p_hwfn, "STALL_MEM_STAT = %x\n", qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_MEM_STAT));
	DP_NOTICE(p_hwfn, "STALL_MEM_DURATION_STAT = %x\n", qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_MEM_DURATION_STAT));
	DP_NOTICE(p_hwfn, "STALL_INT_STAT = %x\n", qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_INT_STAT));
	DP_NOTICE(p_hwfn, "STALL_INT_DURATION_STAT  = %x\n", qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_STALL_INT_DURATION_STAT));

	return 0;
}

/* Set OBFF state; Required for integration of the 'OBFF test'. */
int qed_set_obff_state_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u8 state)
{
	u32 val;

	/* Read register CPMU_REG_OBFF_MODE_CONTROL */
	val = qed_rd(p_hwfn, p_ptt, CPMU_REG_OBFF_MODE_CONTROL); 

	switch (state) {
	case 0:
		/* Modify bit 7-6 (OBFF_ENGINE_IDLE_EN) to 0x0 */
		val &= ~(0x1 << 6);
		val &= ~(0x1 << 7);
		DP_NOTICE(p_hwfn, "OBFF is set to ‘cpu active’ mode\n");
		break;
	case 1:
		/* Modify bit 7-6 (OBFF_ENGINE_IDLE_EN) to 0x1 */
		val |= (0x1 << 6);
		val &= ~(0x1 << 7);
		DP_NOTICE(p_hwfn, "OBFF is set to ‘cpu obff’ mode\n");
		break;
	case 2:
		/* Modify bit 7-6 (OBFF_ENGINE_IDLE_EN) to 0x2 */
		val &= ~(0x1 << 6);
		val |= (0x1 << 7);
		DP_NOTICE(p_hwfn, "OBFF is set to ‘cpu idle’ mode\n");
		break;
	default:
		DP_NOTICE(p_hwfn, "Invalid OBFF state value\n");
		return -1;
	}

	qed_wr(p_hwfn, p_ptt, CPMU_REG_OBFF_MODE_CONTROL, val);
	return 0;
}

int qed_ramrod_flood_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, u32 ramrod_amount)
{
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	int rc = 0, i;

	for (i = 0; i < ramrod_amount; i++) {
		DP_NOTICE(p_hwfn, "about to send empty ramrod %d\n", i);

		memset(&init_data, 0, sizeof(init_data));
		init_data.cid = qed_spq_get_cid(p_hwfn);
		init_data.opaque_fid = p_hwfn->hw_info.opaque_fid;
		init_data.comp_mode = QED_SPQ_MODE_CB;

		rc = qed_sp_init_request(p_hwfn, &p_ent,
					 COMMON_RAMROD_EMPTY, PROTOCOLID_COMMON,
					 &init_data);
		if (rc)
			return rc;

		rc = qed_spq_post(p_hwfn, p_ent, NULL);
		if (rc)
			return rc;
	}

	return rc;
}

int qed_gen_fan_failure_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			     u8 is_over_temp)
{
	u32 mcp_resp, mcp_param;

	return qed_mcp_cmd(p_hwfn, p_ptt, DRV_MSG_CODE_INDUCE_FAILURE,
			   is_over_temp ? DRV_MSG_TEMPERATURE_FAILURE_TYPE
					: DRV_MSG_FAN_FAILURE_TYPE,
			   &mcp_resp, &mcp_param);
}

int qed_bist_register_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	return qed_mcp_bist_register_test(p_hwfn, p_ptt);
}

int qed_bist_clock_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	return qed_mcp_bist_clock_test(p_hwfn, p_ptt);

}

int qed_bist_nvm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	return qed_selftest_nvram(p_hwfn->cdev);
}

int qed_get_temperature_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	struct qed_temperature_sensor *p_temp_sensor;
	struct qed_temperature_info temp_info;
	int rc, i;

	rc = qed_mcp_get_temperature_info(p_hwfn, p_ptt, &temp_info);
	if (rc)
		return rc;

	DP_NOTICE(p_hwfn, "Number of sensors %d\n",  temp_info.num_sensors);
	for (i = 0; i < temp_info.num_sensors; i++) {
		p_temp_sensor = &temp_info.sensors[i];
		DP_NOTICE(p_hwfn,
			  "[sensor %d] sensor_location %hhu, threshold_high %hhu, critical %hhu, current_temp %hhu\n",
			  i, p_temp_sensor->sensor_location,
			  p_temp_sensor->threshold_high,
			  p_temp_sensor->critical,
			  p_temp_sensor->current_temp);
	}

	return 0;
}

int qed_get_mba_versions_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt)
{
	struct qed_mba_vers mba_vers;
	char *str_arr[QED_MAX_NUM_OF_ROMIMG] = {
		"legacy MBA", "PCI30_CLP MBA", "PCI30 MBA", "FCODE",
		"EFI x86", "EFI IPF", "EFI EBC", "EFI x64"
	};
	int rc, i, found = 0;

	rc = qed_mcp_get_mba_versions(p_hwfn, p_ptt, &mba_vers);
	if (rc)
		return rc;

	for (i = 0; i < QED_MAX_NUM_OF_ROMIMG; i++) {
		if (mba_vers.mba_vers[i] == 0)
			continue;

		if (found == 0) {
			DP_NOTICE(p_hwfn, "MBA versions:\n");
			found = 1;
		}

		if (i < QED_EFI_X86_IDX)
			DP_NOTICE(p_hwfn, "  %s %d.%d.%d\n",
				  str_arr[i],
				  (mba_vers.mba_vers[i] & 0xff000) >> 12,
				  (mba_vers.mba_vers[i] & 0x0f00) >> 8,
				  mba_vers.mba_vers[i] & 0xff);
		else
			DP_NOTICE(p_hwfn, "  %s %d.%d.%d.%d\n",
				  str_arr[i],
				  (mba_vers.mba_vers[i] & 0xf0000) >> 16,
				  (mba_vers.mba_vers[i] & 0xf000) >> 12,
				  (mba_vers.mba_vers[i] & 0x0f00) >> 8,
				  mba_vers.mba_vers[i] & 0xff);
	}

	if (found == 0)
		DP_NOTICE(p_hwfn, "No MBA versions can be found.\n");

	return 0;
}
