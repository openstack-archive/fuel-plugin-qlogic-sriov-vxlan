#ifndef _QED_DCBX_H
#define _QED_DCBX_H
#include <linux/types.h>
#include <linux/slab.h>
#include "qed.h"
#include "qed_hsi.h"
#include "qed_hw.h"
#include "qed_mcp.h"
#include "qed_reg_addr.h"

#define DCBX_CONFIG_MAX_APP_PROTOCOL    4

enum qed_mib_read_type {
	QED_DCBX_OPERATIONAL_MIB,
	QED_DCBX_REMOTE_MIB,
	QED_DCBX_LOCAL_MIB,
	QED_DCBX_REMOTE_LLDP_MIB,
	QED_DCBX_LOCAL_LLDP_MIB
};

struct qed_dcbx_app_data {
	bool enable;		/* DCB enabled */
	u8 update;		/* Update indication */
	u8 priority;		/* Priority */
	u8 tc;			/* Traffic Class */
	bool dscp_enable;	/* DSCP enabled */
	u8 dscp_val;		/* DSCP value */
};

#define QED_DCBX_VERSION_DISABLED       0
#define QED_DCBX_VERSION_IEEE           1
#define QED_DCBX_VERSION_CEE            2
#define QED_DCBX_VERSION_DYNAMIC        3

struct qed_dcbx_set {
#define QED_DCBX_OVERRIDE_STATE (1 << 0)
#define QED_DCBX_OVERRIDE_PFC_CFG       (1 << 1)
#define QED_DCBX_OVERRIDE_ETS_CFG       (1 << 2)
#define QED_DCBX_OVERRIDE_APP_CFG       (1 << 3)
#define QED_DCBX_OVERRIDE_DSCP_CFG      (1 << 4)
	u32 override_flags;
	bool enabled;
	struct qed_dcbx_admin_params config;
	u32 ver_num;
	struct qed_dcbx_dscp_params dscp;
};

struct qed_dcbx_results {
	bool dcbx_enabled;
	u8 pf_id;
	struct qed_dcbx_app_data arr[DCBX_MAX_PROTOCOL_TYPE];
};

struct qed_dcbx_app_metadata {
	enum dcbx_protocol_type id;
	char *name;
	enum qed_pci_personality personality;
};

int qed_dcbx_query_params(struct qed_hwfn *,
			  struct qed_dcbx_get *, enum qed_mib_read_type);

int qed_dcbx_get_config_params(struct qed_hwfn *, struct qed_dcbx_set *);

int qed_dcbx_config_params(struct qed_hwfn *,
			   struct qed_ptt *, struct qed_dcbx_set *, bool);

static const struct qed_dcbx_app_metadata qed_dcbx_app_update[] = {
	{DCBX_PROTOCOL_ISCSI, "ISCSI", QED_PCI_ISCSI},
	{DCBX_PROTOCOL_FCOE, "FCOE", QED_PCI_FCOE},
	{DCBX_PROTOCOL_ROCE, "ROCE", QED_PCI_ETH_ROCE},
	{DCBX_PROTOCOL_ROCE_V2, "ROCE_V2", QED_PCI_ETH_ROCE},
	{DCBX_PROTOCOL_ETH, "ETH", QED_PCI_ETH}
};

#define QED_MFW_GET_FIELD(name, field) \
	(((name) & (field ## _MASK)) >> (field ## _SHIFT))

struct qed_dcbx_info {
	struct lldp_status_params_s lldp_remote[LLDP_MAX_LLDP_AGENTS];
	struct lldp_config_params_s lldp_local[LLDP_MAX_LLDP_AGENTS];
	struct dcbx_local_params local_admin;
	struct qed_dcbx_results results;
	struct dcb_dscp_map dscp_map;
	bool dscp_nig_update;
	struct dcbx_mib operational;
	struct dcbx_mib remote;
	struct qed_dcbx_set set;
	struct qed_dcbx_get get;
	u8 dcbx_cap;
};

struct qed_dcbx_mib_meta_data {
	struct lldp_config_params_s *lldp_local;
	struct lldp_status_params_s *lldp_remote;
	struct dcbx_local_params *local_admin;
	struct dcb_dscp_map *dscp_map;
	struct dcbx_mib *mib;
	size_t size;
	u32 addr;
};

/* QED local interface routines */
int
qed_dcbx_mib_update_event(struct qed_hwfn *,
			  struct qed_ptt *, enum qed_mib_read_type);

int qed_dcbx_read_lldp_params(struct qed_hwfn *, struct qed_ptt *);
int qed_dcbx_info_alloc(struct qed_hwfn *p_hwfn);
void qed_dcbx_info_free(struct qed_hwfn *, struct qed_dcbx_info *);
void qed_dcbx_set_pf_update_params(struct qed_dcbx_results *p_src,
				   struct pf_update_ramrod_data *p_dest);

#ifndef REAL_ASIC_ONLY
/* @@@TBD eagle phy workaround */
void qed_dcbx_eagle_workaround(struct qed_hwfn *,
			       struct qed_ptt *, bool set_to_pfc);
#endif

#endif
