#include <linux/types.h>
#include <asm/byteorder.h>
#include <asm/param.h>
#include <linux/dcbnl.h>
#include <linux/delay.h>
#include <linux/dma-mapping.h>
#include <linux/etherdevice.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/slab.h>
#include <linux/stddef.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/workqueue.h>
#include <linux/bitops.h>
#include <linux/bug.h>
#include <linux/errno.h>
#define __PREVENT_DUMP_MEM_ARR__
#define __PREVENT_PXP_GLOBAL_WIN__
#include "qed.h"
#include "qed_chain.h"
#include "qed_compat.h"
#include "qed_cxt.h"
#include "qed_dcbx.h"
#include "qed_dev_api.h"
#include "qed_eth_if.h"
#include "qed_hsi.h"
#include "qed_hw.h"
#include "qed_int.h"
#include "qed_l2.h"
#include "qed_mcp.h"
#include "qed_ptp_if.h"
#include "qed_reg_addr.h"
#include "qed_sp.h"
#include "qed_sriov.h"
#include "qed_vf.h"
#include "qed_eth_if.h"
#include "qed_if.h"

#define QED_MAX_SGES_NUM 16
#define CRC32_POLY 0x1edc6f41

int qed_sp_eth_vport_start(struct qed_hwfn *p_hwfn,
			   struct qed_sp_vport_start_params *p_params)
{
	struct vport_start_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	u8 abs_vport_id = 0;
	int rc = -EINVAL;
	u16 rx_mode = 0;

	rc = qed_fw_vport(p_hwfn, p_params->vport_id, &abs_vport_id);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = qed_spq_get_cid(p_hwfn);
	init_data.opaque_fid = p_params->opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_VPORT_START,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	p_ramrod = &p_ent->ramrod.vport_start;
	p_ramrod->vport_id = abs_vport_id;

	p_ramrod->mtu = cpu_to_le16(p_params->mtu);
	p_ramrod->inner_vlan_removal_en = p_params->remove_inner_vlan;
	p_ramrod->handle_ptp_pkts = p_params->handle_ptp_pkts;
	p_ramrod->drop_ttl0_en = p_params->drop_ttl0;
	p_ramrod->untagged = p_params->only_untagged;
	p_ramrod->zero_placement_offset = p_params->zero_placement_offset;

	SET_FIELD(rx_mode, ETH_VPORT_RX_MODE_UCAST_DROP_ALL, 1);
	SET_FIELD(rx_mode, ETH_VPORT_RX_MODE_MCAST_DROP_ALL, 1);

	p_ramrod->rx_mode.state = cpu_to_le16(rx_mode);

	/* TPA related fields */
	memset(&p_ramrod->tpa_param, 0, sizeof(struct eth_vport_tpa_param));
	p_ramrod->tpa_param.max_buff_num = p_params->max_buffers_per_cqe;

	switch (p_params->tpa_mode) {
	case QED_TPA_MODE_GRO:
		p_ramrod->tpa_param.tpa_max_aggs_num = ETH_TPA_MAX_AGGS_NUM;
		p_ramrod->tpa_param.tpa_max_size = (u16) - 1;
		p_ramrod->tpa_param.tpa_min_size_to_cont = p_params->mtu / 2;
		p_ramrod->tpa_param.tpa_min_size_to_start = p_params->mtu / 2;
		p_ramrod->tpa_param.tpa_ipv4_en_flg = 1;
		p_ramrod->tpa_param.tpa_ipv6_en_flg = 1;
		p_ramrod->tpa_param.tpa_ipv4_tunn_en_flg = 1;
		p_ramrod->tpa_param.tpa_ipv6_tunn_en_flg = 1;
		p_ramrod->tpa_param.tpa_pkt_split_flg = 1;
		p_ramrod->tpa_param.tpa_gro_consistent_flg = 1;
		break;
	default:
		break;
	}

	p_ramrod->tx_switching_en = p_params->tx_switching;
#ifndef ASIC_ONLY
	if (CHIP_REV_IS_SLOW(p_hwfn->cdev))
		p_ramrod->tx_switching_en = 0;
#endif

	p_ramrod->ctl_frame_mac_check_en = ! !p_params->check_mac;
	p_ramrod->ctl_frame_ethtype_check_en = ! !p_params->check_ethtype;

	/* Software Function ID in hwfn (PFs are 0 - 15, VFs are 16 - 135) */
	p_ramrod->sw_fid = qed_concrete_to_sw_fid(p_hwfn->cdev,
						  p_params->concrete_fid);

	return qed_spq_post(p_hwfn, p_ent, NULL);
}

int qed_sp_vport_start(struct qed_hwfn *p_hwfn,
		       struct qed_sp_vport_start_params *p_params)
{
	if (IS_VF(p_hwfn->cdev)) {
		return qed_vf_pf_vport_start(p_hwfn, p_params->vport_id,
					     p_params->mtu,
					     p_params->remove_inner_vlan,
					     p_params->tpa_mode,
					     p_params->max_buffers_per_cqe,
					     p_params->only_untagged);
	}

	return qed_sp_eth_vport_start(p_hwfn, p_params);
}

static int
qed_sp_vport_update_rss(struct qed_hwfn *p_hwfn,
			struct vport_update_ramrod_data *p_ramrod,
			struct qed_rss_params *p_rss)
{
	int rc = 0;
	struct eth_vport_rss_config *p_config;
	u16 abs_l2_queue = 0;
	int i;

	if (!p_rss) {
		p_ramrod->common.update_rss_flg = 0;
		return rc;
	}
	p_config = &p_ramrod->rss_config;

	BUILD_BUG_ON(QED_RSS_IND_TABLE_SIZE != ETH_RSS_IND_TABLE_ENTRIES_NUM);

	rc = qed_fw_rss_eng(p_hwfn, p_rss->rss_eng_id, &p_config->rss_id);
	if (rc != 0)
		return rc;

	p_ramrod->common.update_rss_flg = p_rss->update_rss_config;
	p_config->update_rss_capabilities = p_rss->update_rss_capabilities;
	p_config->update_rss_ind_table = p_rss->update_rss_ind_table;
	p_config->update_rss_key = p_rss->update_rss_key;

	p_config->rss_mode = p_rss->rss_enable ?
	    ETH_VPORT_RSS_MODE_REGULAR : ETH_VPORT_RSS_MODE_DISABLED;

	p_config->capabilities = 0;

	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV4_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV4));
	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV6_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV6));
	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV4_TCP_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV4_TCP));
	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV6_TCP_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV6_TCP));
	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV4_UDP_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV4_UDP));
	SET_FIELD(p_config->capabilities,
		  ETH_VPORT_RSS_CONFIG_IPV6_UDP_CAPABILITY,
		  ! !(p_rss->rss_caps & QED_RSS_IPV6_UDP));
	p_config->tbl_size = p_rss->rss_table_size_log;
	p_config->capabilities = cpu_to_le16(p_config->capabilities);

	DP_VERBOSE(p_hwfn,
		   NETIF_MSG_IFUP,
		   "update rss flag %d, rss_mode = %d, update_caps = %d, capabilities = %d, update_ind = %d, update_rss_key = %d\n",
		   p_ramrod->common.update_rss_flg,
		   p_config->rss_mode,
		   p_config->update_rss_capabilities,
		   p_config->capabilities,
		   p_config->update_rss_ind_table, p_config->update_rss_key);

	for (i = 0; i < QED_RSS_IND_TABLE_SIZE; i++) {
		rc = qed_fw_l2_queue(p_hwfn,
				     (u8) p_rss->rss_ind_table[i],
				     &abs_l2_queue);
		if (rc != 0)
			return rc;

		p_config->indirection_table[i] = cpu_to_le16(abs_l2_queue);
		DP_VERBOSE(p_hwfn, NETIF_MSG_IFUP, "i= %d, queue = %d\n",
			   i, p_config->indirection_table[i]);
	}

	for (i = 0; i < 10; i++)
		p_config->rss_key[i] = cpu_to_le32(p_rss->rss_key[i]);

	return rc;
}

static void
qed_sp_update_accept_mode(struct qed_hwfn *p_hwfn,
			  struct vport_update_ramrod_data *p_ramrod,
			  struct qed_filter_accept_flags accept_flags)
{
	p_ramrod->common.update_rx_mode_flg =
	    accept_flags.update_rx_mode_config;
	p_ramrod->common.update_tx_mode_flg =
	    accept_flags.update_tx_mode_config;

#ifndef ASIC_ONLY
	/* On B0 emulation we cannot enable Tx, since this would cause writes
	 * to PVFC HW block which isn't implemented in emulation.
	 */
	if (CHIP_REV_IS_SLOW(p_hwfn->cdev)) {
		DP_VERBOSE(p_hwfn, QED_MSG_SP,
			   "Non-Asic - prevent Tx mode in vport update\n");
		p_ramrod->common.update_tx_mode_flg = 0;
	}
#endif

	/* Set Rx mode accept flags */
	if (p_ramrod->common.update_rx_mode_flg) {
		u8 accept_filter = accept_flags.rx_accept_filter;
		u16 state = 0;

		SET_FIELD(state, ETH_VPORT_RX_MODE_UCAST_DROP_ALL,
			  !(! !(accept_filter & QED_ACCEPT_UCAST_MATCHED) ||
			    ! !(accept_filter & QED_ACCEPT_UCAST_UNMATCHED)));

		SET_FIELD(state, ETH_VPORT_RX_MODE_UCAST_ACCEPT_UNMATCHED,
			  ! !(accept_filter & QED_ACCEPT_UCAST_UNMATCHED));

		SET_FIELD(state, ETH_VPORT_RX_MODE_MCAST_DROP_ALL,
			  !(! !(accept_filter & QED_ACCEPT_MCAST_MATCHED) ||
			    ! !(accept_filter & QED_ACCEPT_MCAST_UNMATCHED)));

		SET_FIELD(state, ETH_VPORT_RX_MODE_MCAST_ACCEPT_ALL,
			  (! !(accept_filter & QED_ACCEPT_MCAST_MATCHED) &&
			   ! !(accept_filter & QED_ACCEPT_MCAST_UNMATCHED)));

		SET_FIELD(state, ETH_VPORT_RX_MODE_BCAST_ACCEPT_ALL,
			  ! !(accept_filter & QED_ACCEPT_BCAST));

		p_ramrod->rx_mode.state = cpu_to_le16(state);
		DP_VERBOSE(p_hwfn, QED_MSG_SP,
			   "p_ramrod->rx_mode.state = 0x%x\n", state);
	}

	/* Set Tx mode accept flags */
	if (p_ramrod->common.update_tx_mode_flg) {
		u8 accept_filter = accept_flags.tx_accept_filter;
		u16 state = 0;

		SET_FIELD(state, ETH_VPORT_TX_MODE_UCAST_DROP_ALL,
			  ! !(accept_filter & QED_ACCEPT_NONE));

		SET_FIELD(state, ETH_VPORT_TX_MODE_MCAST_DROP_ALL,
			  ! !(accept_filter & QED_ACCEPT_NONE));

		SET_FIELD(state, ETH_VPORT_TX_MODE_MCAST_ACCEPT_ALL,
			  (! !(accept_filter & QED_ACCEPT_MCAST_MATCHED) &&
			   ! !(accept_filter & QED_ACCEPT_MCAST_UNMATCHED)));

		SET_FIELD(state, ETH_VPORT_TX_MODE_BCAST_ACCEPT_ALL,
			  ! !(accept_filter & QED_ACCEPT_BCAST));

		p_ramrod->tx_mode.state = cpu_to_le16(state);
		DP_VERBOSE(p_hwfn, QED_MSG_SP,
			   "p_ramrod->tx_mode.state = 0x%x\n", state);
	}
}

static void
qed_sp_vport_update_sge_tpa(struct qed_hwfn *p_hwfn,
			    struct vport_update_ramrod_data *p_ramrod,
			    struct qed_sge_tpa_params *p_params)
{
	struct eth_vport_tpa_param *p_tpa;

	if (!p_params) {
		p_ramrod->common.update_tpa_param_flg = 0;
		p_ramrod->common.update_tpa_en_flg = 0;
		p_ramrod->common.update_tpa_param_flg = 0;
		return;
	}

	p_ramrod->common.update_tpa_en_flg = p_params->update_tpa_en_flg;
	p_tpa = &p_ramrod->tpa_param;
	p_tpa->tpa_ipv4_en_flg = p_params->tpa_ipv4_en_flg;
	p_tpa->tpa_ipv6_en_flg = p_params->tpa_ipv6_en_flg;
	p_tpa->tpa_ipv4_tunn_en_flg = p_params->tpa_ipv4_tunn_en_flg;
	p_tpa->tpa_ipv6_tunn_en_flg = p_params->tpa_ipv6_tunn_en_flg;

	p_ramrod->common.update_tpa_param_flg = p_params->update_tpa_param_flg;
	p_tpa->max_buff_num = p_params->max_buffers_per_cqe;
	p_tpa->tpa_pkt_split_flg = p_params->tpa_pkt_split_flg;
	p_tpa->tpa_hdr_data_split_flg = p_params->tpa_hdr_data_split_flg;
	p_tpa->tpa_gro_consistent_flg = p_params->tpa_gro_consistent_flg;
	p_tpa->tpa_max_aggs_num = p_params->tpa_max_aggs_num;
	p_tpa->tpa_max_size = p_params->tpa_max_size;
	p_tpa->tpa_min_size_to_start = p_params->tpa_min_size_to_start;
	p_tpa->tpa_min_size_to_cont = p_params->tpa_min_size_to_cont;
}

static void
qed_sp_update_mcast_bin(struct qed_hwfn *p_hwfn,
			struct vport_update_ramrod_data *p_ramrod,
			struct qed_sp_vport_update_params *p_params)
{
	int i;

	memset(&p_ramrod->approx_mcast.bins, 0,
	       sizeof(p_ramrod->approx_mcast.bins));

	if (!p_params->update_approx_mcast_flg)
		return;

	p_ramrod->common.update_approx_mcast_flg = 1;
	for (i = 0; i < ETH_MULTICAST_MAC_BINS_IN_REGS; i++) {
		u32 *p_bins = (u32 *) p_params->bins;

		p_ramrod->approx_mcast.bins[i] = cpu_to_le32(p_bins[i]);
	}
}

int qed_sp_vport_update(struct qed_hwfn *p_hwfn,
			struct qed_sp_vport_update_params *p_params,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_data)
{
	struct qed_rss_params *p_rss_params = p_params->rss_params;
	struct vport_update_ramrod_data_cmn *p_cmn;
	struct qed_sp_init_data init_data;
	struct vport_update_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	u8 abs_vport_id = 0, val;
	int rc = -EINVAL;

	if (IS_VF(p_hwfn->cdev)) {
		rc = qed_vf_pf_vport_update(p_hwfn, p_params);
		return rc;
	}

	rc = qed_fw_vport(p_hwfn, p_params->vport_id, &abs_vport_id);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = qed_spq_get_cid(p_hwfn);
	init_data.opaque_fid = p_params->opaque_fid;
	init_data.comp_mode = comp_mode;
	init_data.p_comp_data = p_comp_data;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_VPORT_UPDATE,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	/* Copy input params to ramrod according to FW struct */
	p_ramrod = &p_ent->ramrod.vport_update;
	p_cmn = &p_ramrod->common;

	p_cmn->vport_id = abs_vport_id;

	p_cmn->rx_active_flg = p_params->vport_active_rx_flg;
	p_cmn->update_rx_active_flg = p_params->update_vport_active_rx_flg;
	p_cmn->tx_active_flg = p_params->vport_active_tx_flg;
	p_cmn->update_tx_active_flg = p_params->update_vport_active_tx_flg;

	p_cmn->accept_any_vlan = p_params->accept_any_vlan;
	val = p_params->update_accept_any_vlan_flg;
	p_cmn->update_accept_any_vlan_flg = val;

	p_cmn->inner_vlan_removal_en = p_params->inner_vlan_removal_flg;
	val = p_params->update_inner_vlan_removal_flg;
	p_cmn->update_inner_vlan_removal_en_flg = val;

	p_cmn->default_vlan_en = p_params->default_vlan_enable_flg;
	val = p_params->update_default_vlan_enable_flg;
	p_cmn->update_default_vlan_en_flg = val;

	p_cmn->default_vlan = cpu_to_le16(p_params->default_vlan);
	p_cmn->update_default_vlan_flg = p_params->update_default_vlan_flg;

	p_cmn->silent_vlan_removal_en = p_params->silent_vlan_removal_flg;

	p_ramrod->common.tx_switching_en = p_params->tx_switching_flg;
#ifndef ASIC_ONLY
	if (CHIP_REV_IS_FPGA(p_hwfn->cdev))
		if (p_ramrod->common.tx_switching_en ||
		    p_ramrod->common.update_tx_switching_en_flg) {
			DP_NOTICE(p_hwfn,
				  "FPGA - why are we seeing tx-switching? Overriding it\n");
			p_ramrod->common.tx_switching_en = 0;
			p_ramrod->common.update_tx_switching_en_flg = 1;
		}
#endif
	p_cmn->update_tx_switching_en_flg = p_params->update_tx_switching_flg;

	p_cmn->anti_spoofing_en = p_params->anti_spoofing_en;
	val = p_params->update_anti_spoofing_en_flg;
	p_ramrod->common.update_anti_spoofing_en_flg = val;

	rc = qed_sp_vport_update_rss(p_hwfn, p_ramrod, p_rss_params);
	if (rc != 0) {
		/* Return spq entry which is taken in qed_sp_init_request() */
		qed_spq_return_entry(p_hwfn, p_ent);
		return rc;
	}

	/* Update mcast bins for VFs, PF doesn't use this functionality */
	qed_sp_update_mcast_bin(p_hwfn, p_ramrod, p_params);

	qed_sp_update_accept_mode(p_hwfn, p_ramrod, p_params->accept_flags);
	qed_sp_vport_update_sge_tpa(p_hwfn, p_ramrod, p_params->sge_tpa_params);
	return qed_spq_post(p_hwfn, p_ent, NULL);
}

int qed_sp_vport_stop(struct qed_hwfn *p_hwfn, u16 opaque_fid, u8 vport_id)
{
	struct vport_stop_ramrod_data *p_ramrod;
	struct qed_sp_init_data init_data;
	struct qed_spq_entry *p_ent;
	u8 abs_vport_id = 0;
	int rc;

	if (IS_VF(p_hwfn->cdev))
		return qed_vf_pf_vport_stop(p_hwfn);

	rc = qed_fw_vport(p_hwfn, vport_id, &abs_vport_id);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = qed_spq_get_cid(p_hwfn);
	init_data.opaque_fid = opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_VPORT_STOP,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	p_ramrod = &p_ent->ramrod.vport_stop;
	p_ramrod->vport_id = abs_vport_id;

	return qed_spq_post(p_hwfn, p_ent, NULL);
}

static int
qed_vf_pf_accept_flags(struct qed_hwfn *p_hwfn,
		       struct qed_filter_accept_flags *p_accept_flags)
{
	struct qed_sp_vport_update_params s_params;

	memset(&s_params, 0, sizeof(s_params));
	memcpy(&s_params.accept_flags, p_accept_flags,
	       sizeof(struct qed_filter_accept_flags));

	return qed_vf_pf_vport_update(p_hwfn, &s_params);
}

int qed_filter_accept_cmd(struct qed_dev *cdev,
			  u8 vport,
			  struct qed_filter_accept_flags accept_flags,
			  u8
			  update_accept_any_vlan,
			  u8 accept_any_vlan,
			  enum spq_mode comp_mode,
			  struct qed_spq_comp_cb *p_comp_data)
{
	struct qed_sp_vport_update_params vport_update_params;
	int i, rc;

	/* Prepare and send the vport rx_mode change */
	memset(&vport_update_params, 0, sizeof(vport_update_params));
	vport_update_params.vport_id = vport;
	vport_update_params.accept_flags = accept_flags;
	vport_update_params.update_accept_any_vlan_flg = update_accept_any_vlan;
	vport_update_params.accept_any_vlan = accept_any_vlan;

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];

		vport_update_params.opaque_fid = p_hwfn->hw_info.opaque_fid;

		if (IS_VF(cdev)) {
			rc = qed_vf_pf_accept_flags(p_hwfn, &accept_flags);
			if (rc != 0)
				return rc;
			continue;
		}

		rc = qed_sp_vport_update(p_hwfn, &vport_update_params,
					 comp_mode, p_comp_data);
		if (rc != 0) {
			DP_ERR(cdev, "Update rx_mode failed %d\n", rc);
			return rc;
		}

		DP_VERBOSE(p_hwfn, QED_MSG_SP,
			   "Accept filter configured, flags = [Rx]%x [Tx]%x\n",
			   accept_flags.rx_accept_filter,
			   accept_flags.tx_accept_filter);

		if (update_accept_any_vlan)
			DP_VERBOSE(p_hwfn, QED_MSG_SP,
				   "accept_any_vlan=%d configured\n",
				   accept_any_vlan);
	}

	return 0;
}

static void qed_sp_release_queue_cid(struct qed_hwfn *p_hwfn,
				     struct qed_hw_cid_data *p_cid_data)
{
	if (!p_cid_data->b_cid_allocated)
		return;

	qed_cxt_release_cid(p_hwfn, p_cid_data->cid);
	p_cid_data->b_cid_allocated = false;
}

int
qed_sp_eth_rxq_start_ramrod(struct qed_hwfn *p_hwfn,
			    u16
			    opaque_fid,
			    u32 cid,
			    struct qed_queue_start_common_params *p_params,
			    u16
			    bd_max_bytes,
			    dma_addr_t
			    bd_chain_phys_addr,
			    dma_addr_t
			    cqe_pbl_addr,
			    u16 cqe_pbl_size, bool b_use_zone_a_prod)
{
	struct rx_queue_start_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	struct qed_hw_cid_data *p_rx_cid;
	u16 abs_rx_q_id = 0;
	u8 abs_vport_id = 0;
	int rc = -EINVAL;

	/* Store information for the stop */
	p_rx_cid = &p_hwfn->p_rx_cids[p_params->queue_id];
	p_rx_cid->cid = cid;
	p_rx_cid->opaque_fid = opaque_fid;
	p_rx_cid->vport_id = p_params->vport_id;

	rc = qed_fw_vport(p_hwfn, p_params->vport_id, &abs_vport_id);
	if (rc != 0)
		return rc;

	rc = qed_fw_l2_queue(p_hwfn, p_params->queue_id, &abs_rx_q_id);
	if (rc != 0)
		return rc;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_SP,
		   "opaque_fid=0x%x, cid=0x%x, rx_qid=0x%x, vport_id=0x%x, sb_id=0x%x\n",
		   opaque_fid,
		   cid, p_params->queue_id, p_params->vport_id, p_params->sb);

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = cid;
	init_data.opaque_fid = opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_RX_QUEUE_START,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	p_ramrod = &p_ent->ramrod.rx_queue_start;

	p_ramrod->sb_id = cpu_to_le16(p_params->sb);
	p_ramrod->sb_index = (u8) p_params->sb_idx;
	p_ramrod->vport_id = abs_vport_id;
	p_ramrod->stats_counter_id = p_params->stats_id;
	p_ramrod->rx_queue_id = cpu_to_le16(abs_rx_q_id);
	p_ramrod->complete_cqe_flg = 0;
	p_ramrod->complete_event_flg = 1;

	p_ramrod->bd_max_bytes = cpu_to_le16(bd_max_bytes);
	DMA_REGPAIR_LE(p_ramrod->bd_base, bd_chain_phys_addr);

	p_ramrod->num_of_pbl_pages = cpu_to_le16(cqe_pbl_size);
	DMA_REGPAIR_LE(p_ramrod->cqe_pbl_addr, cqe_pbl_addr);

	if (p_params->vf_qid || b_use_zone_a_prod) {
		p_ramrod->vf_rx_prod_index = (u8) p_params->vf_qid;
		DP_VERBOSE(p_hwfn,
			   QED_MSG_SP,
			   "Queue%s is meant for VF rxq[%02x]\n",
			   b_use_zone_a_prod ? " [legacy]" : "",
			   p_params->vf_qid);
		p_ramrod->vf_rx_prod_use_zone_a = b_use_zone_a_prod;
	}

	return qed_spq_post(p_hwfn, p_ent, NULL);
}

int
qed_sp_eth_rx_queue_start(struct qed_hwfn *p_hwfn,
			  u16 opaque_fid,
			  struct qed_queue_start_common_params *p_params,
			  u16 bd_max_bytes,
			  dma_addr_t
			  bd_chain_phys_addr,
			  dma_addr_t cqe_pbl_addr,
			  u16 cqe_pbl_size, void __iomem ** pp_prod)
{
	struct qed_hw_cid_data *p_rx_cid;
	u32 init_prod_val = 0;
	u16 abs_l2_queue = 0;
	u8 abs_stats_id = 0;
	int rc;

	if (IS_VF(p_hwfn->cdev)) {
		return qed_vf_pf_rxq_start(p_hwfn,
					   (u8) p_params->queue_id,
					   p_params->sb,
					   (u8) p_params->sb_idx,
					   bd_max_bytes,
					   bd_chain_phys_addr,
					   cqe_pbl_addr, cqe_pbl_size, pp_prod);
	}

	rc = qed_fw_l2_queue(p_hwfn, p_params->queue_id, &abs_l2_queue);
	if (rc != 0)
		return rc;

	rc = qed_fw_vport(p_hwfn, p_params->stats_id, &abs_stats_id);
	if (rc != 0)
		return rc;

	*pp_prod = (u8 __iomem *) p_hwfn->regview +
	    GTT_BAR0_MAP_REG_MSDM_RAM +
	    MSTORM_ETH_PF_PRODS_OFFSET(abs_l2_queue);

	/* Init the rcq, rx bd and rx sge (if valid) producers to 0 */
	__internal_ram_wr(p_hwfn, *pp_prod, sizeof(u32),
			  (u32 *) (&init_prod_val));

	/* Allocate a CID for the queue */
	p_rx_cid = &p_hwfn->p_rx_cids[p_params->queue_id];
	rc = qed_cxt_acquire_cid(p_hwfn, PROTOCOLID_ETH, &p_rx_cid->cid);
	if (rc != 0) {
		DP_NOTICE(p_hwfn, "Failed to acquire cid\n");
		return rc;
	}
	p_rx_cid->b_cid_allocated = true;
	p_params->stats_id = abs_stats_id;
	p_params->vf_qid = 0;

	rc = qed_sp_eth_rxq_start_ramrod(p_hwfn,
					 opaque_fid,
					 p_rx_cid->cid,
					 p_params,
					 bd_max_bytes,
					 bd_chain_phys_addr,
					 cqe_pbl_addr, cqe_pbl_size, false);

	if (rc != 0)
		qed_sp_release_queue_cid(p_hwfn, p_rx_cid);

	return rc;
}

int
qed_sp_eth_rx_queues_update(struct qed_hwfn *p_hwfn,
			    u16 rx_queue_id,
			    u8 num_rxqs,
			    u8 complete_cqe_flg,
			    u8 complete_event_flg,
			    enum spq_mode comp_mode,
			    struct qed_spq_comp_cb *p_comp_data)
{
	struct rx_queue_update_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	struct qed_hw_cid_data *p_rx_cid;
	u16 qid, abs_rx_q_id = 0;
	int rc = -EINVAL;
	u8 i;

	memset(&init_data, 0, sizeof(init_data));
	init_data.comp_mode = comp_mode;
	init_data.p_comp_data = p_comp_data;

	for (i = 0; i < num_rxqs; i++) {
		qid = rx_queue_id + i;
		p_rx_cid = &p_hwfn->p_rx_cids[qid];

		/* Get SPQ entry */
		init_data.cid = p_rx_cid->cid;
		init_data.opaque_fid = p_rx_cid->opaque_fid;

		rc = qed_sp_init_request(p_hwfn, &p_ent,
					 ETH_RAMROD_RX_QUEUE_UPDATE,
					 PROTOCOLID_ETH, &init_data);
		if (rc != 0)
			return rc;

		p_ramrod = &p_ent->ramrod.rx_queue_update;

		qed_fw_vport(p_hwfn, p_rx_cid->vport_id, &p_ramrod->vport_id);
		qed_fw_l2_queue(p_hwfn, qid, &abs_rx_q_id);
		p_ramrod->rx_queue_id = cpu_to_le16(abs_rx_q_id);
		p_ramrod->complete_cqe_flg = complete_cqe_flg;
		p_ramrod->complete_event_flg = complete_event_flg;

		rc = qed_spq_post(p_hwfn, p_ent, NULL);
		if (rc)
			return rc;
	}

	return rc;
}

int qed_sp_eth_rx_queue_stop(struct qed_hwfn *p_hwfn,
			     u16 rx_queue_id,
			     bool eq_completion_only, bool cqe_completion)
{
	struct qed_hw_cid_data *p_rx_cid = &p_hwfn->p_rx_cids[rx_queue_id];
	struct rx_queue_stop_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	u16 abs_rx_q_id = 0;
	int rc = -EINVAL;

	if (IS_VF(p_hwfn->cdev))
		return qed_vf_pf_rxq_stop(p_hwfn, rx_queue_id, cqe_completion);

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = p_rx_cid->cid;
	init_data.opaque_fid = p_rx_cid->opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_RX_QUEUE_STOP,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	p_ramrod = &p_ent->ramrod.rx_queue_stop;

	qed_fw_vport(p_hwfn, p_rx_cid->vport_id, &p_ramrod->vport_id);
	qed_fw_l2_queue(p_hwfn, rx_queue_id, &abs_rx_q_id);
	p_ramrod->rx_queue_id = cpu_to_le16(abs_rx_q_id);

	/* Cleaning the queue requires the completion to arrive there.
	 * In addition, VFs require the answer to come as eqe to PF.
	 */
	p_ramrod->complete_cqe_flg = (! !(p_rx_cid->opaque_fid ==
					  p_hwfn->hw_info.opaque_fid) &&
				      !eq_completion_only) || cqe_completion;
	p_ramrod->complete_event_flg = !(p_rx_cid->opaque_fid ==
					 p_hwfn->hw_info.opaque_fid) ||
	    eq_completion_only;

	rc = qed_spq_post(p_hwfn, p_ent, NULL);
	if (rc != 0)
		return rc;

	qed_sp_release_queue_cid(p_hwfn, p_rx_cid);

	return rc;
}

int
qed_sp_eth_txq_start_ramrod(struct qed_hwfn *p_hwfn,
			    u16
			    opaque_fid,
			    u32 cid,
			    struct qed_queue_start_common_params *p_params,
			    dma_addr_t
			    pbl_addr,
			    u16 pbl_size, union qed_qm_pq_params *p_pq_params)
{
	struct tx_queue_start_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	struct qed_hw_cid_data *p_tx_cid;
	u16 pq_id, abs_tx_qzone_id = 0;
	u8 abs_vport_id;
	int rc = -EINVAL;

	/* Store information for the stop */
	p_tx_cid = &p_hwfn->p_tx_cids[p_params->queue_id];
	p_tx_cid->cid = cid;
	p_tx_cid->opaque_fid = opaque_fid;

	rc = qed_fw_vport(p_hwfn, p_params->vport_id, &abs_vport_id);
	if (rc != 0)
		return rc;

	rc = qed_fw_l2_queue(p_hwfn, p_params->qzone_id, &abs_tx_qzone_id);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = cid;
	init_data.opaque_fid = opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_TX_QUEUE_START,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	p_ramrod = &p_ent->ramrod.tx_queue_start;
	p_ramrod->vport_id = abs_vport_id;

	p_ramrod->sb_id = cpu_to_le16(p_params->sb);
	p_ramrod->sb_index = (u8) p_params->sb_idx;
	p_ramrod->stats_counter_id = p_params->stats_id;

	p_ramrod->queue_zone_id = cpu_to_le16(abs_tx_qzone_id);

	p_ramrod->pbl_size = cpu_to_le16(pbl_size);
	DMA_REGPAIR_LE(p_ramrod->pbl_base_addr, pbl_addr);

	pq_id = qed_get_qm_pq(p_hwfn, PROTOCOLID_ETH, p_pq_params);
	p_ramrod->qm_pq_id = cpu_to_le16(pq_id);

	return qed_spq_post(p_hwfn, p_ent, NULL);
}

int
qed_sp_eth_tx_queue_start(struct qed_hwfn *p_hwfn,
			  u16 opaque_fid,
			  struct qed_queue_start_common_params *p_params,
			  u8 tc,
			  dma_addr_t pbl_addr,
			  u16 pbl_size, void __iomem ** pp_doorbell)
{
	struct qed_hw_cid_data *p_tx_cid;
	union qed_qm_pq_params pq_params;
	u8 abs_stats_id = 0;
	int rc;

	if (IS_VF(p_hwfn->cdev)) {
		return qed_vf_pf_txq_start(p_hwfn,
					   p_params->queue_id,
					   p_params->sb,
					   (u8) p_params->sb_idx,
					   pbl_addr, pbl_size, pp_doorbell);
	}

	rc = qed_fw_vport(p_hwfn, p_params->stats_id, &abs_stats_id);
	if (rc != 0)
		return rc;

	p_tx_cid = &p_hwfn->p_tx_cids[p_params->queue_id];
	memset(p_tx_cid, 0, sizeof(*p_tx_cid));
	memset(&pq_params, 0, sizeof(pq_params));

	pq_params.eth.tc = tc;

	/* Allocate a CID for the queue */
	rc = qed_cxt_acquire_cid(p_hwfn, PROTOCOLID_ETH, &p_tx_cid->cid);
	if (rc != 0) {
		DP_NOTICE(p_hwfn, "Failed to acquire cid\n");
		return rc;
	}
	p_tx_cid->b_cid_allocated = true;

	DP_VERBOSE(p_hwfn,
		   QED_MSG_SP,
		   "opaque_fid=0x%x, cid=0x%x, tx_qid=0x%x, vport_id=0x%x, sb_id=0x%x\n",
		   opaque_fid,
		   p_tx_cid->cid,
		   p_params->queue_id, p_params->vport_id, p_params->sb);

	p_params->stats_id = abs_stats_id;

	/* TODO - set tc in the pq_params for multi-cos */
	rc = qed_sp_eth_txq_start_ramrod(p_hwfn,
					 opaque_fid,
					 p_tx_cid->cid,
					 p_params,
					 pbl_addr, pbl_size, &pq_params);

	*pp_doorbell = (u8 __iomem *) p_hwfn->doorbells +
	    DB_ADDR(p_tx_cid->cid, DQ_DEMS_LEGACY);

	if (rc != 0)
		qed_sp_release_queue_cid(p_hwfn, p_tx_cid);

	return rc;
}

int qed_sp_eth_tx_queue_update(struct qed_hwfn *p_hwfn)
{
	return -EINVAL;
}

int qed_sp_eth_tx_queue_stop(struct qed_hwfn *p_hwfn, u16 tx_queue_id)
{
	struct qed_hw_cid_data *p_tx_cid = &p_hwfn->p_tx_cids[tx_queue_id];
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	int rc = -EINVAL;

	if (IS_VF(p_hwfn->cdev))
		return qed_vf_pf_txq_stop(p_hwfn, tx_queue_id);

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = p_tx_cid->cid;
	init_data.opaque_fid = p_tx_cid->opaque_fid;
	init_data.comp_mode = QED_SPQ_MODE_EBLOCK;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_TX_QUEUE_STOP,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	rc = qed_spq_post(p_hwfn, p_ent, NULL);
	if (rc != 0)
		return rc;

	qed_sp_release_queue_cid(p_hwfn, p_tx_cid);
	return rc;
}

static enum eth_filter_action qed_filter_action(enum qed_filter_opcode opcode)
{
	enum eth_filter_action action = MAX_ETH_FILTER_ACTION;

	switch (opcode) {
	case QED_FILTER_ADD:
		action = ETH_FILTER_ACTION_ADD;
		break;
	case QED_FILTER_REMOVE:
		action = ETH_FILTER_ACTION_REMOVE;
		break;
	case QED_FILTER_FLUSH:
		action = ETH_FILTER_ACTION_REMOVE_ALL;
		break;
	default:
		action = MAX_ETH_FILTER_ACTION;
	}

	return action;
}

static void qed_set_fw_mac_addr(__le16 * fw_msb,
				__le16 * fw_mid, __le16 * fw_lsb, u8 * mac)
{
	((u8 *) fw_msb)[0] = mac[1];
	((u8 *) fw_msb)[1] = mac[0];
	((u8 *) fw_mid)[0] = mac[3];
	((u8 *) fw_mid)[1] = mac[2];
	((u8 *) fw_lsb)[0] = mac[5];
	((u8 *) fw_lsb)[1] = mac[4];
}

static int
qed_filter_ucast_common(struct qed_hwfn *p_hwfn,
			u16 opaque_fid,
			struct qed_filter_ucast *p_filter_cmd,
			struct vport_filter_update_ramrod_data **pp_ramrod,
			struct qed_spq_entry **pp_ent,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_data)
{
	u8 vport_to_add_to = 0, vport_to_remove_from = 0;
	struct vport_filter_update_ramrod_data *p_ramrod;
	struct eth_filter_cmd *p_first_filter;
	struct eth_filter_cmd *p_second_filter;
	struct qed_sp_init_data init_data;
	enum eth_filter_action action;
	int rc;

	rc = qed_fw_vport(p_hwfn, p_filter_cmd->vport_to_remove_from,
			  &vport_to_remove_from);
	if (rc != 0)
		return rc;

	rc = qed_fw_vport(p_hwfn, p_filter_cmd->vport_to_add_to,
			  &vport_to_add_to);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = qed_spq_get_cid(p_hwfn);
	init_data.opaque_fid = opaque_fid;
	init_data.comp_mode = comp_mode;
	init_data.p_comp_data = p_comp_data;

	rc = qed_sp_init_request(p_hwfn, pp_ent,
				 ETH_RAMROD_FILTERS_UPDATE,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0)
		return rc;

	*pp_ramrod = &(*pp_ent)->ramrod.vport_filter_update;
	p_ramrod = *pp_ramrod;
	p_ramrod->filter_cmd_hdr.rx = p_filter_cmd->is_rx_filter ? 1 : 0;
	p_ramrod->filter_cmd_hdr.tx = p_filter_cmd->is_tx_filter ? 1 : 0;

#ifndef ASIC_ONLY
	if (CHIP_REV_IS_SLOW(p_hwfn->cdev)) {
		DP_VERBOSE(p_hwfn, QED_MSG_SP,
			   "Non-Asic - prevent Tx filters\n");
		p_ramrod->filter_cmd_hdr.tx = 0;
	}
#endif

	switch (p_filter_cmd->opcode) {
	case QED_FILTER_REPLACE:
	case QED_FILTER_MOVE:
		p_ramrod->filter_cmd_hdr.cmd_cnt = 2;
		break;
	default:
		p_ramrod->filter_cmd_hdr.cmd_cnt = 1;
		break;
	}

	p_first_filter = &p_ramrod->filter_cmds[0];
	p_second_filter = &p_ramrod->filter_cmds[1];

	switch (p_filter_cmd->type) {
	case QED_FILTER_MAC:
		p_first_filter->type = ETH_FILTER_TYPE_MAC;
		break;
	case QED_FILTER_VLAN:
		p_first_filter->type = ETH_FILTER_TYPE_VLAN;
		break;
	case QED_FILTER_MAC_VLAN:
		p_first_filter->type = ETH_FILTER_TYPE_PAIR;
		break;
	case QED_FILTER_INNER_MAC:
		p_first_filter->type = ETH_FILTER_TYPE_INNER_MAC;
		break;
	case QED_FILTER_INNER_VLAN:
		p_first_filter->type = ETH_FILTER_TYPE_INNER_VLAN;
		break;
	case QED_FILTER_INNER_PAIR:
		p_first_filter->type = ETH_FILTER_TYPE_INNER_PAIR;
		break;
	case QED_FILTER_INNER_MAC_VNI_PAIR:
		p_first_filter->type = ETH_FILTER_TYPE_INNER_MAC_VNI_PAIR;
		break;
	case QED_FILTER_MAC_VNI_PAIR:
		p_first_filter->type = ETH_FILTER_TYPE_MAC_VNI_PAIR;
		break;
	case QED_FILTER_VNI:
		p_first_filter->type = ETH_FILTER_TYPE_VNI;
		break;
	}

	if ((p_first_filter->type == ETH_FILTER_TYPE_MAC) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_INNER_MAC) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_INNER_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_INNER_MAC_VNI_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_MAC_VNI_PAIR)) {
		qed_set_fw_mac_addr(&p_first_filter->mac_msb,
				    &p_first_filter->mac_mid,
				    &p_first_filter->mac_lsb,
				    (u8 *) p_filter_cmd->mac);
	}

	if ((p_first_filter->type == ETH_FILTER_TYPE_VLAN) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_INNER_VLAN) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_INNER_PAIR))
		p_first_filter->vlan_id = cpu_to_le16(p_filter_cmd->vlan);

	if ((p_first_filter->type == ETH_FILTER_TYPE_INNER_MAC_VNI_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_MAC_VNI_PAIR) ||
	    (p_first_filter->type == ETH_FILTER_TYPE_VNI))
		p_first_filter->vni = cpu_to_le32(p_filter_cmd->vni);

	if (p_filter_cmd->opcode == QED_FILTER_MOVE) {
		p_second_filter->type = p_first_filter->type;
		p_second_filter->mac_msb = p_first_filter->mac_msb;
		p_second_filter->mac_mid = p_first_filter->mac_mid;
		p_second_filter->mac_lsb = p_first_filter->mac_lsb;
		p_second_filter->vlan_id = p_first_filter->vlan_id;
		p_second_filter->vni = p_first_filter->vni;

		p_first_filter->action = ETH_FILTER_ACTION_REMOVE;

		p_first_filter->vport_id = vport_to_remove_from;

		p_second_filter->action = ETH_FILTER_ACTION_ADD;
		p_second_filter->vport_id = vport_to_add_to;
	} else if (p_filter_cmd->opcode == QED_FILTER_REPLACE) {
		p_first_filter->vport_id = vport_to_add_to;
		memcpy(p_second_filter, p_first_filter,
		       sizeof(*p_second_filter));
		p_first_filter->action = ETH_FILTER_ACTION_REMOVE_ALL;
		p_second_filter->action = ETH_FILTER_ACTION_ADD;
	} else {
		action = qed_filter_action(p_filter_cmd->opcode);

		if (action == MAX_ETH_FILTER_ACTION) {
			DP_NOTICE(p_hwfn,
				  "%d is not supported yet\n",
				  p_filter_cmd->opcode);
			return -EINVAL;
		}

		p_first_filter->action = action;
		p_first_filter->vport_id =
		    (p_filter_cmd->opcode == QED_FILTER_REMOVE) ?
		    vport_to_remove_from : vport_to_add_to;
	}

	return 0;
}

int
qed_sp_eth_filter_ucast(struct qed_hwfn *p_hwfn,
			u16 opaque_fid,
			struct qed_filter_ucast *p_filter_cmd,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_data)
{
	struct vport_filter_update_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct eth_filter_cmd_header *p_header;
	int rc;

	rc = qed_filter_ucast_common(p_hwfn, opaque_fid, p_filter_cmd,
				     &p_ramrod, &p_ent, comp_mode, p_comp_data);
	if (rc != 0) {
		DP_ERR(p_hwfn, "Uni. filter command failed %d\n", rc);
		return rc;
	}
	p_header = &p_ramrod->filter_cmd_hdr;
	p_header->assert_on_error = p_filter_cmd->assert_on_error;

	rc = qed_spq_post(p_hwfn, p_ent, NULL);
	if (rc != 0) {
		DP_ERR(p_hwfn, "Unicast filter ADD command failed %d\n", rc);
		return rc;
	}

	DP_VERBOSE(p_hwfn,
		   QED_MSG_SP,
		   "Unicast filter configured, opcode = %s, type = %s, cmd_cnt = %d, is_rx_filter = %d, is_tx_filter = %d\n",
		   (p_filter_cmd->opcode == QED_FILTER_ADD) ? "ADD" :
		   ((p_filter_cmd->opcode == QED_FILTER_REMOVE) ?
		    "REMOVE" :
		    ((p_filter_cmd->opcode == QED_FILTER_MOVE) ?
		     "MOVE" : "REPLACE")),
		   (p_filter_cmd->type == QED_FILTER_MAC) ? "MAC" :
		   ((p_filter_cmd->type == QED_FILTER_VLAN) ?
		    "VLAN" : "MAC & VLAN"),
		   p_ramrod->filter_cmd_hdr.cmd_cnt,
		   p_filter_cmd->is_rx_filter, p_filter_cmd->is_tx_filter);
	DP_VERBOSE(p_hwfn,
		   QED_MSG_SP,
		   "vport_to_add_to = %d, vport_to_remove_from = %d, mac = %2x:%2x:%2x:%2x:%2x:%2x, vlan = %d\n",
		   p_filter_cmd->vport_to_add_to,
		   p_filter_cmd->vport_to_remove_from,
		   p_filter_cmd->mac[0],
		   p_filter_cmd->mac[1],
		   p_filter_cmd->mac[2],
		   p_filter_cmd->mac[3],
		   p_filter_cmd->mac[4],
		   p_filter_cmd->mac[5], p_filter_cmd->vlan);

	return 0;
}

/*******************************************************************************
 * Description:
 *         Calculates crc 32 on a buffer
 *         Note: crc32_length MUST be aligned to 8
 * Return:
 ******************************************************************************/
static u32 qed_calc_crc32c(u8 * crc32_packet,
			   u32 crc32_length, u32 crc32_seed, u8 complement)
{
	u32 byte = 0, bit = 0, crc32_result = crc32_seed;
	u8 msb = 0, current_byte = 0;

	if ((crc32_packet == NULL) ||
	    (crc32_length == 0) || ((crc32_length % 8) != 0))
		return crc32_result;

	for (byte = 0; byte < crc32_length; byte++) {
		current_byte = crc32_packet[byte];
		for (bit = 0; bit < 8; bit++) {
			msb = (u8) (crc32_result >> 31);
			crc32_result = crc32_result << 1;
			if (msb != (0x1 & (current_byte >> bit))) {
				crc32_result = crc32_result ^ CRC32_POLY;
				crc32_result |= 1;	/*crc32_result[0] = 1; */
			}
		}
	}

	return crc32_result;
}

static u32 qed_crc32c_le(u32 seed, u8 * mac, u32 len)
{
	u32 packet_buf[2] = { 0 };

	memcpy((u8 *) (&packet_buf[0]), &mac[0], 6);
	return qed_calc_crc32c((u8 *) packet_buf, 8, seed, 0);
}

u8 qed_mcast_bin_from_mac(u8 * mac)
{
	u32 crc = qed_crc32c_le(ETH_MULTICAST_BIN_FROM_MAC_SEED,
				mac, ETH_ALEN);

	return crc & 0xff;
}

static int
qed_sp_eth_filter_mcast(struct qed_hwfn *p_hwfn,
			u16 opaque_fid,
			struct qed_filter_mcast *p_filter_cmd,
			enum spq_mode comp_mode,
			struct qed_spq_comp_cb *p_comp_data)
{
	unsigned long bins[ETH_MULTICAST_MAC_BINS_IN_REGS];
	struct vport_update_ramrod_data *p_ramrod = NULL;
	struct qed_spq_entry *p_ent = NULL;
	struct qed_sp_init_data init_data;
	u8 abs_vport_id = 0;
	int rc;
	int i;

	if (p_filter_cmd->opcode == QED_FILTER_ADD)
		rc = qed_fw_vport(p_hwfn, p_filter_cmd->vport_to_add_to,
				  &abs_vport_id);
	else
		rc = qed_fw_vport(p_hwfn, p_filter_cmd->vport_to_remove_from,
				  &abs_vport_id);
	if (rc != 0)
		return rc;

	/* Get SPQ entry */
	memset(&init_data, 0, sizeof(init_data));
	init_data.cid = qed_spq_get_cid(p_hwfn);
	init_data.opaque_fid = p_hwfn->hw_info.opaque_fid;
	init_data.comp_mode = comp_mode;
	init_data.p_comp_data = p_comp_data;

	rc = qed_sp_init_request(p_hwfn, &p_ent,
				 ETH_RAMROD_VPORT_UPDATE,
				 PROTOCOLID_ETH, &init_data);
	if (rc != 0) {
		DP_ERR(p_hwfn, "Multi-cast command failed %d\n", rc);
		return rc;
	}

	p_ramrod = &p_ent->ramrod.vport_update;
	p_ramrod->common.update_approx_mcast_flg = 1;

	/* explicitly clear out the entire vector */
	memset(&p_ramrod->approx_mcast.bins,
	       0, sizeof(p_ramrod->approx_mcast.bins));
	memset(bins, 0, sizeof(unsigned long) * ETH_MULTICAST_MAC_BINS_IN_REGS);
	/* filter ADD op is explicit set op and it removes
	 *  any existing filters for the vport.
	 */
	if (p_filter_cmd->opcode == QED_FILTER_ADD) {
		for (i = 0; i < p_filter_cmd->num_mc_addrs; i++) {
			u32 bit;

			bit = qed_mcast_bin_from_mac(p_filter_cmd->mac[i]);
			__set_bit(bit, bins);
		}

		/* Convert to correct endianity */
		for (i = 0; i < ETH_MULTICAST_MAC_BINS_IN_REGS; i++) {
			struct vport_update_ramrod_mcast *p_ramrod_bins;
			u32 *p_bins = (u32 *) bins;

			p_ramrod_bins = &p_ramrod->approx_mcast;
			p_ramrod_bins->bins[i] = cpu_to_le32(p_bins[i]);
		}
	}

	p_ramrod->common.vport_id = abs_vport_id;

	rc = qed_spq_post(p_hwfn, p_ent, NULL);
	if (rc != 0)
		DP_ERR(p_hwfn, "Multicast filter command failed %d\n", rc);

	return rc;
}

int qed_filter_mcast_cmd(struct qed_dev *cdev,
			 struct qed_filter_mcast *p_filter_cmd,
			 enum spq_mode comp_mode,
			 struct qed_spq_comp_cb *p_comp_data)
{
	int rc = 0;
	int i;

	/* only ADD and REMOVE operations are supported for multi-cast */
	if ((p_filter_cmd->opcode != QED_FILTER_ADD &&
	     (p_filter_cmd->opcode != QED_FILTER_REMOVE)) ||
	    (p_filter_cmd->num_mc_addrs > QED_MAX_MC_ADDRS))
		return -EINVAL;

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];
		u16 opaque_fid;

		if (IS_VF(cdev)) {
			qed_vf_pf_filter_mcast(p_hwfn, p_filter_cmd);
			continue;
		}

		opaque_fid = p_hwfn->hw_info.opaque_fid;
		rc = qed_sp_eth_filter_mcast(p_hwfn,
					     opaque_fid,
					     p_filter_cmd,
					     comp_mode, p_comp_data);
		if (rc != 0)
			break;
	}

	return rc;
}

int qed_filter_ucast_cmd(struct qed_dev *cdev,
			 struct qed_filter_ucast *p_filter_cmd,
			 enum spq_mode comp_mode,
			 struct qed_spq_comp_cb *p_comp_data)
{
	int rc = 0;
	int i;

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];
		u16 opaque_fid;

		if (IS_VF(cdev)) {
			rc = qed_vf_pf_filter_ucast(p_hwfn, p_filter_cmd);
			continue;
		}

		opaque_fid = p_hwfn->hw_info.opaque_fid;
		rc = qed_sp_eth_filter_ucast(p_hwfn,
					     opaque_fid,
					     p_filter_cmd,
					     comp_mode, p_comp_data);
		if (rc != 0)
			break;
	}

	return rc;
}

/* Statistics related code */
static void __qed_get_vport_pstats_addrlen(struct qed_hwfn *p_hwfn,
					   u32 * p_addr,
					   u32 * p_len, u16 statistics_bin)
{
	if (IS_PF(p_hwfn->cdev)) {
		*p_addr = BAR0_MAP_REG_PSDM_RAM +
		    PSTORM_QUEUE_STAT_OFFSET(statistics_bin);
		*p_len = sizeof(struct eth_pstorm_per_queue_stat);
	} else {
		struct qed_vf_iov *p_iov = p_hwfn->vf_iov_info;
		struct pfvf_acquire_resp_tlv *p_resp = &p_iov->acquire_resp;

		*p_addr = p_resp->pfdev_info.stats_info.pstats.address;
		*p_len = p_resp->pfdev_info.stats_info.pstats.len;
	}
}

static void __qed_get_vport_pstats(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   struct qed_eth_stats *p_stats,
				   u16 statistics_bin)
{
	struct eth_pstorm_per_queue_stat pstats;
	u32 pstats_addr = 0, pstats_len = 0;

	__qed_get_vport_pstats_addrlen(p_hwfn, &pstats_addr, &pstats_len,
				       statistics_bin);

	memset(&pstats, 0, sizeof(pstats));
	qed_memcpy_from(p_hwfn, p_ptt, &pstats, pstats_addr, pstats_len);

	p_stats->tx_ucast_bytes += HILO_64_REGPAIR(pstats.sent_ucast_bytes);
	p_stats->tx_mcast_bytes += HILO_64_REGPAIR(pstats.sent_mcast_bytes);
	p_stats->tx_bcast_bytes += HILO_64_REGPAIR(pstats.sent_bcast_bytes);
	p_stats->tx_ucast_pkts += HILO_64_REGPAIR(pstats.sent_ucast_pkts);
	p_stats->tx_mcast_pkts += HILO_64_REGPAIR(pstats.sent_mcast_pkts);
	p_stats->tx_bcast_pkts += HILO_64_REGPAIR(pstats.sent_bcast_pkts);
	p_stats->tx_err_drop_pkts += HILO_64_REGPAIR(pstats.error_drop_pkts);
}

static void __qed_get_vport_tstats(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   struct qed_eth_stats *p_stats,
				   u16 statistics_bin)
{
	struct tstorm_per_port_stat tstats;
	u32 tstats_addr, tstats_len;

	if (IS_PF(p_hwfn->cdev)) {
		tstats_addr = BAR0_MAP_REG_TSDM_RAM +
		    TSTORM_PORT_STAT_OFFSET(MFW_PORT(p_hwfn));
		tstats_len = sizeof(struct tstorm_per_port_stat);
	} else {
		struct qed_vf_iov *p_iov = p_hwfn->vf_iov_info;
		struct pfvf_acquire_resp_tlv *p_resp = &p_iov->acquire_resp;

		tstats_addr = p_resp->pfdev_info.stats_info.tstats.address;
		tstats_len = p_resp->pfdev_info.stats_info.tstats.len;
	}

	memset(&tstats, 0, sizeof(tstats));
	qed_memcpy_from(p_hwfn, p_ptt, &tstats, tstats_addr, tstats_len);

	p_stats->mftag_filter_discards +=
	    HILO_64_REGPAIR(tstats.mftag_filter_discard);
	p_stats->mac_filter_discards +=
	    HILO_64_REGPAIR(tstats.eth_mac_filter_discard);
}

static void __qed_get_vport_ustats_addrlen(struct qed_hwfn *p_hwfn,
					   u32 * p_addr,
					   u32 * p_len, u16 statistics_bin)
{
	if (IS_PF(p_hwfn->cdev)) {
		*p_addr = BAR0_MAP_REG_USDM_RAM +
		    USTORM_QUEUE_STAT_OFFSET(statistics_bin);
		*p_len = sizeof(struct eth_ustorm_per_queue_stat);
	} else {
		struct qed_vf_iov *p_iov = p_hwfn->vf_iov_info;
		struct pfvf_acquire_resp_tlv *p_resp = &p_iov->acquire_resp;

		*p_addr = p_resp->pfdev_info.stats_info.ustats.address;
		*p_len = p_resp->pfdev_info.stats_info.ustats.len;
	}
}

static void __qed_get_vport_ustats(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   struct qed_eth_stats *p_stats,
				   u16 statistics_bin)
{
	struct eth_ustorm_per_queue_stat ustats;
	u32 ustats_addr = 0, ustats_len = 0;

	__qed_get_vport_ustats_addrlen(p_hwfn, &ustats_addr, &ustats_len,
				       statistics_bin);

	memset(&ustats, 0, sizeof(ustats));
	qed_memcpy_from(p_hwfn, p_ptt, &ustats, ustats_addr, ustats_len);

	p_stats->rx_ucast_bytes += HILO_64_REGPAIR(ustats.rcv_ucast_bytes);
	p_stats->rx_mcast_bytes += HILO_64_REGPAIR(ustats.rcv_mcast_bytes);
	p_stats->rx_bcast_bytes += HILO_64_REGPAIR(ustats.rcv_bcast_bytes);
	p_stats->rx_ucast_pkts += HILO_64_REGPAIR(ustats.rcv_ucast_pkts);
	p_stats->rx_mcast_pkts += HILO_64_REGPAIR(ustats.rcv_mcast_pkts);
	p_stats->rx_bcast_pkts += HILO_64_REGPAIR(ustats.rcv_bcast_pkts);
}

static void __qed_get_vport_mstats_addrlen(struct qed_hwfn *p_hwfn,
					   u32 * p_addr,
					   u32 * p_len, u16 statistics_bin)
{
	if (IS_PF(p_hwfn->cdev)) {
		*p_addr = BAR0_MAP_REG_MSDM_RAM +
		    MSTORM_QUEUE_STAT_OFFSET(statistics_bin);
		*p_len = sizeof(struct eth_mstorm_per_queue_stat);
	} else {
		struct qed_vf_iov *p_iov = p_hwfn->vf_iov_info;
		struct pfvf_acquire_resp_tlv *p_resp = &p_iov->acquire_resp;

		*p_addr = p_resp->pfdev_info.stats_info.mstats.address;
		*p_len = p_resp->pfdev_info.stats_info.mstats.len;
	}
}

static void __qed_get_vport_mstats(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt,
				   struct qed_eth_stats *p_stats,
				   u16 statistics_bin)
{
	struct eth_mstorm_per_queue_stat mstats;
	u32 mstats_addr = 0, mstats_len = 0;

	__qed_get_vport_mstats_addrlen(p_hwfn, &mstats_addr, &mstats_len,
				       statistics_bin);

	memset(&mstats, 0, sizeof(mstats));
	qed_memcpy_from(p_hwfn, p_ptt, &mstats, mstats_addr, mstats_len);

	p_stats->no_buff_discards += HILO_64_REGPAIR(mstats.no_buff_discard);
	p_stats->packet_too_big_discard +=
	    HILO_64_REGPAIR(mstats.packet_too_big_discard);
	p_stats->ttl0_discard += HILO_64_REGPAIR(mstats.ttl0_discard);
	p_stats->tpa_coalesced_pkts +=
	    HILO_64_REGPAIR(mstats.tpa_coalesced_pkts);
	p_stats->tpa_coalesced_events +=
	    HILO_64_REGPAIR(mstats.tpa_coalesced_events);
	p_stats->tpa_aborts_num += HILO_64_REGPAIR(mstats.tpa_aborts_num);
	p_stats->tpa_coalesced_bytes +=
	    HILO_64_REGPAIR(mstats.tpa_coalesced_bytes);
}

static void __qed_get_vport_port_stats(struct qed_hwfn *p_hwfn,
				       struct qed_ptt *p_ptt,
				       struct qed_eth_stats *p_stats)
{
	struct port_stats port_stats;
	int j;

	memset(&port_stats, 0, sizeof(port_stats));

	qed_memcpy_from(p_hwfn, p_ptt, &port_stats,
			p_hwfn->mcp_info->port_addr +
			offsetof(struct public_port, stats),
			sizeof(port_stats));

	p_stats->rx_64_byte_packets += port_stats.eth.r64;
	p_stats->rx_65_to_127_byte_packets += port_stats.eth.r127;
	p_stats->rx_128_to_255_byte_packets += port_stats.eth.r255;
	p_stats->rx_256_to_511_byte_packets += port_stats.eth.r511;
	p_stats->rx_512_to_1023_byte_packets += port_stats.eth.r1023;
	p_stats->rx_1024_to_1518_byte_packets += port_stats.eth.r1518;
	p_stats->rx_1519_to_1522_byte_packets += port_stats.eth.r1522;
	p_stats->rx_1519_to_2047_byte_packets += port_stats.eth.r2047;
	p_stats->rx_2048_to_4095_byte_packets += port_stats.eth.r4095;
	p_stats->rx_4096_to_9216_byte_packets += port_stats.eth.r9216;
	p_stats->rx_9217_to_16383_byte_packets += port_stats.eth.r16383;
	p_stats->rx_crc_errors += port_stats.eth.rfcs;
	p_stats->rx_mac_crtl_frames += port_stats.eth.rxcf;
	p_stats->rx_pause_frames += port_stats.eth.rxpf;
	p_stats->rx_pfc_frames += port_stats.eth.rxpp;
	p_stats->rx_align_errors += port_stats.eth.raln;
	p_stats->rx_carrier_errors += port_stats.eth.rfcr;
	p_stats->rx_oversize_packets += port_stats.eth.rovr;
	p_stats->rx_jabbers += port_stats.eth.rjbr;
	p_stats->rx_undersize_packets += port_stats.eth.rund;
	p_stats->rx_fragments += port_stats.eth.rfrg;
	p_stats->tx_64_byte_packets += port_stats.eth.t64;
	p_stats->tx_65_to_127_byte_packets += port_stats.eth.t127;
	p_stats->tx_128_to_255_byte_packets += port_stats.eth.t255;
	p_stats->tx_256_to_511_byte_packets += port_stats.eth.t511;
	p_stats->tx_512_to_1023_byte_packets += port_stats.eth.t1023;
	p_stats->tx_1024_to_1518_byte_packets += port_stats.eth.t1518;
	p_stats->tx_1519_to_2047_byte_packets += port_stats.eth.t2047;
	p_stats->tx_2048_to_4095_byte_packets += port_stats.eth.t4095;
	p_stats->tx_4096_to_9216_byte_packets += port_stats.eth.t9216;
	p_stats->tx_9217_to_16383_byte_packets += port_stats.eth.t16383;
	p_stats->tx_pause_frames += port_stats.eth.txpf;
	p_stats->tx_pfc_frames += port_stats.eth.txpp;
	p_stats->tx_lpi_entry_count += port_stats.eth.tlpiec;
	p_stats->tx_total_collisions += port_stats.eth.tncl;
	p_stats->rx_mac_bytes += port_stats.eth.rbyte;
	p_stats->rx_mac_uc_packets += port_stats.eth.rxuca;
	p_stats->rx_mac_mc_packets += port_stats.eth.rxmca;
	p_stats->rx_mac_bc_packets += port_stats.eth.rxbca;
	p_stats->rx_mac_frames_ok += port_stats.eth.rxpok;
	p_stats->tx_mac_bytes += port_stats.eth.tbyte;
	p_stats->tx_mac_uc_packets += port_stats.eth.txuca;
	p_stats->tx_mac_mc_packets += port_stats.eth.txmca;
	p_stats->tx_mac_bc_packets += port_stats.eth.txbca;
	p_stats->tx_mac_ctrl_frames += port_stats.eth.txcf;
	for (j = 0; j < 8; j++) {
		p_stats->brb_truncates += port_stats.brb.brb_truncate[j];
		p_stats->brb_discards += port_stats.brb.brb_discard[j];
	}
}

void __qed_get_vport_stats(struct qed_hwfn *p_hwfn,
			   struct qed_ptt *p_ptt,
			   struct qed_eth_stats *stats,
			   u16 statistics_bin, bool b_get_port_stats)
{
	__qed_get_vport_mstats(p_hwfn, p_ptt, stats, statistics_bin);
	__qed_get_vport_ustats(p_hwfn, p_ptt, stats, statistics_bin);
	__qed_get_vport_tstats(p_hwfn, p_ptt, stats, statistics_bin);
	__qed_get_vport_pstats(p_hwfn, p_ptt, stats, statistics_bin);

#ifndef ASIC_ONLY
	/* Avoid getting PORT stats for emulation. */
	if (CHIP_REV_IS_EMUL(p_hwfn->cdev))
		return;
#endif

	if (b_get_port_stats && p_hwfn->mcp_info)
		__qed_get_vport_port_stats(p_hwfn, p_ptt, stats);
}

static void _qed_get_vport_stats(struct qed_dev *cdev,
				 struct qed_eth_stats *stats)
{
	u8 fw_vport = 0;
	int i;

	memset(stats, 0, sizeof(*stats));

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];
		struct qed_ptt *p_ptt = IS_PF(cdev) ?
		    qed_ptt_acquire(p_hwfn) : NULL;

		if (IS_PF(cdev)) {
			/* The main vport index is relative first */
			if (qed_fw_vport(p_hwfn, 0, &fw_vport)) {
				DP_ERR(p_hwfn, "No vport available!\n");
				goto out;
			}
		}

		if (IS_PF(cdev) && !p_ptt) {
			DP_ERR(p_hwfn, "Failed to acquire ptt\n");
			continue;
		}

		__qed_get_vport_stats(p_hwfn, p_ptt, stats, fw_vport,
				      IS_PF(cdev) ? true : false);

out:
		if (IS_PF(cdev) && p_ptt)
			qed_ptt_release(p_hwfn, p_ptt);
	}
}

void qed_get_vport_stats(struct qed_dev *cdev, struct qed_eth_stats *stats)
{
	u32 i;

	if (!cdev) {
		memset(stats, 0, sizeof(*stats));
		return;
	}

	_qed_get_vport_stats(cdev, stats);

	if (!cdev->reset_stats)
		return;

	/* Reduce the statistics baseline */
	for (i = 0; i < sizeof(struct qed_eth_stats) / sizeof(u64); i++)
		((u64 *) stats)[i] -= ((u64 *) cdev->reset_stats)[i];
}

/* zeroes V-PORT specific portion of stats (Port stats remains untouched) */
void qed_reset_vport_stats(struct qed_dev *cdev)
{
	int i;

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];
		struct eth_mstorm_per_queue_stat mstats;
		struct eth_ustorm_per_queue_stat ustats;
		struct eth_pstorm_per_queue_stat pstats;
		struct qed_ptt *p_ptt = IS_PF(cdev) ?
		    qed_ptt_acquire(p_hwfn) : NULL;
		u32 addr = 0, len = 0;

		if (IS_PF(cdev) && !p_ptt) {
			DP_ERR(p_hwfn, "Failed to acquire ptt\n");
			continue;
		}

		memset(&mstats, 0, sizeof(mstats));
		__qed_get_vport_mstats_addrlen(p_hwfn, &addr, &len, 0);
		qed_memcpy_to(p_hwfn, p_ptt, addr, &mstats, len);

		memset(&ustats, 0, sizeof(ustats));
		__qed_get_vport_ustats_addrlen(p_hwfn, &addr, &len, 0);
		qed_memcpy_to(p_hwfn, p_ptt, addr, &ustats, len);

		memset(&pstats, 0, sizeof(pstats));
		__qed_get_vport_pstats_addrlen(p_hwfn, &addr, &len, 0);
		qed_memcpy_to(p_hwfn, p_ptt, addr, &pstats, len);

		if (IS_PF(cdev))
			qed_ptt_release(p_hwfn, p_ptt);
	}

	/* PORT statistics are not necessarily reset, so we need to
	 * read and create a baseline for future statistics.
	 */
	if (!cdev->reset_stats)
		DP_INFO(cdev, "Reset stats not allocated\n");
	else
		_qed_get_vport_stats(cdev, cdev->reset_stats);
}

extern const struct qed_common_ops qed_common_ops_pass;
#ifdef CONFIG_QED_SRIOV
extern const struct qed_iov_hv_ops qed_iov_ops_pass;
#endif

static int qed_fill_eth_dev_info(struct qed_dev *cdev,
				 struct qed_dev_eth_info *info)
{
	int i;

	memset(info, 0, sizeof(*info));

	info->num_tc = 1;	/* TBD obtain from hw_info.num_hw_tcs */

	if (IS_PF(cdev)) {
		int max_vf_vlan_filters = 0;

		info->num_queues = 0;
		if (cdev->int_params.out.int_mode == QED_INT_MODE_MSIX) {
			for_each_hwfn(cdev, i)
			    info->num_queues +=
			    FEAT_NUM(&cdev->hwfns[i], QED_PF_L2_QUE);
			if (cdev->int_params.fp_msix_cnt)
				info->num_queues =
				    min_t(u8, info->num_queues,
					  cdev->int_params.fp_msix_cnt);
		} else {
			info->num_queues = cdev->num_hwfns;
		}

		if (cdev->p_iov_info)
			max_vf_vlan_filters = cdev->p_iov_info->total_vfs *
			    QED_ETH_VF_NUM_VLAN_FILTERS;
		info->num_vlan_filters = RESC_NUM(&cdev->hwfns[0], QED_VLAN) -
		    max_vf_vlan_filters;

		ether_addr_copy(info->port_mac,
				cdev->hwfns[0].hw_info.hw_mac_addr);
	} else {
		qed_vf_get_num_rxqs(QED_LEADING_HWFN(cdev), &info->num_queues);
		if (cdev->num_hwfns > 1) {
			u8 queues = 0;

			qed_vf_get_num_rxqs(&cdev->hwfns[1], &queues);
			info->num_queues += queues;
		}

		qed_vf_get_num_vlan_filters(&cdev->hwfns[0],
					    (u8 *) & info->num_vlan_filters);
		qed_vf_get_port_mac(&cdev->hwfns[0], info->port_mac);

		info->is_legacy = ! !cdev->hwfns[0].vf_iov_info->b_pre_fp_hsi;
	}

	qed_fill_dev_info(cdev, &info->common);

	if (IS_VF(cdev))
		memset(info->common.hw_mac, 0, ETH_ALEN);

	return 0;
}

static void qed_register_eth_ops(struct qed_dev *cdev,
				 struct qed_eth_cb_ops *ops, void *cookie)
{
	cdev->protocol_ops.eth = ops;
	cdev->ops_cookie = cookie;

	/* For VF, we start bulletin reading */
	if (IS_VF(cdev))
		qed_vf_start_iov_wq(cdev);
}

static bool qed_check_mac(struct qed_dev *cdev, u8 * mac)
{
	if (IS_PF(cdev))
		return true;

	return qed_vf_check_mac(&cdev->hwfns[0], mac);
}

static int qed_start_vport(struct qed_dev *cdev,
			   struct qed_start_vport_params *params)
{
	int rc, i;

	for_each_hwfn(cdev, i) {
		struct qed_sp_vport_start_params start = { 0 };
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];
		u8 tx_switching = 0;

		start.tpa_mode = params->gro_enable ? QED_TPA_MODE_GRO :
		    QED_TPA_MODE_NONE;
		start.remove_inner_vlan = params->remove_inner_vlan;
		start.tx_switching = tx_switching;
		start.only_untagged = true;	/* untagged only */
		start.drop_ttl0 = params->drop_ttl0;
		start.opaque_fid = p_hwfn->hw_info.opaque_fid;
		start.concrete_fid = p_hwfn->hw_info.concrete_fid;
		start.handle_ptp_pkts = params->handle_ptp_pkts;
		start.vport_id = params->vport_id;
		start.max_buffers_per_cqe = 16;	/* TODO-is this always right */
		start.mtu = params->mtu;

		rc = qed_sp_vport_start(p_hwfn, &start);
		if (rc) {
			DP_ERR(cdev, "Failed to start VPORT\n");
			return rc;
		}

		qed_hw_start_fastpath(p_hwfn);

		DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
			   "Started V-PORT %d with MTU %d\n",
			   start.vport_id, start.mtu);
	}

	if (params->clear_stats)
		qed_reset_vport_stats(cdev);

	return 0;
}

static int qed_stop_vport(struct qed_dev *cdev, u8 vport_id)
{
	int rc, i;

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];

		rc = qed_sp_vport_stop(p_hwfn,
				       p_hwfn->hw_info.opaque_fid, vport_id);

		if (rc) {
			DP_ERR(cdev, "Failed to stop VPORT\n");
			return rc;
		}
	}
	return 0;
}

static int qed_update_vport(struct qed_dev *cdev,
			    struct qed_update_vport_params *params)
{
	struct qed_sp_vport_update_params sp_params;
	struct qed_rss_params sp_rss_params;
	int rc, i;

	if (!cdev)
		return -ENODEV;

#ifndef ASIC_ONLY
	/* This is a relatively crude hack - for VFs we enable Tx switching on
	 * vport start, and the only vport-updates we send for tx-switching
	 * for PF is either:
	 *   a. One that contains only it [when enabling IOV].
	 *   b. Together with the activation when starting queues, in case
	 *      PF is ifup-ed after VF.
	 */
	if (CHIP_REV_IS_FPGA(cdev) && params->update_tx_switching_flg) {
		if (params->vport_active_flg) {
			DP_NOTICE(cdev,
				  "FPGA: Crude Hack - tx switching on initial vport update - ignore the tx-switching bits\n");
			params->update_tx_switching_flg = 0;
			params->tx_switching_flg = 0;
		} else {
			DP_NOTICE(cdev,
				  "FPGA: Crude Hack - tx switching without vport_active means it came alone; Ignore the request\n");
			return 0;
		}
	}
#endif

	memset(&sp_params, 0, sizeof(sp_params));
	memset(&sp_rss_params, 0, sizeof(sp_rss_params));

	/* Translate protocol params into sp params */
	sp_params.vport_id = params->vport_id;
	sp_params.update_vport_active_rx_flg = params->update_vport_active_flg;
	sp_params.update_vport_active_tx_flg = params->update_vport_active_flg;
	sp_params.vport_active_rx_flg = params->vport_active_flg;
	sp_params.vport_active_tx_flg = params->vport_active_flg;
	sp_params.update_inner_vlan_removal_flg =
	    params->update_inner_vlan_removal_flg;
	sp_params.inner_vlan_removal_flg = params->inner_vlan_removal_flg;
	sp_params.update_tx_switching_flg = params->update_tx_switching_flg;
	sp_params.tx_switching_flg = params->tx_switching_flg;
	sp_params.accept_any_vlan = params->accept_any_vlan;
	sp_params.update_accept_any_vlan_flg =
	    params->update_accept_any_vlan_flg;

	/* RSS - is a bit tricky, since upper-layer isn't familiar with hwfns.
	 * We need to re-fix the rss values per engine for CMT.
	 */
	if (cdev->num_hwfns > 1 && params->update_rss_flg) {
		struct qed_update_vport_rss_params *rss = &params->rss_params;
		int k, max = 0;

		/* Find largest entry, since it's possible RSS needs to
		 * be disabled [in case only 1 queue per-hwfn]
		 */
		for (k = 0; k < QED_RSS_IND_TABLE_SIZE; k++)
			max = (max > rss->rss_ind_table[k]) ?
			    max : rss->rss_ind_table[k];

		/* Either fix RSS values or disable RSS */
		if (cdev->num_hwfns < max + 1) {
			int divisor = (max + cdev->num_hwfns - 1) /
			    cdev->num_hwfns;

			DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
				   "CMT - fixing RSS values (modulo %02x)\n",
				   divisor);

			for (k = 0; k < QED_RSS_IND_TABLE_SIZE; k++)
				rss->rss_ind_table[k] =
				    rss->rss_ind_table[k] % divisor;
		} else {
			DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
				   "CMT - 1 queue per-hwfn; Disabling RSS\n");
			params->update_rss_flg = 0;
		}
	}

	/* Now, update the RSS configuration for actual configuration */
	if (params->update_rss_flg) {
		sp_rss_params.update_rss_config = 1;
		sp_rss_params.rss_enable = 1;
		sp_rss_params.update_rss_capabilities = 1;
		sp_rss_params.update_rss_ind_table = 1;
		sp_rss_params.update_rss_key = 1;
		sp_rss_params.rss_caps = params->rss_params.rss_caps;
		sp_rss_params.rss_table_size_log = 7;	/* 2^7 = 128 */
		memcpy(sp_rss_params.rss_ind_table,
		       params->rss_params.rss_ind_table,
		       QED_RSS_IND_TABLE_SIZE * sizeof(u16));
		memcpy(sp_rss_params.rss_key, params->rss_params.rss_key,
		       QED_RSS_KEY_SIZE * sizeof(u32));
		sp_params.rss_params = &sp_rss_params;
	}

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *p_hwfn = &cdev->hwfns[i];

		sp_params.opaque_fid = p_hwfn->hw_info.opaque_fid;
		rc = qed_sp_vport_update(p_hwfn,
					 &sp_params, QED_SPQ_MODE_EBLOCK, NULL);
		if (rc) {
			DP_ERR(cdev, "Failed to update VPORT\n");
			return rc;
		}

		DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
			   "Updated V-PORT %d: active_flag %d [update %d]\n",
			   params->vport_id, params->vport_active_flg,
			   params->update_vport_active_flg);
	}

	return 0;
}

static int qed_start_rxq(struct qed_dev *cdev,
			 u8 rss_num,
			 struct qed_queue_start_common_params *p_params,
			 u16 bd_max_bytes,
			 dma_addr_t
			 bd_chain_phys_addr,
			 dma_addr_t cqe_pbl_addr,
			 u16 cqe_pbl_size, void __iomem ** pp_prod)
{
	struct qed_hwfn *p_hwfn;
	int rc, hwfn_index;

	hwfn_index = rss_num % cdev->num_hwfns;
	p_hwfn = &cdev->hwfns[hwfn_index];

	p_params->queue_id = p_params->queue_id / cdev->num_hwfns;
	p_params->stats_id = p_params->vport_id;

	rc = qed_sp_eth_rx_queue_start(p_hwfn,
				       p_hwfn->hw_info.opaque_fid,
				       p_params,
				       bd_max_bytes,
				       bd_chain_phys_addr,
				       cqe_pbl_addr, cqe_pbl_size, pp_prod);

	if (rc) {
		DP_ERR(cdev, "Failed to start RXQ#%d\n", p_params->queue_id);
		return rc;
	}

	DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
		   "Started RX-Q %d [rss_num %d] on V-PORT %d and SB %d\n",
		   p_params->queue_id, rss_num, p_params->vport_id,
		   p_params->sb);

	return 0;
}

static int qed_stop_rxq(struct qed_dev *cdev,
			struct qed_stop_rxq_params *params)
{
	int rc, hwfn_index;
	struct qed_hwfn *p_hwfn;

	hwfn_index = params->rss_id % cdev->num_hwfns;
	p_hwfn = &cdev->hwfns[hwfn_index];

	rc = qed_sp_eth_rx_queue_stop(p_hwfn,
				      params->rx_queue_id / cdev->num_hwfns,
				      params->eq_completion_only, false);
	if (rc) {
		DP_ERR(cdev, "Failed to stop RXQ#%d\n", params->rx_queue_id);
		return rc;
	}

	return 0;
}

static int qed_start_txq(struct qed_dev *cdev,
			 u8 rss_num,
			 struct qed_queue_start_common_params *p_params,
			 dma_addr_t pbl_addr,
			 u16 pbl_size, void __iomem ** pp_doorbell)
{
	struct qed_hwfn *p_hwfn;
	int rc, hwfn_index;

	hwfn_index = rss_num % cdev->num_hwfns;
	p_hwfn = &cdev->hwfns[hwfn_index];
	p_params->queue_id = p_params->queue_id / cdev->num_hwfns;
	p_params->qzone_id = p_params->queue_id;
	p_params->stats_id = p_params->vport_id;

	rc = qed_sp_eth_tx_queue_start(p_hwfn,
				       p_hwfn->hw_info.opaque_fid,
				       p_params, 0 /* tc */ ,
				       pbl_addr, pbl_size, pp_doorbell);

	if (rc) {
		DP_ERR(cdev, "Failed to start TXQ#%d\n", p_params->queue_id);
		return rc;
	}

	DP_VERBOSE(cdev, (QED_MSG_SPQ | NETIF_MSG_IFUP),
		   "Started TX-Q %d [rss_num %d] on V-PORT %d and SB %d\n",
		   p_params->queue_id, rss_num, p_params->vport_id,
		   p_params->sb);

	return 0;
}

#define QED_HW_STOP_RETRY_LIMIT (10)
static int qed_fastpath_stop(struct qed_dev *cdev)
{
	qed_hw_stop_fastpath(cdev);

	return 0;
}

static int qed_stop_txq(struct qed_dev *cdev,
			struct qed_stop_txq_params *params)
{
	struct qed_hwfn *p_hwfn;
	int rc, hwfn_index;

	hwfn_index = params->rss_id % cdev->num_hwfns;
	p_hwfn = &cdev->hwfns[hwfn_index];

	rc = qed_sp_eth_tx_queue_stop(p_hwfn,
				      params->tx_queue_id / cdev->num_hwfns);
	if (rc) {
		DP_ERR(cdev, "Failed to stop TXQ#%d\n", params->tx_queue_id);
		return rc;
	}

	return 0;
}

static int qed_tunn_configure(struct qed_dev *cdev,
			      struct qed_tunn_params *tunn_params)
{
	struct qed_tunn_update_params tunn_info;
	int i, rc;

	if (IS_VF(cdev))
		return 0;

	memset(&tunn_info, 0, sizeof(tunn_info));
	if (tunn_params->update_vxlan_port == 1) {
		tunn_info.update_vxlan_udp_port = 1;
		tunn_info.vxlan_udp_port = tunn_params->vxlan_port;
	}

	if (tunn_params->update_geneve_port == 1) {
		tunn_info.update_geneve_udp_port = 1;
		tunn_info.geneve_udp_port = tunn_params->geneve_port;
	}

	for_each_hwfn(cdev, i) {
		struct qed_hwfn *hwfn = &cdev->hwfns[i];

		rc = qed_sp_pf_update_tunn_cfg(hwfn, &tunn_info,
					       QED_SPQ_MODE_EBLOCK, NULL);
		if (rc)
			return rc;
	}
	return 0;
}

static int qed_configure_filter_rx_mode(struct qed_dev *cdev,
					enum qed_filter_rx_mode_type type)
{
	struct qed_filter_accept_flags accept_flags;

	memset(&accept_flags, 0, sizeof(accept_flags));

	accept_flags.update_rx_mode_config = 1;
	accept_flags.update_tx_mode_config = 1;
	accept_flags.rx_accept_filter = QED_ACCEPT_UCAST_MATCHED |
	    QED_ACCEPT_MCAST_MATCHED | QED_ACCEPT_BCAST;
	accept_flags.tx_accept_filter = QED_ACCEPT_UCAST_MATCHED |
	    QED_ACCEPT_MCAST_MATCHED | QED_ACCEPT_BCAST;

	if (type == QED_FILTER_RX_MODE_TYPE_PROMISC)
		accept_flags.rx_accept_filter |= QED_ACCEPT_UCAST_UNMATCHED |
		    QED_ACCEPT_MCAST_UNMATCHED;
	else if (type == QED_FILTER_RX_MODE_TYPE_MULTI_PROMISC)
		accept_flags.rx_accept_filter |= QED_ACCEPT_MCAST_UNMATCHED;

	return qed_filter_accept_cmd(cdev, 0, accept_flags, false, false,
				     QED_SPQ_MODE_CB, NULL);
}

static int qed_configure_filter_ucast(struct qed_dev *cdev,
				      struct qed_filter_ucast_params *params)
{
	struct qed_filter_ucast ucast;

	if (!params->vlan_valid && !params->mac_valid) {
		DP_NOTICE(cdev,
			  "Tried configuring a unicast filter, but both MAC and VLAN are not set\n");
		return -EINVAL;
	}

	memset(&ucast, 0, sizeof(ucast));
	switch (params->type) {
	case QED_FILTER_XCAST_TYPE_ADD:
		ucast.opcode = QED_FILTER_ADD;
		break;
	case QED_FILTER_XCAST_TYPE_DEL:
		ucast.opcode = QED_FILTER_REMOVE;
		break;
	case QED_FILTER_XCAST_TYPE_REPLACE:
		ucast.opcode = QED_FILTER_REPLACE;
		break;
	default:
		DP_NOTICE(cdev, "Unknown unicast filter type %d\n",
			  params->type);
	}

	if (params->vlan_valid && params->mac_valid) {
		ucast.type = QED_FILTER_MAC_VLAN;
		ether_addr_copy(ucast.mac, params->mac);
		ucast.vlan = params->vlan;
	} else if (params->mac_valid) {
		ucast.type = QED_FILTER_MAC;
		ether_addr_copy(ucast.mac, params->mac);
	} else {
		ucast.type = QED_FILTER_VLAN;
		ucast.vlan = params->vlan;
	}

	ucast.is_rx_filter = true;
	ucast.is_tx_filter = true;

	return qed_filter_ucast_cmd(cdev, &ucast, QED_SPQ_MODE_CB, NULL);
}

static int qed_configure_filter_mcast(struct qed_dev *cdev,
				      struct qed_filter_mcast_params *params)
{
	struct qed_filter_mcast mcast;
	int i;

	memset(&mcast, 0, sizeof(mcast));
	switch (params->type) {
	case QED_FILTER_XCAST_TYPE_ADD:
		mcast.opcode = QED_FILTER_ADD;
		break;
	case QED_FILTER_XCAST_TYPE_DEL:
		mcast.opcode = QED_FILTER_REMOVE;
		break;
	default:
		DP_NOTICE(cdev, "Unknown multicast filter type %d\n",
			  params->type);
	}

	mcast.num_mc_addrs = params->num;
	for (i = 0; i < mcast.num_mc_addrs; i++)
		ether_addr_copy(mcast.mac[i], params->mac[i]);

	return qed_filter_mcast_cmd(cdev, &mcast, QED_SPQ_MODE_CB, NULL);
}

static int qed_configure_filter(struct qed_dev *cdev,
				struct qed_filter_params *params)
{
	enum qed_filter_rx_mode_type accept_flags;

	switch (params->type) {
	case QED_FILTER_TYPE_UCAST:
		return qed_configure_filter_ucast(cdev, &params->filter.ucast);
	case QED_FILTER_TYPE_MCAST:
		return qed_configure_filter_mcast(cdev, &params->filter.mcast);
	case QED_FILTER_TYPE_RX_MODE:
		accept_flags = params->filter.accept_flags;
		return qed_configure_filter_rx_mode(cdev, accept_flags);
	default:
		DP_NOTICE(cdev, "Unknown filter type %d\n", (int)params->type);
		return -EINVAL;
	}
}

static int qed_fp_cqe_completion(struct qed_dev *dev,
				 u8 rss_id, struct eth_slow_path_rx_cqe *cqe)
{
	return qed_eth_cqe_completion(&dev->hwfns[rss_id % dev->num_hwfns],
				      cqe);
}

void qed_dcbx_aen(struct qed_hwfn *hwfn, u32 mib_type)
{
	struct qed_common_cb_ops *op = hwfn->cdev->protocol_ops.common;
	void *cookie = hwfn->cdev->ops_cookie;

	if (cookie && op->dcbx_aen)
		op->dcbx_aen(cookie, &hwfn->p_dcbx_info->get, mib_type);
}

static int qed_ptp_hw_enable_pkt2host(struct qed_dev *cdev)
{
	return qed_ptp_enable_pkt2host(&cdev->hwfns[0]);
}

static int qed_ptp_hw_hwtstamp_tx_on(struct qed_dev *cdev)
{
	return qed_ptp_hwtstamp_tx_on(&cdev->hwfns[0]);
}

static int qed_ptp_hw_cfg_rx_filters(struct qed_dev *cdev,
				     u32 rule_mask, u32 param_mask)
{
	return qed_ptp_cfg_rx_filters(&cdev->hwfns[0], rule_mask, param_mask);
}

static u64 qed_ptp_hw_read_rx_ts(struct qed_dev *cdev, int *valid)
{
	return qed_ptp_read_rx_ts(&cdev->hwfns[0], valid);
}

static u64 qed_ptp_hw_read_tx_ts(struct qed_dev *cdev, int *valid)
{
	return qed_ptp_read_tx_ts(&cdev->hwfns[0], valid);
}

static u64 qed_ptp_hw_read_cc(struct qed_dev *cdev, int *valid)
{
	return qed_ptp_read_cc(&cdev->hwfns[0], valid);
}

static int qed_ptp_hw_disable(struct qed_dev *cdev)
{
	return qed_ptp_disable(&cdev->hwfns[0]);
}

static int qed_ptp_hw_adjfreq(struct qed_dev *cdev, u32 cfg)
{
	return qed_ptp_adjfreq(&cdev->hwfns[0], cfg);
}

static int qed_ptp_hw_enable(struct qed_dev *cdev)
{
	return qed_ptp_enable(&cdev->hwfns[0]);
}

static const struct qed_eth_ptp_ops qed_ptp_ops_pass = {
	INIT_STRUCT_FIELD(enable_pkt2host, qed_ptp_hw_enable_pkt2host),
	INIT_STRUCT_FIELD(hwtstamp_tx_on, qed_ptp_hw_hwtstamp_tx_on),
	INIT_STRUCT_FIELD(cfg_rx_filters, qed_ptp_hw_cfg_rx_filters),
	INIT_STRUCT_FIELD(read_rx_ts, qed_ptp_hw_read_rx_ts),
	INIT_STRUCT_FIELD(read_tx_ts, qed_ptp_hw_read_tx_ts),
	INIT_STRUCT_FIELD(read_cc, qed_ptp_hw_read_cc),
	INIT_STRUCT_FIELD(adjfreq, qed_ptp_hw_adjfreq),
	INIT_STRUCT_FIELD(disable, qed_ptp_hw_disable),
	INIT_STRUCT_FIELD(enable, qed_ptp_hw_enable),
};

static u8 qed_dcbnl_getstate(struct qed_dev *cdev)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	bool enabled;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return 0;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return 0;
	}

	enabled = dcbx_info->operational.enabled;
	DP_VERBOSE(hwfn, QED_MSG_DCB, "DCB state = %d\n", enabled);
	kfree(dcbx_info);

	return enabled;
}

static u8 qed_dcbnl_setstate(struct qed_dev *cdev, u8 state)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "DCB state = %d\n", state);

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return 1;

	dcbx_set.enabled = state ? true : false;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return 1;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc ? 1 : 0;
}

static void qed_dcbnl_getpgtccfgtx(struct qed_dev *cdev,
				   int tc,
				   u8 * prio_type,
				   u8 * pgid, u8 * bw_pct, u8 * up_map)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "tc = %d\n", tc);
	*prio_type = *pgid = *bw_pct = *up_map = 0;
	if (tc < 0 || tc >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid tc %d\n", tc);
		return;
	}

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return;
	}
	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		return;
	}

	*pgid = dcbx_info->operational.params.ets_pri_tc_tbl[tc];
	/* TODO: prio_type, bw_pct, up_map are not supported? */
	kfree(dcbx_info);
}

static void qed_dcbnl_getpgbwgcfgtx(struct qed_dev *cdev, int pgid, u8 * bw_pct)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	*bw_pct = 0;
	DP_VERBOSE(hwfn, QED_MSG_DCB, "pgid = %d\n", pgid);
	if (pgid < 0 || pgid >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid pgid %d\n", pgid);
		return;
	}
	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return;
	}

	*bw_pct = dcbx_info->operational.params.ets_tc_bw_tbl[pgid];
	DP_VERBOSE(hwfn, QED_MSG_DCB, "bw_pct = %d\n", *bw_pct);
	kfree(dcbx_info);
}

static void qed_dcbnl_getpgtccfgrx(struct qed_dev *cdev,
				   int tc,
				   u8 * prio,
				   u8 * bwg_id, u8 * bw_pct, u8 * up_map)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);

	DP_INFO(hwfn, "Rx ETS is not supportted\n");
	*prio = *bwg_id = *bw_pct = *up_map = 0;
}

static void qed_dcbnl_getpgbwgcfgrx(struct qed_dev *cdev,
				    int bwg_id, u8 * bw_pct)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);

	DP_INFO(hwfn, "Rx ETS is not supportted\n");
	*bw_pct = 0;
}

static void qed_dcbnl_getpfccfg(struct qed_dev *cdev,
				int priority, u8 * setting)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "priority = %d\n", priority);
	if (priority < 0 || priority >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid priority %d\n", priority);
		return;
	}
	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return;
	}

	*setting = dcbx_info->operational.params.pfc.prio[priority];
	DP_VERBOSE(hwfn, QED_MSG_DCB, "setting = %d\n", *setting);
	kfree(dcbx_info);
}

static void qed_dcbnl_setpfccfg(struct qed_dev *cdev, int priority, u8 setting)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "priority = %d setting = %d\n",
		   priority, setting);
	if (priority < 0 || priority >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid priority %d\n", priority);
		return;
	}

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_PFC_CFG;
	if (setting)
		dcbx_set.config.params.pfc.prio[priority] = true;
	else
		dcbx_set.config.params.pfc.prio[priority] = false;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);
}

static u8 qed_dcbnl_getcap(struct qed_dev *cdev, int capid, u8 * cap)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc = 0;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "capid = %d\n", capid);
	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return 0;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return 1;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return 1;
	}

	switch (capid) {
	case DCB_CAP_ATTR_PG:
	case DCB_CAP_ATTR_PFC:
	case DCB_CAP_ATTR_UP2TC:
	case DCB_CAP_ATTR_GSP:
		*cap = true;
		break;
	case DCB_CAP_ATTR_PG_TCS:
	case DCB_CAP_ATTR_PFC_TCS:
		*cap = 0x80;
		break;
	case DCB_CAP_ATTR_DCBX:
		*cap = QED_DCBX_CAPS;
		break;
	default:
		*cap = false;
		rc = 1;
	}
	DP_VERBOSE(hwfn, QED_MSG_DCB, "id = %d caps = %d\n", capid, *cap);
	kfree(dcbx_info);

	return rc;
}

static int qed_dcbnl_getnumtcs(struct qed_dev *cdev, int tcid, u8 * num)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "tcid = %d\n", tcid);
	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return -EINVAL;
	}

	switch (tcid) {
	case DCB_NUMTCS_ATTR_PG:
		*num = dcbx_info->operational.params.max_ets_tc;
		break;
	case DCB_NUMTCS_ATTR_PFC:
		*num = dcbx_info->operational.params.pfc.max_tc;
		break;
	default:
		kfree(dcbx_info);
		return -EINVAL;
	}

	kfree(dcbx_info);
	DP_VERBOSE(hwfn, QED_MSG_DCB, "numtcs = %d\n", *num);

	return 0;
}

static u8 qed_dcbnl_getpfcstate(struct qed_dev *cdev)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	bool enabled;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return 0;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return 0;
	}

	DP_VERBOSE(hwfn, QED_MSG_DCB, "pfc state = %d\n",
		   dcbx_info->operational.params.pfc.enabled);
	enabled = dcbx_info->operational.params.pfc.enabled;
	kfree(dcbx_info);

	return enabled;
}

static u8 qed_dcbnl_getdcbx(struct qed_dev *cdev)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	u8 mode = 0;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return 0;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return 0;
	}

	if (dcbx_info->operational.enabled)
		mode |= DCB_CAP_DCBX_LLD_MANAGED;
	if (dcbx_info->operational.ieee)
		mode |= DCB_CAP_DCBX_VER_IEEE;
	if (dcbx_info->operational.cee)
		mode |= DCB_CAP_DCBX_VER_CEE;
	if (dcbx_info->operational.local)
		mode |= DCB_CAP_DCBX_STATIC;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "dcb mode = %d\n", mode);
	kfree(dcbx_info);

	return mode;
}

static void qed_dcbnl_setpgtccfgtx(struct qed_dev *cdev,
				   int tc,
				   u8 pri_type, u8 pgid, u8 bw_pct, u8 up_map)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB,
		   "tc = %d pri_type = %d pgid = %d bw_pct = %d up_map = %d\n",
		   tc, pri_type, pgid, bw_pct, up_map);

	if (tc < 0 || tc >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid tc %d\n", tc);
		return;
	}
	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_ETS_CFG;
	dcbx_set.config.params.ets_pri_tc_tbl[tc] = pgid;
	/* TODO: pri_type, bw_pct, up_map are not supported? */

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);
}

static void qed_dcbnl_setpgtccfgrx(struct qed_dev *cdev,
				   int prio,
				   u8 pri_type, u8 pgid, u8 bw_pct, u8 up_map)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);

	DP_INFO(hwfn, "Rx ETS is not supportted\n");
}

static void qed_dcbnl_setpgbwgcfgtx(struct qed_dev *cdev, int pgid, u8 bw_pct)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "pgid = %d bw_pct = %d\n", pgid, bw_pct);
	if (pgid < 0 || pgid >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid pgid %d\n", pgid);
		return;
	}

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_ETS_CFG;
	dcbx_set.config.params.ets_tc_bw_tbl[pgid] = bw_pct;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);
}

static void qed_dcbnl_setpgbwgcfgrx(struct qed_dev *cdev, int pgid, u8 bw_pct)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);

	DP_INFO(hwfn, "Rx ETS is not supportted\n");
}

static u8 qed_dcbnl_setall(struct qed_dev *cdev)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return 1;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return 1;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 1);

	qed_ptt_release(hwfn, ptt);

	return rc;
}

static int qed_dcbnl_setnumtcs(struct qed_dev *cdev, int tcid, u8 num)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "tcid = %d num = %d\n", tcid, num);
	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return 1;

	switch (tcid) {
	case DCB_NUMTCS_ATTR_PG:
		dcbx_set.override_flags |= QED_DCBX_OVERRIDE_ETS_CFG;
		dcbx_set.config.params.max_ets_tc = num;
		break;
	case DCB_NUMTCS_ATTR_PFC:
		dcbx_set.override_flags |= QED_DCBX_OVERRIDE_PFC_CFG;
		dcbx_set.config.params.pfc.max_tc = num;
		break;
	default:
		DP_INFO(hwfn, "Invalid tcid %d\n", tcid);
		return -EINVAL;
	}

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return -EINVAL;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return 0;
}

static void qed_dcbnl_setpfcstate(struct qed_dev *cdev, u8 state)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "new state = %d\n", state);

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_PFC_CFG;
	dcbx_set.config.params.pfc.enabled = state ? true : false;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return;
}

static int qed_dcbnl_getapp(struct qed_dev *cdev, u8 idtype, u16 idval)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_app_entry *entry;
	bool ethtype;
	int rc, i;
	u8 prio = 0;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	ethtype = (idtype == DCB_APP_IDTYPE_ETHTYPE) ? true : false;
	for (i = 0; i < QED_DCBX_MAX_APP_PROTOCOL; i++) {
		entry = &dcbx_info->operational.params.app_entry[i];
		if ((entry->ethtype == ethtype) && (entry->proto_id == idval)) {
			prio = entry->prio;
			break;
		}
	}
	if (i == QED_DCBX_MAX_APP_PROTOCOL) {
		DP_ERR(cdev, "App entry (%d, %d) not found\n", idtype, idval);
		kfree(dcbx_info);
		return -EINVAL;
	}

	kfree(dcbx_info);

	return prio;
}

static int qed_dcbnl_setapp(struct qed_dev *cdev,
			    u8 idtype, u16 idval, u8 pri_map)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_app_entry *entry;
	bool ethtype;
	struct qed_ptt *ptt;
	int rc, i;

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return -EINVAL;

	ethtype = (idtype == DCB_APP_IDTYPE_ETHTYPE) ? true : false;
	for (i = 0; i < QED_DCBX_MAX_APP_PROTOCOL; i++) {
		entry = &dcbx_set.config.params.app_entry[i];
		if ((entry->ethtype == ethtype) && (entry->proto_id == idval))
			break;
		/* First empty slot */
		if (!entry->proto_id)
			break;
	}
	if (i == QED_DCBX_MAX_APP_PROTOCOL) {
		DP_ERR(cdev, "App table is full\n");
		return -EBUSY;
	}

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_APP_CFG;
	dcbx_set.config.params.app_entry[i].ethtype = ethtype;
	dcbx_set.config.params.app_entry[i].proto_id = idval;
	dcbx_set.config.params.app_entry[i].prio = pri_map;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return -EBUSY;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc;
}

static u8 qed_dcbnl_setdcbx(struct qed_dev *cdev, u8 mode)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "new mode = %x\n", mode);

	if (!(mode & DCB_CAP_DCBX_VER_IEEE) &&
	    !(mode & DCB_CAP_DCBX_VER_CEE) && !(mode & DCB_CAP_DCBX_STATIC)) {
		DP_INFO(hwfn, "Allowed modes are cee, ieee or static\n");
		return 1;
	}

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return 1;

	dcbx_set.ver_num = 0;
	if (mode & DCB_CAP_DCBX_VER_CEE) {
		dcbx_set.ver_num |= DCBX_CONFIG_VERSION_CEE;
		dcbx_set.enabled = true;
	}

	if (mode & DCB_CAP_DCBX_VER_IEEE) {
		dcbx_set.ver_num |= DCBX_CONFIG_VERSION_IEEE;
		dcbx_set.enabled = true;
	}

	if (mode & DCB_CAP_DCBX_STATIC) {
		dcbx_set.ver_num |= DCBX_CONFIG_VERSION_STATIC;
		dcbx_set.enabled = true;
	}

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return 1;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc;
}

static u8 qed_dcbnl_getfeatcfg(struct qed_dev *cdev, int featid, u8 * flags)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "Feature id  = %d\n", featid);
	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return 1;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return 1;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return 1;
	}

	*flags = 0;
	switch (featid) {
	case DCB_FEATCFG_ATTR_PG:
		if (dcbx_info->operational.params.ets_enabled)
			*flags = DCB_FEATCFG_ENABLE;
		else
			*flags = DCB_FEATCFG_ERROR;
		break;
	case DCB_FEATCFG_ATTR_PFC:
		if (dcbx_info->operational.params.pfc.enabled)
			*flags = DCB_FEATCFG_ENABLE;
		else
			*flags = DCB_FEATCFG_ERROR;
		break;
	case DCB_FEATCFG_ATTR_APP:
		if (dcbx_info->operational.params.app_valid)
			*flags = DCB_FEATCFG_ENABLE;
		else
			*flags = DCB_FEATCFG_ERROR;
		break;
	default:
		DP_INFO(hwfn, "Invalid feature-ID %d\n", featid);
		kfree(dcbx_info);
		return 1;
	}

	DP_VERBOSE(hwfn, QED_MSG_DCB, "flags = %d\n", *flags);
	kfree(dcbx_info);

	return 0;
}

static u8 qed_dcbnl_setfeatcfg(struct qed_dev *cdev, int featid, u8 flags)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_set dcbx_set;
	bool enabled, willing;
	struct qed_ptt *ptt;
	int rc;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "featid = %d flags = %d\n",
		   featid, flags);
	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return 1;

	enabled = flags & DCB_FEATCFG_ENABLE ? true : false;
	willing = flags & DCB_FEATCFG_WILLING ? true : false;
	switch (featid) {
	case DCB_FEATCFG_ATTR_PG:
		dcbx_set.override_flags |= QED_DCBX_OVERRIDE_ETS_CFG;
		dcbx_set.config.params.ets_enabled = enabled;
		dcbx_set.config.params.ets_willing = willing;
		break;
	case DCB_FEATCFG_ATTR_PFC:
		dcbx_set.override_flags |= QED_DCBX_OVERRIDE_PFC_CFG;
		dcbx_set.config.params.pfc.enabled = enabled;
		dcbx_set.config.params.pfc.willing = willing;
		break;
	case DCB_FEATCFG_ATTR_APP:
		dcbx_set.override_flags |= QED_DCBX_OVERRIDE_APP_CFG;
		/* TODO: ignore enable, always enabled? */
		dcbx_set.config.params.app_willing = willing;
		break;
	default:
		DP_INFO(hwfn, "Invalid feature-ID %d\n", featid);
		return 1;
	}

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return 1;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return 0;
}

#ifdef DCB_CEE_SUPPORT		/* QED_UPSTREAM */
static int qed_dcbnl_peer_getappinfo(struct qed_dev *cdev,
				     struct dcb_peer_app_info *info,
				     u16 * app_count)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_REMOTE_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	info->willing = dcbx_info->remote.params.app_willing;
	info->error = dcbx_info->remote.params.app_error;
	*app_count = dcbx_info->remote.params.num_app_entries;
	kfree(dcbx_info);

	return 0;
}

static int qed_dcbnl_peer_getapptable(struct qed_dev *cdev,
				      struct dcb_app *table)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc, i;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_REMOTE_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	for (i = 0; i < dcbx_info->remote.params.num_app_entries; i++) {
		if (dcbx_info->remote.params.app_entry[i].ethtype)
			table[i].selector = DCB_APP_IDTYPE_ETHTYPE;
		else
			table[i].selector = DCB_APP_IDTYPE_PORTNUM;
		table[i].priority = dcbx_info->remote.params.app_entry[i].prio;
		table[i].protocol =
		    dcbx_info->remote.params.app_entry[i].proto_id;
	}
	kfree(dcbx_info);

	return 0;
}

static int qed_dcbnl_cee_peer_getpfc(struct qed_dev *cdev, struct cee_pfc *pfc)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc, i;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return -EINVAL;
	}

	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_REMOTE_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	for (i = 0; i < QED_MAX_PFC_PRIORITIES; i++)
		if (dcbx_info->remote.params.pfc.prio[i])
			pfc->pfc_en |= (0x1 << i);
	pfc->tcs_supported = dcbx_info->remote.params.pfc.max_tc;
	DP_VERBOSE(hwfn, QED_MSG_DCB, "pfc state = %d tcs_supported = %d\n",
		   pfc->pfc_en, pfc->tcs_supported);
	kfree(dcbx_info);

	return 0;
}

static int qed_dcbnl_cee_peer_getpg(struct qed_dev *cdev, struct cee_pg *pg)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	int rc, i;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (!dcbx_info->operational.enabled) {
		DP_INFO(hwfn, "DCBX is not enabled/operational\n");
		kfree(dcbx_info);
		return -EINVAL;
	}

	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_REMOTE_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	pg->willing = dcbx_info->remote.params.ets_willing;
	for (i = 0; i < QED_MAX_PFC_PRIORITIES; i++) {
		pg->pg_bw[i] = dcbx_info->remote.params.ets_tc_bw_tbl[i];
		pg->prio_pg[i] = dcbx_info->remote.params.ets_pri_tc_tbl[i];
	}

	DP_VERBOSE(hwfn, QED_MSG_DCB, "willing = %d", pg->willing);
	kfree(dcbx_info);

	return 0;
}
#endif

static int qed_dcbnl_get_ieee_pfc(struct qed_dev *cdev,
				  struct ieee_pfc *pfc, bool remote)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_params *params;
	struct qed_dcbx_get *dcbx_info;
	int rc, i;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		return -EINVAL;
	}

	if (remote) {
		memset(dcbx_info, 0, sizeof(struct qed_dcbx_get));
		rc = qed_dcbx_query_params(hwfn, dcbx_info,
					   QED_DCBX_REMOTE_MIB);
		if (rc) {
			kfree(dcbx_info);
			return -EINVAL;
		}
		params = &dcbx_info->remote.params;
	} else {
		params = &dcbx_info->operational.params;
	}

	pfc->pfc_cap = params->pfc.max_tc;
	pfc->pfc_en = 0;
	for (i = 0; i < QED_MAX_PFC_PRIORITIES; i++)
		if (params->pfc.prio[i])
			pfc->pfc_en |= (0x1 << i);

	kfree(dcbx_info);

	return 0;
}

static int qed_dcbnl_ieee_getpfc(struct qed_dev *cdev, struct ieee_pfc *pfc)
{
	return qed_dcbnl_get_ieee_pfc(cdev, pfc, false);
}

static int qed_dcbnl_ieee_setpfc(struct qed_dev *cdev, struct ieee_pfc *pfc)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc, i;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		kfree(dcbx_info);
		return -EINVAL;
	}
	kfree(dcbx_info);

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return -EINVAL;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_PFC_CFG;
	for (i = 0; i < QED_MAX_PFC_PRIORITIES; i++) {
		if (pfc->pfc_en & BIT(i))
			dcbx_set.config.params.pfc.prio[i] = true;
		else
			dcbx_set.config.params.pfc.prio[i] = false;
	}

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return -EINVAL;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc;
}

static int qed_dcbnl_get_ieee_ets(struct qed_dev *cdev,
				  struct ieee_ets *ets, bool remote)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_dcbx_params *params;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}
	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		kfree(dcbx_info);
		return -EINVAL;
	}

	if (remote) {
		memset(dcbx_info, 0, sizeof(struct qed_dcbx_get));
		rc = qed_dcbx_query_params(hwfn, dcbx_info,
					   QED_DCBX_REMOTE_MIB);
		if (rc) {
			kfree(dcbx_info);
			return -EINVAL;
		}
		params = &dcbx_info->remote.params;
	} else {
		params = &dcbx_info->operational.params;
	}

	ets->ets_cap = params->max_ets_tc;
	ets->willing = params->ets_willing;
	ets->cbs = params->ets_cbs;
	memcpy(ets->tc_tx_bw, params->ets_tc_bw_tbl, sizeof(ets->tc_tx_bw));
	memcpy(ets->tc_tsa, params->ets_tc_tsa_tbl, sizeof(ets->tc_tsa));
	memcpy(ets->prio_tc, params->ets_pri_tc_tbl, sizeof(ets->prio_tc));
	kfree(dcbx_info);

	return 0;
}

static int qed_dcbnl_ieee_getets(struct qed_dev *cdev, struct ieee_ets *ets)
{
	return qed_dcbnl_get_ieee_ets(cdev, ets, false);
}

static int qed_dcbnl_ieee_setets(struct qed_dev *cdev, struct ieee_ets *ets)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_dcbx_set dcbx_set;
	struct qed_ptt *ptt;
	int rc;

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}
	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		kfree(dcbx_info);
		return -EINVAL;
	}
	kfree(dcbx_info);

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return -EINVAL;

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_ETS_CFG;
	dcbx_set.config.params.max_ets_tc = ets->ets_cap;
	dcbx_set.config.params.ets_willing = ets->willing;
	dcbx_set.config.params.ets_cbs = ets->cbs;
	memcpy(dcbx_set.config.params.ets_tc_bw_tbl, ets->tc_tx_bw,
	       sizeof(ets->tc_tx_bw));
	memcpy(dcbx_set.config.params.ets_tc_tsa_tbl, ets->tc_tsa,
	       sizeof(ets->tc_tsa));
	memcpy(dcbx_set.config.params.ets_pri_tc_tbl, ets->prio_tc,
	       sizeof(ets->prio_tc));

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return -EINVAL;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc;
}

int qed_dcbnl_ieee_peer_getets(struct qed_dev *cdev, struct ieee_ets *ets)
{
	return qed_dcbnl_get_ieee_ets(cdev, ets, true);
}

int qed_dcbnl_ieee_peer_getpfc(struct qed_dev *cdev, struct ieee_pfc *pfc)
{
	return qed_dcbnl_get_ieee_pfc(cdev, pfc, true);
}

#ifdef _IEEE_8021QAZ_APP	/* QED_UPSTREAM */
int qed_dcbnl_ieee_getapp(struct qed_dev *cdev, struct dcb_app *app)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_app_entry *entry;
	u8 prio = 0;
	u8 sf_ieee;
	int rc, i;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "selector = %d protocol = %d\n",
		   app->selector, app->protocol);
	switch (app->selector) {
	case IEEE_8021QAZ_APP_SEL_ETHERTYPE:
		sf_ieee = QED_DCBX_SF_IEEE_ETHTYPE;
		break;
	case IEEE_8021QAZ_APP_SEL_STREAM:
		sf_ieee = QED_DCBX_SF_IEEE_TCP_PORT;
		break;
	case IEEE_8021QAZ_APP_SEL_DGRAM:
		sf_ieee = QED_DCBX_SF_IEEE_UDP_PORT;
		break;
	case IEEE_8021QAZ_APP_SEL_ANY:
		sf_ieee = QED_DCBX_SF_IEEE_TCP_UDP_PORT;
		break;
	default:
		DP_INFO(cdev, "Invalid selector field value %d\n",
			app->selector);
		return -EINVAL;
	}

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}
	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		kfree(dcbx_info);
		return -EINVAL;
	}

	for (i = 0; i < QED_DCBX_MAX_APP_PROTOCOL; i++) {
		entry = &dcbx_info->operational.params.app_entry[i];
		if ((entry->sf_ieee == sf_ieee) &&
		    (entry->proto_id == app->protocol)) {
			prio = entry->prio;
			break;
		}
	}
	if (i == QED_DCBX_MAX_APP_PROTOCOL) {
		DP_ERR(cdev, "App entry (%d, %d) not found\n", app->selector,
		       app->protocol);
		kfree(dcbx_info);
		return -EINVAL;
	}

	app->priority = ffs(prio) - 1;

	kfree(dcbx_info);

	return 0;
}

int qed_dcbnl_ieee_setapp(struct qed_dev *cdev, struct dcb_app *app)
{
	struct qed_hwfn *hwfn = QED_LEADING_HWFN(cdev);
	struct qed_dcbx_get *dcbx_info;
	struct qed_dcbx_set dcbx_set;
	struct qed_app_entry *entry;
	struct qed_ptt *ptt;
	u8 sf_ieee;
	int rc, i;

	DP_VERBOSE(hwfn, QED_MSG_DCB, "selector = %d protocol = %d pri = %d\n",
		   app->selector, app->protocol, app->priority);
	if (app->priority >= QED_MAX_PFC_PRIORITIES) {
		DP_INFO(hwfn, "Invalid priority %d\n", app->priority);
		return -EINVAL;
	}

	switch (app->selector) {
	case IEEE_8021QAZ_APP_SEL_ETHERTYPE:
		sf_ieee = QED_DCBX_SF_IEEE_ETHTYPE;
		break;
	case IEEE_8021QAZ_APP_SEL_STREAM:
		sf_ieee = QED_DCBX_SF_IEEE_TCP_PORT;
		break;
	case IEEE_8021QAZ_APP_SEL_DGRAM:
		sf_ieee = QED_DCBX_SF_IEEE_UDP_PORT;
		break;
	case IEEE_8021QAZ_APP_SEL_ANY:
		sf_ieee = QED_DCBX_SF_IEEE_TCP_UDP_PORT;
		break;
	default:
		DP_INFO(cdev, "Invalid selector field value %d\n",
			app->selector);
		return -EINVAL;
	}

	dcbx_info = kmalloc(sizeof(*dcbx_info), GFP_KERNEL);
	if (!dcbx_info) {
		DP_ERR(cdev, "Failed to allocate memory for dcbx_info\n");
		return -ENOMEM;
	}
	rc = qed_dcbx_query_params(hwfn, dcbx_info, QED_DCBX_OPERATIONAL_MIB);
	if (rc) {
		kfree(dcbx_info);
		return -EINVAL;
	}
	if (!dcbx_info->operational.enabled || !dcbx_info->operational.ieee) {
		DP_INFO(hwfn, "DCBX is not enabled/operational in IEEE mode\n");
		kfree(dcbx_info);
		return -EINVAL;
	}
	kfree(dcbx_info);

	memset(&dcbx_set, 0, sizeof(struct qed_dcbx_set));
	rc = qed_dcbx_get_config_params(hwfn, &dcbx_set);
	if (rc)
		return -EINVAL;

	for (i = 0; i < QED_DCBX_MAX_APP_PROTOCOL; i++) {
		entry = &dcbx_set.config.params.app_entry[i];
		if ((entry->sf_ieee == sf_ieee) &&
		    (entry->proto_id == app->protocol))
			break;
		/* First empty slot */
		if (!entry->proto_id)
			break;
	}
	if (i == QED_DCBX_MAX_APP_PROTOCOL) {
		DP_ERR(cdev, "App table is full\n");
		return -EBUSY;
	}

	dcbx_set.override_flags |= QED_DCBX_OVERRIDE_APP_CFG;
	dcbx_set.config.params.app_entry[i].sf_ieee = sf_ieee;
	dcbx_set.config.params.app_entry[i].proto_id = app->protocol;
	dcbx_set.config.params.app_entry[i].prio = BIT(app->priority);
	dcbx_set.config.params.num_app_entries++;

	ptt = qed_ptt_acquire(hwfn);
	if (!ptt)
		return -EBUSY;

	rc = qed_dcbx_config_params(hwfn, ptt, &dcbx_set, 0);

	qed_ptt_release(hwfn, ptt);

	return rc;
}
#endif

static const struct qed_eth_dcbnl_ops qed_dcbnl_ops_pass = {
	INIT_STRUCT_FIELD(getstate, qed_dcbnl_getstate),
	INIT_STRUCT_FIELD(setstate, qed_dcbnl_setstate),
	INIT_STRUCT_FIELD(getpgtccfgtx, qed_dcbnl_getpgtccfgtx),
	INIT_STRUCT_FIELD(getpgbwgcfgtx, qed_dcbnl_getpgbwgcfgtx),
	INIT_STRUCT_FIELD(getpgtccfgrx, qed_dcbnl_getpgtccfgrx),
	INIT_STRUCT_FIELD(getpgbwgcfgrx, qed_dcbnl_getpgbwgcfgrx),
	INIT_STRUCT_FIELD(getpfccfg, qed_dcbnl_getpfccfg),
	INIT_STRUCT_FIELD(setpfccfg, qed_dcbnl_setpfccfg),
	INIT_STRUCT_FIELD(getcap, qed_dcbnl_getcap),
	INIT_STRUCT_FIELD(getnumtcs, qed_dcbnl_getnumtcs),
	INIT_STRUCT_FIELD(getpfcstate, qed_dcbnl_getpfcstate),
	INIT_STRUCT_FIELD(getdcbx, qed_dcbnl_getdcbx),
	INIT_STRUCT_FIELD(setpgtccfgtx, qed_dcbnl_setpgtccfgtx),
	INIT_STRUCT_FIELD(setpgtccfgrx, qed_dcbnl_setpgtccfgrx),
	INIT_STRUCT_FIELD(setpgbwgcfgtx, qed_dcbnl_setpgbwgcfgtx),
	INIT_STRUCT_FIELD(setpgbwgcfgrx, qed_dcbnl_setpgbwgcfgrx),
	INIT_STRUCT_FIELD(setall, qed_dcbnl_setall),
	INIT_STRUCT_FIELD(setnumtcs, qed_dcbnl_setnumtcs),
	INIT_STRUCT_FIELD(setpfcstate, qed_dcbnl_setpfcstate),
	INIT_STRUCT_FIELD(setapp, qed_dcbnl_setapp),
	INIT_STRUCT_FIELD(setdcbx, qed_dcbnl_setdcbx),
	INIT_STRUCT_FIELD(setfeatcfg, qed_dcbnl_setfeatcfg),
	INIT_STRUCT_FIELD(getfeatcfg, qed_dcbnl_getfeatcfg),
	INIT_STRUCT_FIELD(getapp, qed_dcbnl_getapp),
#ifdef DCB_CEE_SUPPORT		/* QED_UPSTREAM */
	INIT_STRUCT_FIELD(peer_getappinfo, qed_dcbnl_peer_getappinfo),
	INIT_STRUCT_FIELD(peer_getapptable, qed_dcbnl_peer_getapptable),
	INIT_STRUCT_FIELD(cee_peer_getpfc, qed_dcbnl_cee_peer_getpfc),
	INIT_STRUCT_FIELD(cee_peer_getpg, qed_dcbnl_cee_peer_getpg),
#endif
	INIT_STRUCT_FIELD(ieee_getpfc, qed_dcbnl_ieee_getpfc),
	INIT_STRUCT_FIELD(ieee_setpfc, qed_dcbnl_ieee_setpfc),
	INIT_STRUCT_FIELD(ieee_getets, qed_dcbnl_ieee_getets),
	INIT_STRUCT_FIELD(ieee_setets, qed_dcbnl_ieee_setets),
	INIT_STRUCT_FIELD(ieee_peer_getpfc, qed_dcbnl_ieee_peer_getpfc),
	INIT_STRUCT_FIELD(ieee_peer_getets, qed_dcbnl_ieee_peer_getets),
#ifdef _IEEE_8021QAZ_APP	/* QED_UPSTREAM */
	INIT_STRUCT_FIELD(ieee_getapp, qed_dcbnl_ieee_getapp),
	INIT_STRUCT_FIELD(ieee_setapp, qed_dcbnl_ieee_setapp),
#endif
};

static const struct qed_eth_ops qed_eth_ops_pass = {
	INIT_STRUCT_FIELD(common, &qed_common_ops_pass),
	INIT_STRUCT_FIELD(dcb, &qed_dcbnl_ops_pass),
	INIT_STRUCT_FIELD(ptp, &qed_ptp_ops_pass),
#ifdef CONFIG_QED_SRIOV
	INIT_STRUCT_FIELD(iov, &qed_iov_ops_pass),
#endif
	INIT_STRUCT_FIELD(fill_dev_info, &qed_fill_eth_dev_info),
	INIT_STRUCT_FIELD(register_ops, &qed_register_eth_ops),
	INIT_STRUCT_FIELD(check_mac, &qed_check_mac),
	INIT_STRUCT_FIELD(vport_start, &qed_start_vport),
	INIT_STRUCT_FIELD(vport_stop, &qed_stop_vport),
	INIT_STRUCT_FIELD(vport_update, &qed_update_vport),
	INIT_STRUCT_FIELD(q_rx_start, &qed_start_rxq),
	INIT_STRUCT_FIELD(q_rx_stop, &qed_stop_rxq),
	INIT_STRUCT_FIELD(q_tx_start, &qed_start_txq),
	INIT_STRUCT_FIELD(q_tx_stop, &qed_stop_txq),
	INIT_STRUCT_FIELD(filter_config, &qed_configure_filter),
	INIT_STRUCT_FIELD(fastpath_stop, &qed_fastpath_stop),
	INIT_STRUCT_FIELD(eth_cqe_completion, &qed_fp_cqe_completion),
	INIT_STRUCT_FIELD(get_vport_stats, &qed_get_vport_stats),
#ifdef CONFIG_QED_USER
	INIT_STRUCT_FIELD(get_phys_addr, &qed_get_phys_addr),
#endif
	INIT_STRUCT_FIELD(tunn_config, &qed_tunn_configure),
};

#ifdef QED_UPSTREAM
const struct qed_eth_ops *qed_get_eth_ops(void)
{
	return &qed_eth_ops_pass;
}
#else
const struct qed_eth_ops *qed_get_eth_ops(u32 version)
{
	if (version != QED_ETH_INTERFACE_VERSION) {
		pr_notice("Cannot supply ethtool operations [%08x != %08x]\n",
			  version, QED_ETH_INTERFACE_VERSION);
		return NULL;
	}
	return &qed_eth_ops_pass;
}
#endif

EXPORT_SYMBOL(qed_get_eth_ops);

void qed_put_eth_ops(void)
{
	/* TODO - reference count for module? */
}

EXPORT_SYMBOL(qed_put_eth_ops);
