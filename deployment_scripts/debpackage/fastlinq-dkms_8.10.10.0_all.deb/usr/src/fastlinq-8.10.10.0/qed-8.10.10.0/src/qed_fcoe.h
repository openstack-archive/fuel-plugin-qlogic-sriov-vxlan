#ifndef _QED_FCOE_H
#define _QED_FCOE_H
#include <linux/types.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include "qed.h"
#include "qed_chain.h"
#include "qed_hsi.h"
#include "qed_mcp.h"
#include "qed_sp.h"
#include "qed_fcoe_if.h"

struct qed_fcoe_conn {
	struct list_head list_entry;
	bool free_on_delete;

	u16 conn_id;
	u32 icid;
	u32 fw_cid;
	u8 layer_code;

	dma_addr_t sq_pbl_addr;
	dma_addr_t sq_curr_page_addr;
	dma_addr_t sq_next_page_addr;
	dma_addr_t xferq_pbl_addr;
	void *xferq_pbl_addr_virt_addr;
	dma_addr_t xferq_addr[4];
	void *xferq_addr_virt_addr[4];
	dma_addr_t confq_pbl_addr;
	void *confq_pbl_addr_virt_addr;
	dma_addr_t confq_addr[2];
	void *confq_addr_virt_addr[2];

	dma_addr_t terminate_params;

	u16 dst_mac_addr_lo;
	u16 dst_mac_addr_mid;
	u16 dst_mac_addr_hi;
	u16 src_mac_addr_lo;
	u16 src_mac_addr_mid;
	u16 src_mac_addr_hi;

	u16 tx_max_fc_pay_len;
	u16 e_d_tov_timer_val;
	u16 rec_tov_timer_val;
	u16 rx_max_fc_pay_len;
	u16 vlan_tag;
	u16 physical_q0;

	struct fc_addr_nw s_id;
	u8 max_conc_seqs_c3;
	struct fc_addr_nw d_id;
	u8 flags;
	u8 def_q_idx;
};

int
qed_fcoe_acquire_connection(struct qed_hwfn *p_hwfn,
			    struct qed_fcoe_conn *p_in_conn,
			    struct qed_fcoe_conn **p_out_conn);

void __iomem *qed_fcoe_get_db_addr(struct qed_hwfn *p_hwfn, u32 cid);

void __iomem *qed_fcoe_get_global_cmdq_cons(struct qed_hwfn *p_hwfn,
					    u8 relative_q_id);

void __iomem *qed_fcoe_get_primary_bdq_prod(struct qed_hwfn *p_hwfn, u8 bdq_id);

void __iomem *qed_fcoe_get_secondary_bdq_prod(struct qed_hwfn *p_hwfn,
					      u8 bdq_id);

int
qed_fcoe_offload_connection(struct qed_hwfn *p_hwfn,
			    struct qed_fcoe_conn *p_conn);

int
qed_fcoe_terminate_connection(struct qed_hwfn *p_hwfn,
			      struct qed_fcoe_conn *p_conn);

void qed_fcoe_release_connection(struct qed_hwfn *p_hwfn,
				 struct qed_fcoe_conn *p_conn);

int
qed_sp_fcoe_func_start(struct qed_hwfn *p_hwfn,
		       enum spq_mode comp_mode,
		       struct qed_spq_comp_cb *p_comp_addr);

int
qed_sp_fcoe_func_stop(struct qed_hwfn *p_hwfn,
		      enum spq_mode comp_mode,
		      struct qed_spq_comp_cb *p_comp_addr);

int qed_fcoe_get_stats(struct qed_hwfn *p_hwfn, struct qed_fcoe_stats *stats);

struct qed_fcoe_info {
	spinlock_t lock;
	struct list_head free_list;
};

struct qed_fcoe_info *qed_fcoe_alloc(struct qed_hwfn *p_hwfn);

void qed_fcoe_setup(struct qed_hwfn *p_hwfn, struct qed_fcoe_info *p_fcoe_info);

void qed_fcoe_free(struct qed_hwfn *p_hwfn, struct qed_fcoe_info *p_fcoe_info);

int
qed_sp_fcoe_conn_offload(struct qed_hwfn *p_hwfn,
			 struct qed_fcoe_conn *p_conn,
			 enum spq_mode comp_mode,
			 struct qed_spq_comp_cb *p_comp_addr);

int
qed_sp_fcoe_conn_destroy(struct qed_hwfn *p_hwfn,
			 struct qed_fcoe_conn *p_conn,
			 enum spq_mode comp_mode,
			 struct qed_spq_comp_cb *p_comp_addr);

#ifdef CONFIG_QED_LL2
extern const struct qed_common_ops qed_common_ops_pass;
extern const struct qed_ll2_ops qed_ll2_ops_pass;
#endif

/**
 * @brief - Fills provided statistics struct with statistics.
 *
 * @param cdev
 * @param stats - points to struct that will be filled with statistics.
 */
void qed_get_protocol_stats_fcoe(struct qed_dev *cdev,
				 struct qed_mcp_fcoe_stats *stats);
#endif
