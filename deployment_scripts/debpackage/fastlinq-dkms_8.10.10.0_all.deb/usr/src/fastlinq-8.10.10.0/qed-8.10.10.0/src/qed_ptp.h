#ifndef _QED_PTP_H
#define _QED_PTP_H
#include <linux/types.h>

int qed_ptp_hwtstamp_tx_on(struct qed_hwfn *p_hwfn);
int qed_ptp_enable_pkt2host(struct qed_hwfn *p_hwfn);
int qed_ptp_cfg_rx_filters(struct qed_hwfn *p_hwfn,
			   u32 rule_mask, u32 parm_mask);
u64 qed_ptp_read_rx_ts(struct qed_hwfn *p_hwfn, int *valid);
u64 qed_ptp_read_tx_ts(struct qed_hwfn *p_hwfn, int *valid);
u64 qed_ptp_read_cc(struct qed_hwfn *p_hwfn, int *valid);
int qed_ptp_adjfreq(struct qed_hwfn *p_hwfn, u32 cfg);
int qed_ptp_disable(struct qed_hwfn *p_hwfn);
int qed_ptp_enable(struct qed_hwfn *p_hwfn);

#endif
