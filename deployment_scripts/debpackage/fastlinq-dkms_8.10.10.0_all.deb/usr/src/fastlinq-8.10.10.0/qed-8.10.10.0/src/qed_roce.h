#ifndef _QED_ROCE_H
#define _QED_ROCE_H
#include <linux/types.h>
#include <linux/bitops.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include "qed.h"
#include "qed_dev_api.h"
#include "qed_hsi.h"
#include "qed_if.h"
#include "qed_roce_if.h"

struct qed_rdma_resize_cq_in_params {
	/* input variables (given by miniport) */

	u16 icid;
	u32 cq_size;
	bool pbl_two_level;
	u64 pbl_ptr;
	u16 pbl_num_pages;
	u8 pbl_page_size_log;	/* for the pages that contain the
				 * pointers to the CQ pages
				 */
};

struct qed_rdma_resize_cq_out_params {
	/* output variables, provided to the upper layer */
	u32 prod;		/* CQ producer value on old PBL */
	u32 cons;		/* CQ consumer value on old PBL */
};

struct qed_rdma_resize_cnq_in_params {
	/* input variables (given by miniport) */
	u32 cnq_id;
	u32 pbl_page_size_log;	/* for the pages that contain the
				 * pointers to the cnq pages
				 */
	u64 pbl_ptr;
};

int
qed_rdma_add_user(void *rdma_cxt,
		  struct qed_rdma_add_user_out_params *out_params);

int qed_rdma_alloc_pd(void *rdma_cxt, u16 * pd);

int qed_rdma_alloc_tid(void *rdma_cxt, u32 * tid);

int
qed_rdma_create_cq(void *rdma_cxt,
		   struct qed_rdma_create_cq_in_params *params, u16 * icid);

/* Returns a pointer to the responders' CID, which is also a pointer to the
 * qed_qp_params struct. Returns NULL in case of failure.
 */
struct qed_rdma_qp *qed_rdma_create_qp(void *rdma_cxt,
				       struct qed_rdma_create_qp_in_params
				       *in_params,
				       struct qed_rdma_create_qp_out_params
				       *out_params);

int qed_rdma_deregister_tid(void *rdma_cxt, u32 tid);

int
qed_rdma_destroy_cq(void *rdma_cxt,
		    struct qed_rdma_destroy_cq_in_params *in_params,
		    struct qed_rdma_destroy_cq_out_params *out_params);

int qed_rdma_destroy_qp(void *rdma_cxt, struct qed_rdma_qp *qp);

void qed_rdma_free_pd(void *rdma_cxt, u16 pd);

void qed_rdma_free_tid(void *rdma_cxt, u32 tid);

int
qed_roce_modify_qp(void *rdma_cxt,
		   struct qed_rdma_qp *qp,
		   struct qed_roce_modify_qp_in_params *params);

struct qed_rdma_device *qed_rdma_query_device(void *rdma_cxt);

struct qed_rdma_port *qed_rdma_query_port(void *rdma_cxt);

int
qed_roce_query_qp(void *rdma_cxt,
		  struct qed_rdma_qp *qp,
		  struct qed_roce_query_qp_out_params *out_params);

int
qed_rdma_register_tid(void *rdma_cxt,
		      struct qed_rdma_register_tid_in_params *params);

void qed_rdma_remove_user(void *rdma_cxt, u16 dpi);

int
qed_rdma_resize_cnq(void *rdma_cxt,
		    struct qed_rdma_resize_cnq_in_params *in_params);

/*Returns the CQ CID or zero in case of failure */
int
qed_rdma_resize_cq(void *rdma_cxt,
		   struct qed_rdma_resize_cq_in_params *in_params,
		   struct qed_rdma_resize_cq_out_params *out_params);

/* Before calling rdma_start upper layer (VBD/qed) should fill the
 * page-size and mtu in hwfn context
 */
int qed_rdma_start(void *p_hwfn, struct qed_rdma_start_in_params *params);

int qed_rdma_stop(void *rdma_cxt);

int
qed_rdma_query_stats(void *rdma_cxt,
		     u8 stats_queue,
		     struct qed_rdma_stats_out_params *out_parms);

int
qed_rdma_query_counters(void *rdma_cxt,
			struct qed_rdma_counters_out_params *out_parms);

u32 qed_rdma_get_sb_id(void *p_hwfn, u32 rel_sb_id);

u32 qed_rdma_query_cau_timer_res(void *p_hwfn);

void qed_rdma_cnq_prod_update(void *rdma_cxt, u8 cnq_index, u16 prod);

void qed_rdma_resc_free(struct qed_hwfn *p_hwfn);

/* iWARP API */

int
qed_iwarp_connect(void *rdma_cxt,
		  struct qed_iwarp_connect_in *iparams,
		  struct qed_iwarp_connect_out *oparams);

int
qed_iwarp_create_listen(void *rdma_cxt,
			struct qed_iwarp_listen_in *iparams,
			struct qed_iwarp_listen_out *oparams);

int qed_iwarp_accept(void *rdma_cxt, struct qed_iwarp_accept_in *iparams);

int qed_iwarp_reject(void *rdma_cxt, struct qed_iwarp_reject_in *iparams);

int qed_iwarp_destroy_listen(void *rdma_cxt, void *handle);

/* Constants */

/* HW/FW RoCE Limitations (internal. For external see qed_rdma_api.h) */
#define QED_RDMA_MAX_FMR                    (RDMA_MAX_TIDS)	/* 2^17 - 1 */
#define QED_RDMA_MAX_P_KEY                  (1)
#define QED_RDMA_MAX_WQE                    (0x7FFF)	/* 2^15 -1 */
#define QED_RDMA_MAX_SRQ_WQE_ELEM           (0x7FFF)	/* 2^15 -1 */
#define QED_RDMA_PAGE_SIZE_CAPS             (0xFFFFF000)	/* TODO: > 4k?! */
#define QED_RDMA_ACK_DELAY                  (15)	/* 131 milliseconds */
#define QED_RDMA_MAX_MR_SIZE                (0x10000000000ULL)	/* 2^40 */
#define QED_RDMA_MAX_CQS                    (RDMA_MAX_CQS)	/* 64k */
#define QED_RDMA_MAX_MRS                    (RDMA_MAX_TIDS)	/* 2^17 - 1 */
/* Add 1 for header element */
#define QED_RDMA_MAX_SRQ_ELEM_PER_WQE         (RDMA_MAX_SGE_PER_RQ_WQE + 1)
#define QED_RDMA_MAX_SGE_PER_SRQ_WQE          (RDMA_MAX_SGE_PER_RQ_WQE)
#define QED_RDMA_SRQ_WQE_ELEM_SIZE          (16)
#define QED_RDMA_MAX_SRQS                     (32 * 1024)	/* 32k */

/* Configurable */
/* Max CQE is derived from u16/32 size, halved and decremented by 1 to handle
 * wrap properly and then decremented by 1 again. The latter decrement comes
 * from a requirement to create a chain that is bigger than what the user
 * requested by one:
 * The CQE size is 32 bytes but the FW writes in chunks of 64
 * bytes, for performance purposes. Allocating an extra entry and telling the
 * FW we have less prevents overwriting the first entry in case of a wrap i.e.
 * when the FW writes the last entry and the application hasn't read the first
 * one.
 */
#define QED_RDMA_MAX_CQE_32_BIT             (0x7FFFFFFF - 1)
#define QED_RDMA_MAX_CQE_16_BIT             (0x7FFF - 1)

enum qed_rdma_toggle_bit {
	QED_RDMA_TOGGLE_BIT_CLEAR = 0,
	QED_RDMA_TOGGLE_BIT_SET = 1
};

/* @@@TBD Currently we support only affilited events
 * enum qed_rdma_unaffiliated_event_code {
 * QED_RDMA_PORT_ACTIVE, // Link Up
 * QED_RDMA_PORT_CHANGED, // SGID table has changed
 * QED_RDMA_LOCAL_CATASTROPHIC_ERR, // Fatal device error
 * QED_RDMA_PORT_ERR, // Link down
 * };
 */

struct qed_bmap {
	u32 max_count;

	/* requeseter */

	unsigned long *bitmap;

	/* responder */
};

/* functions for enabling/disabling edpm in rdma PFs according to existence of
 * qps during DCBx update or bar size
 */
void qed_roce_dpm_dcbx(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);
void qed_rdma_dpm_bar(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

struct qed_rdma_info {
	spinlock_t lock;

	struct qed_bmap cq_map;
	struct qed_bmap pd_map;
	struct qed_bmap tid_map;
	struct qed_bmap qp_map;
	struct qed_bmap srq_map;
	struct qed_bmap cid_map;
	struct qed_bmap dpi_map;
	struct qed_bmap toggle_bits;
	struct qed_rdma_events events;
	struct qed_rdma_device *dev;
	struct qed_rdma_port *port;
	u32 last_tid;
	u8 num_cnqs;
	struct rdma_sent_stats rdma_sent_pstats;
	struct rdma_rcv_stats rdma_rcv_tstats;
	u32 num_qps;
	u32 num_mrs;
	u32 num_srqs;
	u8 dcqcn_enabled;
	u8 dcqcn_reaction_point;
	u16 queue_zone_base;
	enum protocol_type proto;
};

struct qed_rdma_qp {
	struct regpair qp_handle;
	struct regpair qp_handle_async;
	u32 qpid;		/* iwarp: may differ from icid */
	u16 icid;
	enum qed_roce_qp_state cur_state;
	bool use_srq;
	bool signal_all;
	bool fmr_and_reserved_lkey;

	bool incoming_rdma_read_en;
	bool incoming_rdma_write_en;
	bool incoming_atomic_en;
	bool e2e_flow_control_en;

	u16 pd;			/* Protection domain */
	u16 pkey;		/* Primary P_key index */
	u32 dest_qp;
	u16 mtu;
	u16 srq_id;
	u8 traffic_class_tos;	/* IPv6/GRH traffic class; IPv4 TOS */
	u8 hop_limit_ttl;	/* IPv6/GRH hop limit; IPv4 TTL */
	u16 dpi;
	u32 flow_label;		/* ignored in IPv4 */
	bool lb_indication;
	u16 vlan_id;
	u32 ack_timeout;
	u8 retry_cnt;
	u8 rnr_retry_cnt;
	u8 min_rnr_nak_timer;
	bool sqd_async;
	union qed_gid sgid;	/* GRH SGID; IPv4/6 Source IP */
	union qed_gid dgid;	/* GRH DGID; IPv4/6 Destination IP */
	enum roce_mode roce_mode;
	u16 udp_src_port;	/* RoCEv2 only */
	u8 stats_queue;

	/* requeseter */

	u8 max_rd_atomic_req;
	u32 sq_psn;
	u16 sq_cq_id;		/* The cq to be associated with the send queue */
	u16 sq_num_pages;
	dma_addr_t sq_pbl_ptr;
	void *orq;
	dma_addr_t orq_phys_addr;
	u8 orq_num_pages;
	bool req_ofloaded;

	/* responder */

	u8 max_rd_atomic_resp;
	u32 rq_psn;
	u16 rq_cq_id;		/* The cq to be associated with the receive queue */
	u16 rq_num_pages;
	dma_addr_t rq_pbl_ptr;
	void *irq;
	dma_addr_t irq_phys_addr;
	u8 irq_num_pages;
	bool resp_ofloaded;

	u8 remote_mac_addr[6];
	u8 local_mac_addr[6];
};

#endif
