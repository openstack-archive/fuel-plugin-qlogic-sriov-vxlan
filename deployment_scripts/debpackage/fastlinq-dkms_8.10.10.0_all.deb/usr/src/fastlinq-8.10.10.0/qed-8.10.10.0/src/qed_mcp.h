#ifndef _QED_MCP_H
#define _QED_MCP_H
#include <linux/types.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include "qed_hsi.h"
#include "qed_fcoe_if.h"
#include "qed_iscsi_if.h"

struct qed_mcp_link_speed_params {
	bool autoneg;
	u32 advertised_speeds;	/* bitmask of DRV_SPEED_CAPABILITY */
	u32 forced_speed;	/* In Mb/s */
};

struct qed_mcp_link_pause_params {
	bool autoneg;
	bool forced_rx;
	bool forced_tx;
};

struct qed_mcp_link_params {
	struct qed_mcp_link_speed_params speed;
	struct qed_mcp_link_pause_params pause;
	u32 loopback_mode;	/* in PMM_LOOPBACK values */
};

struct qed_mcp_link_capabilities {
	u32 speed_capabilities;
	bool default_speed_autoneg;	/* In Mb/s */
	u32 default_speed;	/* In Mb/s */
};

struct qed_mcp_link_state {
	bool link_up;

	u32 line_speed;		/* In Mb/s */
	u32 min_pf_rate;	/* In Mb/s */
	u32 speed;		/* In Mb/s */
	bool full_duplex;

	bool an;
	bool an_complete;
	bool parallel_detection;
	bool pfc_enabled;

#define QED_LINK_PARTNER_SPEED_1G_HD    (1 << 0)
#define QED_LINK_PARTNER_SPEED_1G_FD    (1 << 1)
#define QED_LINK_PARTNER_SPEED_10G      (1 << 2)
#define QED_LINK_PARTNER_SPEED_20G      (1 << 3)
#define QED_LINK_PARTNER_SPEED_25G      (1 << 4)
#define QED_LINK_PARTNER_SPEED_40G      (1 << 5)
#define QED_LINK_PARTNER_SPEED_50G      (1 << 6)
#define QED_LINK_PARTNER_SPEED_100G     (1 << 7)
	u32 partner_adv_speed;

	bool partner_tx_flow_ctrl_en;
	bool partner_rx_flow_ctrl_en;

#define QED_LINK_PARTNER_SYMMETRIC_PAUSE (1)
#define QED_LINK_PARTNER_ASYMMETRIC_PAUSE (2)
#define QED_LINK_PARTNER_BOTH_PAUSE (3)
	u8 partner_adv_pause;

	bool sfp_tx_fault;
};

struct qed_mcp_function_info {
	u8 pause_on_host;

	enum qed_pci_personality protocol;

	u8 bandwidth_min;
	u8 bandwidth_max;

	u8 mac[ETH_ALEN];

	u64 wwn_port;
	u64 wwn_node;

#define QED_MCP_VLAN_UNSET              (0xffff)
	u16 ovlan;
};

struct qed_mcp_nvm_common {
	u32 offset;
	u32 param;
	u32 resp;
	u32 cmd;
};

struct qed_mcp_nvm_rd {
	u32 *buf_size;
	u32 *buf;
};

struct qed_mcp_nvm_wr {
	u32 buf_size;
	u32 *buf;
};

struct qed_mcp_nvm_params {
#define QED_MCP_CMD             (1 << 0)
#define QED_MCP_NVM_RD  (1 << 1)
#define QED_MCP_NVM_WR  (1 << 2)
	u8 type;

	struct qed_mcp_nvm_common nvm_common;

	union {
		struct qed_mcp_nvm_rd nvm_rd;
		struct qed_mcp_nvm_wr nvm_wr;
	};
};

struct qed_mcp_drv_version {
	u32 version;
	u8 name[MCP_DRV_VER_STR_SIZE - 4];
};

struct qed_mcp_lan_stats {
	u64 ucast_rx_pkts;
	u64 ucast_tx_pkts;
	u32 fcs_err;
};

#ifndef QED_PROTO_STATS
#define QED_PROTO_STATS
struct qed_mcp_fcoe_stats {
	u64 rx_pkts;
	u64 tx_pkts;
	u32 fcs_err;
	u32 login_failure;
};

struct qed_mcp_iscsi_stats {
	u64 rx_pdus;
	u64 tx_pdus;
	u64 rx_bytes;
	u64 tx_bytes;
};

struct qed_mcp_rdma_stats {
	u64 rx_pkts;
	u64 tx_pkts;
	u64 rx_bytes;
	u64 tx_byts;
};

enum qed_mcp_protocol_type {
	QED_MCP_LAN_STATS,
	QED_MCP_FCOE_STATS,
	QED_MCP_ISCSI_STATS,
	QED_MCP_RDMA_STATS
};

union qed_mcp_protocol_stats {
	struct qed_mcp_lan_stats lan_stats;
	struct qed_mcp_fcoe_stats fcoe_stats;
	struct qed_mcp_iscsi_stats iscsi_stats;
	struct qed_mcp_rdma_stats rdma_stats;
};
#endif

enum qed_ov_config_method {
	QED_OV_CONFIG_MTU,
	QED_OV_CONFIG_MAC,
	QED_OV_CONFIG_WOL
};

enum qed_ov_client {
	QED_OV_CLIENT_DRV,
	QED_OV_CLIENT_USER
};

enum qed_ov_driver_state {
	QED_OV_DRIVER_STATE_NOT_LOADED,
	QED_OV_DRIVER_STATE_DISABLED,
	QED_OV_DRIVER_STATE_ACTIVE
};

#define QED_MAX_NPIV_ENTRIES 128
#define QED_WWN_SIZE 8
struct qed_fc_npiv_tbl {
	u32 count;
	u8 wwpn[QED_MAX_NPIV_ENTRIES][QED_WWN_SIZE];
	u8 wwnn[QED_MAX_NPIV_ENTRIES][QED_WWN_SIZE];
};

struct qed_temperature_sensor {
	u8 sensor_location;
	u8 threshold_high;
	u8 critical;
	u8 current_temp;
};

#define QED_MAX_NUM_OF_SENSORS  7
struct qed_temperature_info {
	u32 num_sensors;
	struct qed_temperature_sensor sensors[QED_MAX_NUM_OF_SENSORS];
};

enum qed_mba_img_idx {
	QED_MBA_LEGACY_IDX,
	QED_MBA_PCI3CLP_IDX,
	QED_MBA_PCI3_IDX,
	QED_MBA_FCODE_IDX,
	QED_EFI_X86_IDX,
	QED_EFI_IPF_IDX,
	QED_EFI_EBC_IDX,
	QED_EFI_X64_IDX,
	QED_MAX_NUM_OF_ROMIMG
};

struct qed_mba_vers {
	u32 mba_vers[QED_MAX_NUM_OF_ROMIMG];
};

/**
 * @brief - returns the link params of the hw function
 *
 * @param p_hwfn
 *
 * @returns pointer to link params
 */
struct qed_mcp_link_params *qed_mcp_get_link_params(struct qed_hwfn *);

/**
 * @brief - return the link state of the hw function
 *
 * @param p_hwfn
 *
 * @returns pointer to link state
 */
struct qed_mcp_link_state *qed_mcp_get_link_state(struct qed_hwfn *);

/**
 * @brief - return the link capabilities of the hw function
 *
 * @param p_hwfn
 *
 * @returns pointer to link capabilities
 */
struct qed_mcp_link_capabilities
*qed_mcp_get_link_capabilities(struct qed_hwfn *p_hwfn);

/**
 * @brief Request the MFW to set the the link according to 'link_input'.
 *
 * @param p_hwfn
 * @param p_ptt
 * @param b_up - raise link if `true'. Reset link if `false'.
 *
 * @return int
 */
int qed_mcp_set_link(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt, bool b_up);

/**
 * @brief Get the management firmware version value
 *
 * @param p_hwfn
 * @param p_ptt
 * @param p_mfw_ver    - mfw version value
 * @param p_running_bundle_id	- image id in nvram; Optional.
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_get_mfw_ver(struct qed_hwfn *p_hwfn,
			struct qed_ptt *p_ptt,
			u32 * p_mfw_ver, u32 * p_running_bundle_id);

/**
 * @brief Get media type value of the port.
 *
 * @param cdev      - qed dev pointer
 * @param mfw_ver    - media type value
 *
 * @return int -
 *      0 - Operation was successful.
 *      -EBUSY - Operation failed
 */
int qed_mcp_get_media_type(struct qed_dev *cdev, u32 * media_type);

/**
 * @brief - Sends a command to the MCP mailbox.
 *
 * @param p_hwfn      - hw function
 * @param p_ptt       - PTT required for register access
 * @param cmd         - command to be sent to the MCP
 * @param param       - optional param
 * @param o_mcp_resp  - the MCP response code (exclude sequence)
 * @param o_mcp_param - optional parameter provided by the MCP response
 *
 * @return int -
 *      0 - operation was successful
 *      -EBUSY    - operation failed
 */
int qed_mcp_cmd(struct qed_hwfn *p_hwfn,
		struct qed_ptt *p_ptt,
		u32 cmd, u32 param, u32 * o_mcp_resp, u32 * o_mcp_param);

/**
 * @brief - drains the nig, allowing completion to pass in case of pauses.
 *          (Should be called only from sleepable context)
 *
 * @param p_hwfn
 * @param p_ptt
 */
int qed_mcp_drain(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief - Function for reading/manipulating the nvram. Following are supported
 *          functionalities.
 *          1. Read: Read the specified nvram offset.
 *             input values:
 *               type   - QED_MCP_NVM_RD
 *               cmd    - command code (e.g. DRV_MSG_CODE_NVM_READ_NVRAM)
 *               offset - nvm offset
 *
 *             output values:
 *               buf      - buffer
 *               buf_size - buffer size
 *
 *          2. Write: Write the data at the specified nvram offset
 *             input values:
 *               type     - QED_MCP_NVM_WR
 *               cmd      - command code (e.g. DRV_MSG_CODE_NVM_WRITE_NVRAM)
 *               offset   - nvm offset
 *               buf      - buffer
 *               buf_size - buffer size
 *
 *          3. Command: Send the NVM command to MCP.
 *             input values:
 *               type   - QED_MCP_CMD
 *               cmd    - command code (e.g. DRV_MSG_CODE_NVM_DEL_FILE)
 *               offset - nvm offset
 *
 *
 * @param p_hwfn
 * @param p_ptt
 * @param params
 *
 * @return 0 - operation was successful.
 */
int qed_mcp_nvm_command(struct qed_hwfn *p_hwfn,
			struct qed_ptt *p_ptt,
			struct qed_mcp_nvm_params *params);

/**
 * @brief Get the flash size value
 *
 * @param p_hwfn
 * @param p_ptt
 * @param p_flash_size  - flash size in bytes to be filled.
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_get_flash_size(struct qed_hwfn *p_hwfn,
			   struct qed_ptt *p_ptt, u32 * p_flash_size);

/**
 * @brief Send driver version to MFW
 *
 * @param p_hwfn
 * @param p_ptt
 * @param version - Version value
 * @param name - Protocol driver name
 *
 * @return int - 0 - operation was successful.
 */
int
qed_mcp_send_drv_version(struct qed_hwfn *p_hwfn,
			 struct qed_ptt *p_ptt,
			 struct qed_mcp_drv_version *p_ver);

/**
 * @brief Read the MFW process kill counter
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @return u32
 */
u32 qed_get_process_kill_counter(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt);

/**
 * @brief Trigger a recovery process
 *
 *  @param p_hwfn
 *  @param p_ptt
 *
 * @return int
 */
int qed_start_recovery_process(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Notify MFW about the change in base device properties
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param config - Configuation that has been updated
 *  @param client - qed client type
 *
 * @return int - 0 - operation was successful.
 */
int
qed_mcp_ov_update_current_config(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt,
				 enum qed_ov_config_method config,
				 enum qed_ov_client client);

/**
 * @brief Notify MFW about the driver state
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param drv_state - Driver state
 *
 * @return int - 0 - operation was successful.
 */
int
qed_mcp_ov_update_driver_state(struct qed_hwfn *p_hwfn,
			       struct qed_ptt *p_ptt,
			       enum qed_ov_driver_state drv_state);

/**
 * @brief Read NPIV settings form the MFW
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param p_table - Array to hold the FC NPIV data. Client need allocate the
 *                   required buffer. The field 'count' specifies number of NPIV
 *                   entries. A value of 0 means the table was not populated.
 *
 * @return int - 0 - operation was successful.
 */
int
qed_mcp_ov_get_fc_npiv(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt, struct qed_fc_npiv_tbl *p_table);

/**
 * @brief Send MTU size to MFW
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param mtu - MTU size
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_ov_update_mtu(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt, u16 mtu);

/**
 * @brief Set LED status
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param mode - LED mode
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_set_led(struct qed_hwfn *p_hwfn,
		    struct qed_ptt *p_ptt, enum qed_led_mode mode);

/**
 * @brief Set secure mode
 *
 *  @param cdev
 *  @param addr - nvm offset
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_set_secure_mode(struct qed_dev *cdev, u32 addr);

/**
 * @brief Write to phy
 *
 *  @param cdev
 *  @param addr - nvm offset
 *  @param cmd - nvm command
 *  @param p_buf - nvm write buffer
 *  @param len - buffer len
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_phy_write(struct qed_dev *cdev,
		      u32 cmd, u32 addr, u8 * p_buf, u32 len);

/**
 * @brief Write to nvm
 *
 *  @param cdev
 *  @param addr - nvm offset
 *  @param cmd - nvm command
 *  @param p_buf - nvm write buffer
 *  @param len - buffer len
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_write(struct qed_dev *cdev,
		      u32 cmd, u32 addr, u8 * p_buf, u32 len);

/**
 * @brief Put file begin
 *
 *  @param cdev
 *  @param addr - nvm offset
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_put_file_begin(struct qed_dev *cdev, u32 addr);

/**
 * @brief Delete file
 *
 *  @param cdev
 *  @param addr - nvm offset
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_del_file(struct qed_dev *cdev, u32 addr);

/**
 * @brief Check latest response
 *
 *  @param cdev
 *  @param p_buf - nvm write buffer
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_resp(struct qed_dev *cdev, u8 * p_buf);

/**
 * @brief Read from phy
 *
 *  @param cdev
 *  @param addr - nvm offset
 *  @param cmd - nvm command
 *  @param p_buf - nvm write buffer
 *  @param len - buffer len
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_phy_read(struct qed_dev *cdev,
		     u32 cmd, u32 addr, u8 * p_buf, u32 len);

/**
 * @brief Read from nvm
 *
 *  @param cdev
 *  @param addr - nvm offset
 *  @param p_buf - nvm write buffer
 *  @param len - buffer len
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_nvm_read(struct qed_dev *cdev, u32 addr, u8 * p_buf, u32 len);

/**
 * @brief Allows reading a whole nvram image
 *
 * @param p_hwfn
 * @param p_ptt
 * @param image_id - image requested for reading
 * @param p_buffer - allocated buffer into which to fill data
 * @param buffer_len - length of the allocated buffer.
 *
 * @return 0 iff p_buffer now contains the nvram image.
 */
int qed_mcp_get_nvm_image(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt,
			  enum qed_nvm_images image_id,
			  char *p_buffer, u16 buffer_len);

/**
 * @brief Read from sfp
 *
 *  @param p_hwfn - hw function
 *  @param p_ptt  - PTT required for register access
 *  @param port   - transceiver port
 *  @param addr   - I2C address
 *  @param offset - offset in sfp
 *  @param len    - buffer length
 *  @param p_buf  - buffer to read into
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_phy_sfp_read(struct qed_hwfn *p_hwfn,
			 struct qed_ptt *p_ptt,
			 u32 port, u32 addr, u32 offset, u32 len, u8 * p_buf);

/**
 * @brief Write to sfp
 *
 *  @param p_hwfn - hw function
 *  @param p_ptt  - PTT required for register access
 *  @param port   - transceiver port
 *  @param addr   - I2C address
 *  @param offset - offset in sfp
 *  @param len    - buffer length
 *  @param p_buf  - buffer to write from
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_phy_sfp_write(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt,
			  u32 port, u32 addr, u32 offset, u32 len, u8 * p_buf);

/**
 * @brief Gpio read
 *
 *  @param p_hwfn    - hw function
 *  @param p_ptt     - PTT required for register access
 *  @param gpio      - gpio number
 *  @param gpio_val  - value read from gpio
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_gpio_read(struct qed_hwfn *p_hwfn,
		      struct qed_ptt *p_ptt, u16 gpio, u32 * gpio_val);

/**
 * @brief Gpio write
 *
 *  @param p_hwfn    - hw function
 *  @param p_ptt     - PTT required for register access
 *  @param gpio      - gpio number
 *  @param gpio_val  - value to write to gpio
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_gpio_write(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt, u16 gpio, u16 gpio_val);

/**
 * @brief Gpio get information
 *
 *  @param p_hwfn          - hw function
 *  @param p_ptt           - PTT required for register access
 *  @param gpio            - gpio number
 *  @param gpio_direction  - gpio is output (0) or input (1)
 *  @param gpio_ctrl       - gpio control is uninitialized (0),
 *                         path 0 (1), path 1 (2) or shared(3)
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_gpio_info(struct qed_hwfn *p_hwfn,
		      struct qed_ptt *p_ptt,
		      u16 gpio, u32 * gpio_direction, u32 * gpio_ctrl);

/**
 * @brief Bist register test
 *
 *  @param p_hwfn    - hw function
 *  @param p_ptt     - PTT required for register access
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_bist_register_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Bist clock test
 *
 *  @param p_hwfn    - hw function
 *  @param p_ptt     - PTT required for register access
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_bist_clock_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Bist nvm test - get number of images
 *
 *  @param p_hwfn       - hw function
 *  @param p_ptt        - PTT required for register access
 *  @param num_images   - number of images if operation was
 *			  successful. 0 if not.
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_bist_nvm_test_get_num_images(struct qed_hwfn *p_hwfn,
					 struct qed_ptt *p_ptt,
					 u32 * num_images);

/**
 * @brief Bist nvm test - get image attributes by index
 *
 *  @param p_hwfn      - hw function
 *  @param p_ptt       - PTT required for register access
 *  @param p_image_att - Attributes of image
 *  @param image_index - Index of image to get information for
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_bist_nvm_test_get_image_att(struct qed_hwfn *p_hwfn,
					struct qed_ptt *p_ptt,
					struct bist_nvm_image_att *p_image_att,
					u32 image_index);

/**
 * @brief qed_mcp_get_temperature_info - get the status of the temperature
 *                                         sensors
 *
 *  @param p_hwfn        - hw function
 *  @param p_ptt         - PTT required for register access
 *  @param p_temp_status - A pointer to an qed_temperature_info structure to
 *                         be filled with the temperature data
 *
 * @return int - 0 - operation was successful.
 */
int
qed_mcp_get_temperature_info(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt,
			     struct qed_temperature_info *p_temp_info);

/**
 * @brief Get MBA versions - get MBA sub images versions
 *
 *  @param p_hwfn      - hw function
 *  @param p_ptt       - PTT required for register access
 *  @param p_mba_vers  - MBA versions array to fill
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_get_mba_versions(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt,
			     struct qed_mba_vers *p_mba_vers);

/**
 * @brief Count memory ecc events
 *
 *  @param p_hwfn      - hw function
 *  @param p_ptt       - PTT required for register access
 *  @param num_events  - number of memory ecc events
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_mem_ecc_events(struct qed_hwfn *p_hwfn,
			   struct qed_ptt *p_ptt, u64 * num_events);

struct qed_mdump_info {
	u32 reason;
	u32 version;
	u32 config;
	u32 epoch;
	u32 num_of_logs;
	u32 valid_logs;
};

/**
 * @brief - Gets the MFW crash dump configuration and logs info.
 *
 * @param p_hwfn
 * @param p_ptt
 * @param p_mdump_info
 *
 * @param return 0 upon success.
 */
int
qed_mcp_mdump_get_info(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt,
		       struct qed_mdump_info *p_mdump_info);

/**
 * @brief - Clears the MFW crash dump logs.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_mdump_clear_logs(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/* Using hwfn number (and not pf_num) is required since in CMT mode,
 * same pf_num may be used by two different hwfn
 * TODO - this shouldn't really be in .h file, but until all fields
 * required during hw-init will be placed in their correct place in shmem
 * we need it in qed_dev.c [for readin the nvram reflection in shmem].
 */
#define MCP_PF_ID_BY_REL(p_hwfn, rel_pfid) (QED_IS_BB((p_hwfn)->cdev) ?	       \
					    ((rel_pfid) |		       \
					     ((p_hwfn)->abs_pf_id & 1) << 3) : \
					    rel_pfid)
#define MCP_PF_ID(p_hwfn) MCP_PF_ID_BY_REL(p_hwfn, (p_hwfn)->rel_pf_id)

#define MFW_PORT(_p_hwfn)       ((_p_hwfn)->abs_pf_id %			  \
				 ((_p_hwfn)->cdev->num_ports_in_engines * \
				  qed_device_num_engines((_p_hwfn)->cdev)))

struct qed_mcp_info {
	/* Spinlock used for protecting the access to the MFW mailbox */
	spinlock_t lock;
	/* Flag to indicate whether sending a MFW mailbox is forbidden */
	bool block_mb_sending;

	/* Address of the MCP public area */
	u32 public_base;
	/* Address of the driver mailbox */
	u32 drv_mb_addr;
	/* Address of the MFW mailbox */
	u32 mfw_mb_addr;
	/* Address of the port configuration (link) */
	u32 port_addr;

	/* Current driver mailbox sequence */
	u16 drv_mb_seq;
	/* Current driver pulse sequence */
	u16 drv_pulse_seq;

	struct qed_mcp_link_params link_input;
	struct qed_mcp_link_state link_output;
	struct qed_mcp_link_capabilities link_capabilities;

	struct qed_mcp_function_info func_info;

	u8 *mfw_mb_cur;
	u8 *mfw_mb_shadow;
	u16 mfw_mb_length;
	u16 mcp_hist;
};

struct qed_mcp_mb_params {
	u32 cmd;
	u32 param;
	union drv_union_data *p_data_src;
	union drv_union_data *p_data_dst;
	u32 mcp_resp;
	u32 mcp_param;
};

/**
 * @brief Initialize the interface with the MCP
 *
 * @param p_hwfn - HW func
 * @param p_ptt - PTT required for register access
 *
 * @return int
 */
int qed_mcp_cmd_init(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Intialize the port interface with the MCP
 *
 * @param p_hwfn
 * @param p_ptt
 * Can only be called after `num_ports_in_engines' is set
 */
void qed_mcp_cmd_port_init(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);
/**
 * @brief Releases resources allocated during the init process.
 *
 * @param p_hwfn - HW func
 * @param p_ptt - PTT required for register access
 *
 * @return int
 */

int qed_mcp_free(struct qed_hwfn *p_hwfn);

/**
 * @brief This function is called from the DPC context. After
 * pointing PTT to the mfw mb, check for events sent by the MCP
 * to the driver and ack them. In case a critical event
 * detected, it will be handled here, otherwise the work will be
 * queued to a sleepable work-queue.
 *
 * @param p_hwfn - HW function
 * @param p_ptt - PTT required for register access
 * @return int - 0 - operation
 * was successul.
 */
int qed_mcp_handle_events(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief When MFW doesn't get driver pulse for couple of seconds, at some
 * threshold before timeout expires, it will generate interrupt
 * through a dedicated status block (DPSB - Driver Pulse Status
 * Block), which the driver should respond immediately, by
 * providing keepalive indication after setting the PTT to the
 * driver-MFW mailbox. This function is called directly from the
 * DPC upon receiving the DPSB attention.
 *
 * @param p_hwfn - hw function
 * @param p_ptt - PTT required for register access
 * @return int - 0 - operation
 * was successul.
 */
int qed_issue_pulse(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Sends a LOAD_REQ to the MFW, and in case operation
 *        succeed, returns whether this PF is the first on the
 *        chip/engine/port or function. This function should be
 *        called when driver is ready to accept MFW events after
 *        Storms initializations are done.
 *
 * @param p_hwfn       - hw function
 * @param p_ptt        - PTT required for register access
 * @param p_load_code  - The MCP response param containing one
 *      of the following:
 *      FW_MSG_CODE_DRV_LOAD_ENGINE
 *      FW_MSG_CODE_DRV_LOAD_PORT
 *      FW_MSG_CODE_DRV_LOAD_FUNCTION
 * @return int -
 *      0 - Operation was successul.
 *      -EBUSY - Operation failed
 */
int qed_mcp_load_req(struct qed_hwfn *p_hwfn,
		     struct qed_ptt *p_ptt, u32 * p_load_code);

/**
 * @brief Read the MFW mailbox into Current buffer.
 *
 * @param p_hwfn
 * @param p_ptt
 */
void qed_mcp_read_mb(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief Ack to mfw that driver finished FLR process for VFs
 *
 * @param p_hwfn
 * @param p_ptt
 * @param vfs_to_ack - bit mask of all engine VFs for which the PF acks.
 *
 * @param return int - 0 upon success.
 */
int qed_mcp_ack_vf_flr(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt, u32 * vfs_to_ack);

/**
 * @brief - calls during init to read shmem of all function-related info.
 *
 * @param p_hwfn
 *
 * @param return 0 upon success.
 */
int qed_mcp_fill_shmem_func_info(struct qed_hwfn *p_hwfn,
				 struct qed_ptt *p_ptt);

/**
 * @brief - Reset the MCP using mailbox command.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_reset(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief - Sends an NVM write command request to the MFW with
 *          payload.
 *
 * @param p_hwfn
 * @param p_ptt
 * @param cmd - Command: Either DRV_MSG_CODE_NVM_WRITE_NVRAM or
 *            DRV_MSG_CODE_NVM_PUT_FILE_DATA
 * @param param - [0:23] - Offset [24:31] - Size
 * @param o_mcp_resp - MCP response
 * @param o_mcp_param - MCP response param
 * @param i_txn_size -  Buffer size
 * @param i_buf - Pointer to the buffer
 *
 * @param return 0 upon success.
 */
int qed_mcp_nvm_wr_cmd(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt,
		       u32 cmd,
		       u32 param,
		       u32 * o_mcp_resp,
		       u32 * o_mcp_param, u32 i_txn_size, u32 * i_buf);

/**
 * @brief - Sends an NVM read command request to the MFW to get
 *        a buffer.
 *
 * @param p_hwfn
 * @param p_ptt
 * @param cmd - Command: DRV_MSG_CODE_NVM_GET_FILE_DATA or
 *            DRV_MSG_CODE_NVM_READ_NVRAM commands
 * @param param - [0:23] - Offset [24:31] - Size
 * @param o_mcp_resp - MCP response
 * @param o_mcp_param - MCP response param
 * @param o_txn_size -  Buffer size output
 * @param o_buf - Pointer to the buffer returned by the MFW.
 *
 * @param return 0 upon success.
 */
int qed_mcp_nvm_rd_cmd(struct qed_hwfn *p_hwfn,
		       struct qed_ptt *p_ptt,
		       u32 cmd,
		       u32 param,
		       u32 * o_mcp_resp,
		       u32 * o_mcp_param, u32 * o_txn_size, u32 * o_buf);

/**
 * @brief indicates whether the MFW objects [under mcp_info] are accessible
 *
 * @param p_hwfn
 *
 * @return true iff MFW is running and mcp_info is initialized
 */
bool qed_mcp_is_init(struct qed_hwfn *p_hwfn);

/**
 * @brief request MFW to configure MSI-X for a VF
 *
 * @param p_hwfn
 * @param p_ptt
 * @param vf_id - absolute inside engine
 * @param num_sbs - number of entries to request
 *
 * @return int
 */
int qed_mcp_config_vf_msix(struct qed_hwfn *p_hwfn,
			   struct qed_ptt *p_ptt, u8 vf_id, u8 num);

/**
 * @brief - Halt the MCP.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_halt(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief - Wake up the MCP.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_resume(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);
int __qed_configure_pf_max_bandwidth(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     struct qed_mcp_link_state *p_link,
				     u8 max_bw);
int __qed_configure_pf_min_bandwidth(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     struct qed_mcp_link_state *p_link,
				     u8 min_bw);
int qed_mcp_mask_parities(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt, u32 mask_parities);
#if 0
int qed_hw_init_first_eth(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt, u8 * p_pf);
#endif
/**
 * @brief - Sends crash mdump related info to the MFW.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_mdump_set_values(struct qed_hwfn *p_hwfn,
			     struct qed_ptt *p_ptt, u32 epoch);

/**
 * @brief - Triggers a MFW crash dump procedure.
 *
 * @param p_hwfn
 * @param p_ptt
 *
 * @param return 0 upon success.
 */
int qed_mcp_mdump_trigger(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

/**
 * @brief - Gets the MFW allocation info for the given resource
 *
 *  @param p_hwfn
 *  @param p_ptt
 *  @param p_resc_info
 *  @param p_mcp_resp
 *  @param p_mcp_param
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_get_resc_info(struct qed_hwfn *p_hwfn,
			  struct qed_ptt *p_ptt,
			  struct resource_info *p_resc_info,
			  u32 * p_mcp_resp, u32 * p_mcp_param);

/**
 * @brief - Initiates PF FLR
 *
 *  @param p_hwfn
 *  @param p_ptt
 *
 * @return int - 0 - operation was successful.
 */
int qed_mcp_initiate_pf_flr(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);

#endif
