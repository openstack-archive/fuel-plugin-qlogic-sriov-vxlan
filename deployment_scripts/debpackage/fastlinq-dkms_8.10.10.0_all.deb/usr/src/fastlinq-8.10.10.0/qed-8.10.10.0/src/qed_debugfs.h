#ifndef _QED_DEBUGFS_H
#define _QED_DEBUGFS_H
enum qed_dbg_features {
	DBG_FEATURE_BUS,
	DBG_FEATURE_GRC,
	DBG_FEATURE_IDLE_CHK,
	DBG_FEATURE_MCP_TRACE,
	DBG_FEATURE_REG_FIFO,
	DBG_FEATURE_IGU_FIFO,
	DBG_FEATURE_PROTECTION_OVERRIDE,
	DBG_FEATURE_FW_ASSERTS,
	DBG_FEATURE_NUM
};

/* Forward Declaration */
struct qed_dev;
struct qed_hwfn;
struct qed_ptt;
void qed_copy_preconfig_to_bus(struct qed_dev *cdev, u8 init_engine);
int qed_copy_bus_to_postconfig(struct qed_dev *cdev, u8 down_engine);
int qed_dbg_grc(struct qed_dev *cdev, void *buffer, u32 * num_dumped_bytes);
int qed_dbg_grc_size(struct qed_dev *cdev);
int qed_dbg_idle_chk(struct qed_dev *cdev, void *buffer,
		     u32 * num_dumped_bytes);
int qed_dbg_idle_chk_size(struct qed_dev *cdev);
int qed_dbg_reg_fifo(struct qed_dev *cdev, void *buffer,
		     u32 * num_dumped_bytes);
int qed_dbg_reg_fifo_size(struct qed_dev *cdev);
int qed_dbg_igu_fifo(struct qed_dev *cdev, void *buffer,
		     u32 * num_dumped_bytes);
int qed_dbg_igu_fifo_size(struct qed_dev *cdev);
int qed_dbg_protection_override(struct qed_dev *cdev, void *buffer,
				u32 * num_dumped_bytes);
int qed_dbg_protection_override_size(struct qed_dev *cdev);
int qed_dbg_fw_asserts(struct qed_dev *cdev, void *buffer,
		       u32 * num_dumped_bytes);
int qed_dbg_fw_asserts_size(struct qed_dev *cdev);
int qed_dbg_mcp_trace(struct qed_dev *cdev, void *buffer,
		      u32 * num_dumped_bytes);
int qed_dbg_mcp_trace_size(struct qed_dev *cdev);
int qed_dbg_phy(struct qed_dev *cdev, void *buffer, u32 * num_dumped_bytes);
int qed_dbg_phy_size(struct qed_dev *cdev);
int qed_dbg_all_data(struct qed_dev *cdev, void *buffer);
int qed_dbg_all_data_size(struct qed_dev *cdev);
void qed_dbg_save_all_data(struct qed_dev *cdev, bool print_dbg_data);
u8 qed_get_debug_engine(struct qed_dev *cdev);
void qed_set_debug_engine(struct qed_dev *cdev, int engine_number);
int qed_dbg_feature(struct qed_dev *cdev, void *buffer,
		    enum qed_dbg_features feature, u32 * num_dumped_bytes);
int qed_dbg_feature_size(struct qed_dev *cdev, enum qed_dbg_features feature);
void qed_debug_printk(char *format, ...);
void qed_free_debug_data_info(struct qed_dev *cdev);
int qed_str_engine(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		   char *params_string);
void qed_register_debug_cb(struct qed_dev *cdev, char *key,
			   void (*func_ptr) (void *), void *cookie);

int qed_str_bus_reset(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		      char *params_string);
int qed_str_bus_set_pci_output(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			       char *params_string);
int qed_str_bus_set_nw_output(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      char *params_string);
int qed_str_bus_enable_block(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			     char *params_string);
int qed_str_bus_enable_storm(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			     char *params_string);
int qed_str_bus_enable_timestamp(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_bus_add_eid_range_sem_filter(struct qed_hwfn *p_hwfn,
					 struct qed_ptt *p_ptt,
					 char *params_string);
int qed_str_bus_add_eid_mask_sem_filter(struct qed_hwfn *p_hwfn,
					struct qed_ptt *p_ptt,
					char *params_string);
int qed_str_bus_add_cid_sem_filter(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt, char *params_string);
int qed_str_bus_enable_filter(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      char *params_string);
int qed_str_bus_enable_trigger(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			       char *params_string);
int qed_str_bus_add_trigger_state(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_bus_add_constraint(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			       char *params_string);
int qed_str_bus_start(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		      char *params_string);
int qed_str_bus_stop(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		     char *params_string);
int qed_str_bus_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		     char *params_string);
int qed_str_grc_config(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		       char *params_string);
int qed_str_grc_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		     char *params_string);
int qed_str_idle_chk_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_mcp_trace_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_reg_fifo_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_igu_fifo_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_protection_override_dump(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     char *params_string);
int qed_str_fw_asserts_dump(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			    char *params_string);
int qed_str_qm_reconf_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_ets_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		     char *params_string);
int qed_str_phony_dcbx_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			    char *params_string);
int qed_str_mcp_halt_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_mcp_resume_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			    char *params_string);
int qed_str_mcp_mask_parities_test(struct qed_hwfn *p_hwfn,
				   struct qed_ptt *p_ptt, char *params_string);
int qed_str_mcp_unmask_parities_test(struct qed_hwfn *p_hwfn,
				     struct qed_ptt *p_ptt,
				     char *params_string);
int qed_str_test_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		      char *params_string);
int qed_str_gen_process_kill_test(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_gen_system_kill_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_trigger_recovery_test(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_msix_vector_mask_test(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_msix_mask_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_msix_disable_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      char *params_string);
int qed_str_config_obff_fsm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_dump_obff_stats_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_set_obff_state_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				char *params_string);
int qed_str_ramrod_flood_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      char *params_string);
int qed_str_gen_fan_failure_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_bist_register_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			       char *params_string);
int qed_str_bist_clock_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			    char *params_string);
int qed_str_bist_nvm_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_get_temperature_test(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_get_mba_versions_test(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_phy_core_write(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_phy_core_read(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_phy_raw_write(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_phy_raw_read(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			 char *params_string);
int qed_str_phy_mac_stat(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			 char *params_string);
int qed_str_phy_info(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
		     char *params_string);
int qed_str_phy_sfp_write(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_phy_sfp_read(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			 char *params_string);
int qed_str_phy_sfp_decode(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_phy_sfp_get_inserted(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				 char *params_string);
int qed_str_phy_sfp_get_txdisable(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_phy_sfp_set_txdisable(struct qed_hwfn *p_hwfn,
				  struct qed_ptt *p_ptt, char *params_string);
int qed_str_phy_sfp_get_txreset(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
				char *params_string);
int qed_str_phy_sfp_get_rxlos(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			      char *params_string);
int qed_str_phy_sfp_get_eeprom(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			       char *params_string);
int qed_str_phy_gpio_write(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			   char *params_string);
int qed_str_phy_gpio_read(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
int qed_str_phy_gpio_info(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt,
			  char *params_string);
#endif
