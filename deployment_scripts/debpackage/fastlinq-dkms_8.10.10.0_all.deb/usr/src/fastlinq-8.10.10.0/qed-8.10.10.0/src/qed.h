#ifndef _QED_H
#define _QED_H
#include <linux/types.h>
#include <linux/delay.h>
#include <linux/firmware.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/pci.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/workqueue.h>
#include <linux/zlib.h>
#if defined(QED_UPSTREAM)
#include <linux/hashtable.h>
#endif
#if defined(CONFIG_DEBUG_FS)
#include <linux/debugfs.h>
#endif
#if defined(CONFIG_DEBUG_FS)
#include <linux/fs.h>
#endif
#include "qed_debugfs.h"
#include "qed_hsi.h"
#include "qed_if.h"
#include "qed_compat.h"
#include "qed_eth_if.h"
#include "qed_if.h"
#ifndef _QED_H_
#define _QED_H_

#define DRV_MODULE_VERSION "8.10.10.0"

#define MAX_HWFNS_PER_DEVICE    (4)
#define NAME_SIZE 16
#define VER_SIZE 16
#define ARRAY_DECL static const
#define QED_WFQ_UNIT    100

#define ISCSI_BDQ_ID(_port_id) (_port_id)
#define FCOE_BDQ_ID(_port_id) (_port_id + 2)
/* Constants */
#define QED_WID_SIZE            (1024)

/* Configurable */
#define QED_PF_DEMS_SIZE        (4)

/* cau states */
enum qed_coalescing_mode {
	QED_COAL_MODE_DISABLE,
	QED_COAL_MODE_ENABLE
};

enum qed_nvm_cmd {
	QED_PUT_FILE_BEGIN = DRV_MSG_CODE_NVM_PUT_FILE_BEGIN,
	QED_PUT_FILE_DATA = DRV_MSG_CODE_NVM_PUT_FILE_DATA,
	QED_NVM_READ_NVRAM = DRV_MSG_CODE_NVM_READ_NVRAM,
	QED_NVM_WRITE_NVRAM = DRV_MSG_CODE_NVM_WRITE_NVRAM,
	QED_NVM_DEL_FILE = DRV_MSG_CODE_NVM_DEL_FILE,
	QED_NVM_SET_SECURE_MODE = DRV_MSG_CODE_SET_SECURE_MODE,
	QED_PHY_RAW_READ = DRV_MSG_CODE_PHY_RAW_READ,
	QED_PHY_RAW_WRITE = DRV_MSG_CODE_PHY_RAW_WRITE,
	QED_PHY_CORE_READ = DRV_MSG_CODE_PHY_CORE_READ,
	QED_PHY_CORE_WRITE = DRV_MSG_CODE_PHY_CORE_WRITE,
	QED_GET_MCP_NVM_RESP = 0xFFFFFF00
};

/* helpers */

static inline u32 DB_ADDR(u32 cid, u32 DEMS)
{
	u32 db_addr = FIELD_VALUE(DB_LEGACY_ADDR_DEMS, DEMS) |
	    (cid * QED_PF_DEMS_SIZE);

	return db_addr;
}

static inline u32 DB_ADDR_VF(u32 cid, u32 DEMS)
{
	u32 db_addr = FIELD_VALUE(DB_LEGACY_ADDR_DEMS, DEMS) |
	    FIELD_VALUE(DB_LEGACY_ADDR_ICID, cid);

	return db_addr;
}

#define ALIGNED_TYPE_SIZE(type_name, p_hwfn)				     \
	((sizeof(type_name) + (u32)(1 << (p_hwfn->cdev->cache_shift)) - 1) & \
	 ~((1 << (p_hwfn->cdev->cache_shift)) - 1))

#define for_each_hwfn(cdev, i)  for (i = 0; i < cdev->num_hwfns; i++)

#define D_TRINE(val, cond1, cond2, true1, true2, def) \
	(val == (cond1) ? true1 :		      \
	 (val == (cond2) ? true2 : def))

/* forward */
struct qed_ptt_pool;
struct qed_spq;
struct qed_sb_info;
struct qed_sb_attn_info;
struct qed_cxt_mngr;
struct qed_dma_mem;
struct qed_sb_sp_info;
struct qed_ll2_info;
struct qed_igu_info;
struct qed_mcp_info;
struct qed_dcbx_info;

struct qed_rt_data {
	u32 *init_val;
	bool *b_valid;
};

enum qed_tunn_mode {
	QED_MODE_L2GENEVE_TUNN,
	QED_MODE_IPGENEVE_TUNN,
	QED_MODE_L2GRE_TUNN,
	QED_MODE_IPGRE_TUNN,
	QED_MODE_VXLAN_TUNN,
};

enum qed_tunn_clss {
	QED_TUNN_CLSS_MAC_VLAN,
	QED_TUNN_CLSS_MAC_VNI,
	QED_TUNN_CLSS_INNER_MAC_VLAN,
	QED_TUNN_CLSS_INNER_MAC_VNI,
	QED_TUNN_CLSS_MAC_VLAN_DUAL_STAGE,
	MAX_QED_TUNN_CLSS,
};

struct qed_tunn_start_params {
	unsigned long tunn_mode;
	u16 vxlan_udp_port;
	u16 geneve_udp_port;
	u8 update_vxlan_udp_port;
	u8 update_geneve_udp_port;
	u8 tunn_clss_vxlan;
	u8 tunn_clss_l2geneve;
	u8 tunn_clss_ipgeneve;
	u8 tunn_clss_l2gre;
	u8 tunn_clss_ipgre;
};

struct qed_tunn_update_params {
	unsigned long tunn_mode_update_mask;
	unsigned long tunn_mode;
	u16 vxlan_udp_port;
	u16 geneve_udp_port;
	u8 update_rx_pf_clss;
	u8 update_tx_pf_clss;
	u8 update_vxlan_udp_port;
	u8 update_geneve_udp_port;
	u8 tunn_clss_vxlan;
	u8 tunn_clss_l2geneve;
	u8 tunn_clss_ipgeneve;
	u8 tunn_clss_l2gre;
	u8 tunn_clss_ipgre;
};

/* The PCI personality is not quite synonymous to protocol ID:
 * 1. All personalities need CORE connections
 * 2. The Ethernet personality may support also the RoCE/iWARP protocol
 */
enum qed_pci_personality {
	QED_PCI_ETH,
	QED_PCI_FCOE,
	QED_PCI_ISCSI,
	QED_PCI_ETH_ROCE,
	QED_PCI_IWARP,
	QED_PCI_DEFAULT		/* default in shmem */
};

/* All VFs are symetric, all counters are PF + all VFs */
struct qed_qm_iids {
	u32 cids;
	u32 vf_cids;
	u32 tids;
};

#define MAX_PF_PER_PORT 8

/* HW / FW resources, output of features supported below, most information
 * is received from MFW.
 */
enum qed_resources {
	QED_SB,
	QED_L2_QUEUE,
	QED_VPORT,
	QED_RSS_ENG,
	QED_PQ,
	QED_RL,
	QED_MAC,
	QED_VLAN,
	QED_RDMA_CNQ_RAM,
	QED_ILT,
	QED_LL2_QUEUE,
	QED_CMDQS_CQS,
	QED_RDMA_STATS_QUEUE,
	QED_MAX_RESC,		/* must be last */
};

/* Features that require resources, given as input to the resource management
 * algorithm, the output are the resources above
 */
enum qed_feature {
	QED_PF_L2_QUE,
	QED_PF_TC,
	QED_VF,
	QED_EXTRA_VF_QUE,
	QED_VMQ,
	QED_RDMA_CNQ,
	QED_ISCSI_CQ,
	QED_FCOE_CQ,
	QED_MAX_FEATURES,
};

enum qed_port_mode {
	QED_PORT_MODE_DE_2X40G,
	QED_PORT_MODE_DE_2X50G,
	QED_PORT_MODE_DE_1X100G,
	QED_PORT_MODE_DE_4X10G_F,
	QED_PORT_MODE_DE_4X10G_E,
	QED_PORT_MODE_DE_4X20G,
	QED_PORT_MODE_DE_1X40G,
	QED_PORT_MODE_DE_2X25G,
	QED_PORT_MODE_DE_1X25G,
	QED_PORT_MODE_DE_4X25G,
};

enum qed_dev_cap {
	QED_DEV_CAP_ETH,
	QED_DEV_CAP_FCOE,
	QED_DEV_CAP_ISCSI,
	QED_DEV_CAP_ROCE,
	QED_DEV_CAP_IWARP
};

struct qed_hw_info {
	/* PCI personality */
	enum qed_pci_personality personality;

	/* Resource Allocation scheme results */
	u32 resc_start[QED_MAX_RESC];
	u32 resc_num[QED_MAX_RESC];
	u32 feat_num[QED_MAX_FEATURES];

#define RESC_START(_p_hwfn, resc) ((_p_hwfn)->hw_info.resc_start[resc])
#define RESC_NUM(_p_hwfn, resc) ((_p_hwfn)->hw_info.resc_num[resc])
#define RESC_END(_p_hwfn, resc) (RESC_START(_p_hwfn, resc) + \
				 RESC_NUM(_p_hwfn, resc))
#define FEAT_NUM(_p_hwfn, resc) ((_p_hwfn)->hw_info.feat_num[resc])

	/* Amount of traffic classes HW supports */
	u8 num_hw_tc;

	/* Amount of TCs which should be active according to DCBx or upper layer driver configuration */
	u8 num_active_tc;

	/* Traffic class used for tcp out of order traffic */
	u8 ooo_tc;

	/* The traffic class used by PF for it's offloaded protocol */
	u8 offload_tc;

	u32 concrete_fid;
	u16 opaque_fid;
	u16 ovlan;
	u32 part_num[4];

#define ETH_ALEN 6		/* @@@ TBD - define somewhere else for Windows */
	unsigned char hw_mac_addr[ETH_ALEN];
	u64 node_wwn;		/* For FCoE only */
	u64 port_wwn;		/* For FCoE only */

	u16 num_iscsi_conns;
	u16 num_fcoe_conns;

	struct qed_igu_info *p_igu_info;
	/* Sriov */
	u8 max_chains_per_vf;

	u32 port_mode;
	u32 hw_mode;
	unsigned long device_capabilities;

	/* Default DCBX mode */
	u8 dcbx_mode;
};

struct qed_hw_cid_data {
	u32 cid;
	bool b_cid_allocated;
	u8 vfid;		/* 1-based; 0 signals this is for a PF */

	/* Additional identifiers */
	u16 opaque_fid;
	u8 vport_id;
};

/* maximun size of read/write commands (HW limit) */
#define DMAE_MAX_RW_SIZE        0x2000

struct qed_dmae_info {
	/* Mutex for synchronizing access to functions */
	struct mutex mutex;

	u8 channel;

	dma_addr_t completion_word_phys_addr;

	/* The memory location where the DMAE writes the completion
	 * value when an operation is finished on this context.
	 */
	u32 *p_completion_word;

	dma_addr_t intermediate_buffer_phys_addr;

	/* An intermediate buffer for DMAE operations that use virtual
	 * addresses - data is DMA'd to/from this buffer and then
	 * memcpy'd to/from the virtual address
	 */
	u32 *p_intermediate_buffer;

	dma_addr_t dmae_cmd_phys_addr;
	struct dmae_cmd *p_dmae_cmd;
};

struct qed_wfq_data {
	u32 default_min_speed;	/* When wfq feature is not configured */
	u32 min_speed;		/* when feature is configured for any 1 vport */
	bool configured;
};

struct qed_qm_info {
	struct init_qm_pq_params *qm_pq_params;
	struct init_qm_vport_params *qm_vport_params;
	struct init_qm_port_params *qm_port_params;
	u16 start_pq;
	u8 start_vport;
	u8 pure_lb_pq;
	u8 offload_pq;
	u8 pure_ack_pq;
	u8 ooo_pq;
	u8 vf_queues_offset;
	u16 num_pqs;
	u16 num_vf_pqs;
	u8 num_vports;
	u8 max_phys_tcs_per_port;
	bool pf_rl_en;
	bool pf_wfq_en;
	bool vport_rl_en;
	bool vport_wfq_en;
	u8 pf_wfq;
	u32 pf_rl;
	struct qed_wfq_data *wfq_data;
	u8 num_pf_rls;
};

struct storm_stats {
	u32 address;
	u32 len;
};

struct qed_fw_data {
#ifdef CONFIG_QED_BINARY_FW
	struct fw_ver_info *fw_ver_info;
#endif
	const u8 *modes_tree_buf;
	union init_op *init_ops;
	const u32 *arr_data;
	u32 init_ops_size;
};

struct qed_simd_fp_handler {
	void *token;
	void (*func) (void *);
};

struct qed_hwfn {
	struct qed_dev *cdev;
	u8 my_id;		/* ID inside the PF */
#define IS_LEAD_HWFN(edev)              (!((edev)->my_id))
	u8 rel_pf_id;		/* Relative to engine */
	u8 abs_pf_id;
#define QED_PATH_ID(_p_hwfn) \
	(QED_IS_K2((_p_hwfn)->cdev) ? 0 : ((_p_hwfn)->abs_pf_id & 1))
	u8 port_id;
	bool b_active;

	u32 dp_module;
	u8 dp_level;
	char name[NAME_SIZE];
	void *dp_ctx;

	bool first_on_engine;
	bool hw_init_done;

	u8 num_funcs_on_engine;
	u8 enabled_func_idx;

	/* BAR access */
	void __iomem *regview;
	void __iomem *doorbells;
	u64 db_phys_addr;
	unsigned long db_size;

	/* PTT pool */
	struct qed_ptt_pool *p_ptt_pool;

	/* HW info */
	struct qed_hw_info hw_info;

	/* rt_array (for init-tool) */
	struct qed_rt_data rt_data;

	/* SPQ */
	struct qed_spq *p_spq;

	/* EQ */
	struct qed_eq *p_eq;

	/* Consolidate Q */
	struct qed_consq *p_consq;

	/* Slow-Path definitions */
	struct tasklet_struct *sp_dpc;
	bool b_sp_dpc_enabled;

	struct qed_ptt *p_main_ptt;
	struct qed_ptt *p_dpc_ptt;

	struct qed_sb_sp_info *p_sp_sb;
	struct qed_sb_attn_info *p_sb_attn;

	/* Protocol related */
	bool using_ll2;
	struct qed_ll2_info *p_ll2_info;
	struct qed_ooo_info *p_ooo_info;
	struct qed_iscsi_info *p_iscsi_info;
	struct qed_fcoe_info *p_fcoe_info;
	struct qed_rdma_info *p_rdma_info;
	struct qed_pf_params pf_params;

	bool b_rdma_enabled_in_prs;
	u32 rdma_prs_search_reg;

	/* Array of sb_info of all status blocks */
	struct qed_sb_info *sbs_info[MAX_SB_PER_PF_MIMD];
	u16 num_sbs;

	struct qed_cxt_mngr *p_cxt_mngr;

	/* Flag indicating whether interrupts are enabled or not */
	bool b_int_enabled;
	bool b_int_requested;

	/* True if the driver requests for the link */
	bool b_drv_link_init;

	struct qed_vf_iov *vf_iov_info;
	struct qed_pf_iov *pf_iov_info;
	struct qed_mcp_info *mcp_info;
	struct qed_dcbx_info *p_dcbx_info;

	struct qed_hw_cid_data *p_tx_cids;
	struct qed_hw_cid_data *p_rx_cids;

	struct qed_dmae_info dmae_info;

	/* QM init */
	struct qed_qm_info qm_info;

	/* Buffer for unzipping firmware data */
#ifdef CONFIG_QED_ZIPPED_FW
	void *unzip_buf;
#endif

	struct dbg_tools_data dbg_info;

	/* PWM region specific data */
	u32 dpi_size;
	u32 dpi_count;
	u32 dpi_start_offset;	/* this is used to
				 * calculate th
				 * doorbell address
				 */

	/* If one of the following is set then EDPM shouldn't be used */
	u8 dcbx_no_edpm;
	u8 db_bar_no_edpm;

	struct qed_simd_fp_handler simd_proto_handler[64];

#ifdef CONFIG_QED_SRIOV
	struct workqueue_struct *iov_wq;
	struct delayed_work iov_task;
	unsigned long iov_task_flags;
#endif
	struct z_stream_s *stream;

	struct qed_roce_ll2_info *ll2;
};

struct qed_filter_ucast;
struct qed_vf_info;
struct qed_eth_cb_ops;
struct qed_dev_info;
struct qed_cb_ll2_info;
struct qed_public_vf_info;
struct qed_vf_acquire_sw_info;
union qed_mcp_protocol_stats;
enum qed_mcp_protocol_type;

struct pci_params {
	int pm_cap;

	unsigned long mem_start;
	unsigned long mem_end;
	unsigned int irq;
	u8 pf_num;
};

struct qed_int_param {
	u32 int_mode;
	u8 num_vectors;
	u8 min_msix_cnt;	/* for minimal functionality */
};

struct qed_int_params {
	struct qed_int_param in;
	struct qed_int_param out;
	struct msix_entry *msix_table;
	bool fp_initialized;
	u8 fp_msix_base;
	u8 fp_msix_cnt;
#ifdef CONFIG_QEDR
	u8 rdma_msix_base;
	u8 rdma_msix_cnt;
#endif
};

#if defined(CONFIG_DEBUG_FS)
struct qed_dbg_feature {
	struct dentry *dentry;
	u8 *dump_buf;
	u32 buf_size;
	u32 dumped_dwords;
};

struct debug_data_info_pool {
	struct list_head debug_data_list;
};

/* info of chain for printing */
struct chain_print_struct {
	bool b_key_entered;
	char *buffer;
	u32 current_index;
	u32 final_index;
	bool print_metadata;
	struct qed_chain *chain;
};
#endif

struct qed_dev {
	u32 dp_module;
	u8 dp_level;
	char name[NAME_SIZE];
	void *dp_ctx;

	u8 type;
#define QED_DEV_TYPE_BB (0 << 0)
#define QED_DEV_TYPE_AH (1 << 0)
/* Translate type/revision combo into the proper conditions */
#define QED_IS_BB(dev)  ((dev)->type == QED_DEV_TYPE_BB)
#define QED_IS_BB_A0(dev)       (QED_IS_BB(dev) && CHIP_REV_IS_A0(dev))
#ifndef ASIC_ONLY
#define QED_IS_BB_B0(dev)       ((QED_IS_BB(dev) && CHIP_REV_IS_B0(dev)) || \
				 (CHIP_REV_IS_TEDIBEAR(dev)))
#else
#define QED_IS_BB_B0(dev)       (QED_IS_BB(dev) && CHIP_REV_IS_B0(dev))
#endif
#define QED_IS_AH(dev)  ((dev)->type == QED_DEV_TYPE_AH)
#define QED_IS_K2(dev)  QED_IS_AH(dev)

	u16 vendor_id;
	u16 device_id;

	u16 chip_num;
#define CHIP_NUM_MASK                   0xffff
#define CHIP_NUM_SHIFT                  16

	u16 chip_rev;
#define CHIP_REV_MASK                   0xf
#define CHIP_REV_SHIFT                  12
#ifndef ASIC_ONLY
#define CHIP_REV_IS_TEDIBEAR(_cdev) ((_cdev)->chip_rev == 0x5)
#define CHIP_REV_IS_EMUL_A0(_cdev) ((_cdev)->chip_rev == 0xe)
#define CHIP_REV_IS_EMUL_B0(_cdev) ((_cdev)->chip_rev == 0xc)
#define CHIP_REV_IS_EMUL(_cdev) (CHIP_REV_IS_EMUL_A0(_cdev) || \
				 CHIP_REV_IS_EMUL_B0(_cdev))
#define CHIP_REV_IS_FPGA_A0(_cdev) ((_cdev)->chip_rev == 0xf)
#define CHIP_REV_IS_FPGA_B0(_cdev) ((_cdev)->chip_rev == 0xd)
#define CHIP_REV_IS_FPGA(_cdev) (CHIP_REV_IS_FPGA_A0(_cdev) || \
				 CHIP_REV_IS_FPGA_B0(_cdev))
#define CHIP_REV_IS_SLOW(_cdev)	\
	(CHIP_REV_IS_EMUL(_cdev) || CHIP_REV_IS_FPGA(_cdev))
#define CHIP_REV_IS_A0(_cdev)	       \
	(CHIP_REV_IS_EMUL_A0(_cdev) || \
	 CHIP_REV_IS_FPGA_A0(_cdev) || \
	 !(_cdev)->chip_rev)
#define CHIP_REV_IS_B0(_cdev)	       \
	(CHIP_REV_IS_EMUL_B0(_cdev) || \
	 CHIP_REV_IS_FPGA_B0(_cdev) || \
	 (_cdev)->chip_rev == 1)
#define CHIP_REV_IS_ASIC(_cdev) !CHIP_REV_IS_SLOW(_cdev)
#else
#define CHIP_REV_IS_A0(_cdev)   (!(_cdev)->chip_rev)
#define CHIP_REV_IS_B0(_cdev)   ((_cdev)->chip_rev == 1)
#endif

	u16 chip_metal;
#define CHIP_METAL_MASK                 0xff
#define CHIP_METAL_SHIFT                4

	u16 chip_bond_id;
#define CHIP_BOND_ID_MASK               0xf
#define CHIP_BOND_ID_SHIFT              0

	u8 num_engines;
	u8 num_ports_in_engines;
	u8 num_funcs_in_port;

	u8 path_id;
	enum qed_mf_mode mf_mode;
#define IS_MF_DEFAULT(_p_hwfn)  (((_p_hwfn)->cdev)->mf_mode == QED_MF_DEFAULT)
#define IS_MF_SI(_p_hwfn)       (((_p_hwfn)->cdev)->mf_mode == QED_MF_NPAR)
#define IS_MF_SD(_p_hwfn)       (((_p_hwfn)->cdev)->mf_mode == QED_MF_OVLAN)

	int pcie_width;
	int pcie_speed;
	u8 ver_str[VER_SIZE];
	/* Add MF related configuration */
	u8 mcp_rev;
	u8 boot_mode;

	u8 wol;

	u32 int_mode;
	enum qed_coalescing_mode int_coalescing_mode;
	u16 rx_coalesce_usecs;
	u16 tx_coalesce_usecs;

	/* Start Bar offset of first hwfn */
	void __iomem *regview;
	void __iomem *doorbells;
	u64 db_phys_addr;
	unsigned long db_size;

	/* PCI */
	u8 cache_shift;

	/* Init */
	const struct iro *iro_arr;
#define IRO (p_hwfn->cdev->iro_arr)

	/* HW functions */
	u8 num_hwfns;
	struct qed_hwfn hwfns[MAX_HWFNS_PER_DEVICE];

	/* SRIOV */
	struct qed_hw_sriov_info *p_iov_info;
#define IS_QED_SRIOV(cdev)              (!!(cdev)->p_iov_info)
	bool b_hw_channel;

	unsigned long tunn_mode;

	bool b_is_vf;

	u32 drv_type;

	u32 rdma_max_sge;
	u32 rdma_max_inline;
	u32 rdma_max_srq_sge;

	struct qed_eth_stats *reset_stats;
	struct qed_fw_data *fw_data;

	u32 mcp_nvm_resp;

	/* Recovery */
	bool recov_in_prog;

	/* Indicates whether should prevent attentions from being reasserted */
	bool attn_clr_en;

	/* Indicates whether allowing the MFW to collect a crash dump */
	bool mdump_en;

	/* Indicates if the reg_fifo is checked after any register access */
	bool chk_reg_fifo;

#ifndef ASIC_ONLY
	bool b_is_emul_full;
#endif

	/* Linux specific here */
	struct pci_dev *pdev;
	u32 flags;
#define QED_FLAG_STORAGE_STARTED (1 << 0)	/* TODO - very likely this isn't the
						 * correct place, but didn't want to
						 * start protocol-specific structs.
						 */

	int msg_enable;

	struct pci_params pci_params;

	struct qed_int_params int_params;

	u8 protocol;
#define IS_QED_ETH_IF(cdev)     ((cdev)->protocol == QED_PROTOCOL_ETH)
#define IS_QED_FCOE_IF(cdev)    ((cdev)->protocol == QED_PROTOCOL_FCOE)
#define IS_QED_ISCSI_IF(cdev)   ((cdev)->protocol == QED_PROTOCOL_ISCSI)

	/* Callbacks to protocol driver */
	union {
		struct qed_common_cb_ops *common;
		struct qed_eth_cb_ops *eth;
		struct qed_fcoe_cb_ops *fcoe;
		struct qed_iscsi_cb_ops *iscsi;
	} protocol_ops;
	void *ops_cookie;

#ifdef CONFIG_QED_LL2
	struct qed_cb_ll2_info *ll2;
	u8 ll2_mac_address[ETH_ALEN];
#endif

#ifdef CONFIG_DEBUG_FS
	struct qed_dbg_feature dbg_features[DBG_FEATURE_NUM];
	struct dentry *bdf_dentry;
	bool test_result_available;
	char test_result[sizeof(int)];
	struct debug_data_info_pool data_info_pool;
	struct chain_print_struct chain_info;
	u8 engine_for_debug;
	bool recording_active;
#endif

	 DECLARE_HASHTABLE(connections, 10);
#ifdef CONFIG_QED_BINARY_FW
	const struct firmware *firmware;
#endif

	u8 *p_dbg_data_buf;
	u32 dbg_data_buf_size;
	bool print_dbg_data;
};

#define NUM_OF_VFS(dev)         (QED_IS_BB(dev) ? MAX_NUM_VFS_BB \
				 : MAX_NUM_VFS_K2)
#define NUM_OF_L2_QUEUES(dev)   (QED_IS_BB(dev) ? MAX_NUM_L2_QUEUES_BB \
				 : MAX_NUM_L2_QUEUES_K2)
#define NUM_OF_PORTS(dev)       (QED_IS_BB(dev) ? MAX_NUM_PORTS_BB \
				 : MAX_NUM_PORTS_K2)
#define NUM_OF_SBS(dev)         (QED_IS_BB(dev) ? MAX_SB_PER_PATH_BB \
				 : MAX_SB_PER_PATH_K2)
#define NUM_OF_ENG_PFS(dev)     (QED_IS_BB(dev) ? MAX_NUM_PFS_BB \
				 : MAX_NUM_PFS_K2)

#ifndef REAL_ASIC_ONLY
#define ENABLE_EAGLE_ENG1_WORKAROUND(p_hwfn) (				  \
		(QED_IS_BB_A0(p_hwfn->cdev)) &&				  \
		(QED_PATH_ID(p_hwfn) == 1) &&				  \
		((p_hwfn->hw_info.port_mode == QED_PORT_MODE_DE_2X40G) || \
		 (p_hwfn->hw_info.port_mode == QED_PORT_MODE_DE_2X50G) || \
		 (p_hwfn->hw_info.port_mode == QED_PORT_MODE_DE_2X25G)))
#endif

/**
 * @brief qed_concrete_to_sw_fid - get the sw function id from
 *        the concrete value.
 *
 * @param concrete_fid
 *
 * @return inline u8
 */
static inline u8 qed_concrete_to_sw_fid(struct qed_dev *cdev, u32 concrete_fid)
{
	u8 vfid = GET_FIELD(concrete_fid, PXP_CONCRETE_FID_VFID);
	u8 pfid = GET_FIELD(concrete_fid, PXP_CONCRETE_FID_PFID);
	u8 vf_valid = GET_FIELD(concrete_fid,
				PXP_CONCRETE_FID_VFVALID);
	u8 sw_fid;

	if (vf_valid)
		sw_fid = vfid + MAX_NUM_PFS;
	else
		sw_fid = pfid;

	return sw_fid;
}

#define PURE_LB_TC 8
#define OOO_LB_TC 9

int qed_configure_vport_wfq(struct qed_dev *cdev, u16 vp_id, u32 rate);
void qed_configure_vp_wfq_on_link_change(struct qed_dev *cdev, u32 min_pf_rate);

int qed_configure_pf_max_bandwidth(struct qed_dev *cdev, u8 max_bw);
int qed_configure_pf_min_bandwidth(struct qed_dev *cdev, u8 min_bw);
void qed_clean_wfq_db(struct qed_hwfn *p_hwfn, struct qed_ptt *p_ptt);
int qed_device_num_engines(struct qed_dev *cdev);
int qed_device_num_ports(struct qed_dev *cdev);

#define QED_LEADING_HWFN(dev)   (&dev->hwfns[0])

/* Other Linux specific common definitions */
#define DP_NAME(cdev) ((cdev)->name)
#define DP_TRACK(cdev) (0)

#define REG_ADDR(cdev, offset)          (void __iomem *)((u8 __iomem *)	   \
							 (cdev->regview) + \
							 (offset))

#define REG_RD(cdev, offset)            readl(REG_ADDR(cdev, offset))
#define REG_RD8(cdev, offset)           readb(REG_ADDR(cdev, offset))
#define REG_RD16(cdev, offset)          readw(REG_ADDR(cdev, offset))

#define REG_WR(cdev, offset, val)       writel((u32)val, REG_ADDR(cdev, offset))
#define REG_WR8(cdev, offset, val)      writeb((u8)val, REG_ADDR(cdev, offset))
#define REG_WR16(cdev, offset, val)     writew((u16)val, REG_ADDR(cdev, offset))

#define DOORBELL(cdev, db_addr, val)			 \
	writel((u32)val, (void __iomem *)((u8 __iomem *) \
					  (cdev->doorbells) + (db_addr)))

#define QED_DB_SHIFT    5	/* 32 bytes - check if correct for E4 */

/* Prototypes */
int qed_fill_dev_info(struct qed_dev *cdev, struct qed_dev_info *dev_info);
void qed_link_update(struct qed_hwfn *hwfn);
void qed_dcbx_aen(struct qed_hwfn *hwfn, u32 mib_type);
u32 qed_unzip_data(struct qed_hwfn *p_hwfn,
		   u32 input_len, u8 * input_buf, u32 max_size, u8 * unzip_buf);
void qed_schedule_recovery_handler(struct qed_hwfn *p_hwfn);
void qed_hw_error_occurred(struct qed_hwfn *p_hwfn,
			   enum qed_hw_err_type err_type);
void qed_get_protocol_stats(struct qed_dev *cdev,
			    enum qed_mcp_protocol_type type,
			    union qed_mcp_protocol_stats *stats);
int qed_slowpath_irq_req(struct qed_hwfn *hwfn);

#ifndef QED_UPSTREAM
#define QED_ETH_INTERFACE_VERSION       910
#define QED_ISCSI_INTERFACE_VERSION     910
#define QED_FCOE_INTERFACE_VERSION      910
#define QED_ROCE_INTERFACE_VERSION      910
#endif

#endif /* _QED_H_ */
#endif
