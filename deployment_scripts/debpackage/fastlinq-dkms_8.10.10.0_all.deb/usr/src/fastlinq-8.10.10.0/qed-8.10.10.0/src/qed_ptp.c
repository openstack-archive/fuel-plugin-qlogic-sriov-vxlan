#include <linux/types.h>
#define __PREVENT_DUMP_MEM_ARR__
#define __PREVENT_PXP_GLOBAL_WIN__
#include "qed.h"
#include "qed_dev_api.h"
#include "qed_hw.h"
#include "qed_ptp.h"
#include "qed_reg_addr.h"

int qed_ptp_hwtstamp_tx_on(struct qed_hwfn *p_hwfn)
{
	struct qed_ptt *p_ptt;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_PARAM_MASK, 0x6AA);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_RULE_MASK, 0x3EEE);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}

int qed_ptp_enable_pkt2host(struct qed_hwfn *p_hwfn)
{
	struct qed_ptt *p_ptt;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_TO_HOST, 0x1);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}

int qed_ptp_disable(struct qed_hwfn *p_hwfn)
{
	struct qed_ptt *p_ptt;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	/* Disable sending PTP packets to host */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_TO_HOST, 0x0);

	/* Reset PTP event detection rules */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_PARAM_MASK, 0x7FF);
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_RULE_MASK, 0x3FFF);

	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_PARAM_MASK, 0x7FF);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_RULE_MASK, 0x3FFF);

	/* Disable the PTP feature */
	qed_wr(p_hwfn, p_ptt, NIG_REG_RX_PTP_EN, 0x0);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_PTP_EN, 0x0);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}

/* Read Rx timestamp */
u64 qed_ptp_read_rx_ts(struct qed_hwfn * p_hwfn, int *valid)
{
	struct qed_ptt *p_ptt;
	u32 val;
	u64 timestamp = 0;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt) {
		*valid = 0;
		return timestamp;
	}

	val = qed_rd(p_hwfn, p_ptt, NIG_REG_LLH_PTP_HOST_BUF_SEQID);
	if (val & 0x10000) {
		*valid = 1;
	} else {
		*valid = 0;
		DP_INFO(p_hwfn, "Invalid timestamp\n");
		qed_ptt_release(p_hwfn, p_ptt);

		return timestamp;
	}

	val = qed_rd(p_hwfn, p_ptt, NIG_REG_LLH_PTP_HOST_BUF_TS_LSB);
	timestamp = qed_rd(p_hwfn, p_ptt, NIG_REG_LLH_PTP_HOST_BUF_TS_MSB);
	timestamp <<= 32;
	timestamp |= val;

	/* Reset timestamp register to allow new timestamp */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_HOST_BUF_SEQID, 0x10000);

	qed_ptt_release(p_hwfn, p_ptt);

	return timestamp;
}

/* Read Tx timestamp */
u64 qed_ptp_read_tx_ts(struct qed_hwfn * p_hwfn, int *valid)
{
	struct qed_ptt *p_ptt;
	u32 val;
	u64 timestamp = 0;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt) {
		*valid = 0;
		return timestamp;
	}

	val = qed_rd(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_BUF_SEQID);
	if (val & 0x10000) {
		*valid = 1;
	} else {
		*valid = 0;
		qed_ptt_release(p_hwfn, p_ptt);
		return timestamp;
	}

	val = qed_rd(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_BUF_TS_LSB);
	timestamp = qed_rd(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_BUF_TS_MSB);
	timestamp <<= 32;
	timestamp |= val;

	/* Reset timestamp register to allow new timestamp */
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_BUF_SEQID, 0x10000);

	qed_ptt_release(p_hwfn, p_ptt);

	return timestamp;
}

/* Read Phy Hardware Clock */
u64 qed_ptp_read_cc(struct qed_hwfn * p_hwfn, int *valid)
{
	struct qed_ptt *p_ptt;
	u64 phc_cycles = 0;
	u32 temp = 0;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt) {
		*valid = 0;
		return phc_cycles;
	}

	temp = qed_rd(p_hwfn, p_ptt, NIG_REG_TSGEN_SYNC_TIME_LSB);
	phc_cycles = qed_rd(p_hwfn, p_ptt, NIG_REG_TSGEN_SYNC_TIME_MSB);
	phc_cycles <<= 32;
	phc_cycles |= temp;

	*valid = 1;

	qed_ptt_release(p_hwfn, p_ptt);

	return phc_cycles;
}

/* Filter PTP protocol packets that need to be timestamped */
int qed_ptp_cfg_rx_filters(struct qed_hwfn *p_hwfn,
			   u32 rule_mask, u32 parm_mask)
{
	struct qed_ptt *p_ptt;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_PARAM_MASK, parm_mask);
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_RULE_MASK, rule_mask);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}

int qed_ptp_adjfreq(struct qed_hwfn *p_hwfn, u32 cfg)
{
	struct qed_ptt *p_ptt;
	u32 val;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_RST_DRIFT_CNTR, 0x1);

	val = qed_rd(p_hwfn, p_ptt, NIG_REG_TSGEN_RST_DRIFT_CNTR);
	if (val & 1) {
		qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_DRIFT_CNTR_CONF, cfg);
	} else {
		DP_INFO(p_hwfn, "Drift counter is not reset\n");
		qed_ptt_release(p_hwfn, p_ptt);
		return -EINVAL;
	}

	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_RST_DRIFT_CNTR, 0x0);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}

int qed_ptp_enable(struct qed_hwfn *p_hwfn)
{
	struct qed_ptt *p_ptt;

	p_ptt = qed_ptt_acquire(p_hwfn);
	if (!p_ptt)
		return -EBUSY;

	/* Reset PTP event detection rules - will be configured in the IOCTL */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_PARAM_MASK, 0x7FF);
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_RULE_MASK, 0x3FFF);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_PARAM_MASK, 0x7FF);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_RULE_MASK, 0x3FFF);

	/* Disable PTP packets to host - will be configured in the IOCTL */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_TO_HOST, 0x0);

	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_PTP_EN, 7);
	qed_wr(p_hwfn, p_ptt, NIG_REG_RX_PTP_EN, 7);

	qed_wr(p_hwfn, p_ptt, NIG_REG_TS_OUTPUT_ENABLE_PDA, 0x1);
	if (QED_IS_BB_B0(p_hwfn->cdev))
		qed_wr(p_hwfn, p_ptt, NIG_REG_TS_OUTPUT_ENABLE_HV, 0x1);

	/* Pause free running counter */
	if (QED_IS_BB_B0(p_hwfn->cdev))
		qed_wr(p_hwfn, p_ptt, NIG_REG_TIMESYNC_GEN_REG, 2);
	if (QED_IS_AH(p_hwfn->cdev))
		qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_FREECNT_UPDATE, 2);

	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_FREE_CNT_VALUE_LSB, 0);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_FREE_CNT_VALUE_MSB, 0);
	/* Resume free running counter */
	if (QED_IS_BB_B0(p_hwfn->cdev))
		qed_wr(p_hwfn, p_ptt, NIG_REG_TIMESYNC_GEN_REG, 4);
	if (QED_IS_AH(p_hwfn->cdev))
		qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_FREECNT_UPDATE, 4);

	/* Disable drift register */
	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_DRIFT_CNTR_CONF, 0x0);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TSGEN_RST_DRIFT_CNTR, 0x0);

	/* Reset possibly old timestamps */
	qed_wr(p_hwfn, p_ptt, NIG_REG_LLH_PTP_HOST_BUF_SEQID, 0x10000);
	qed_wr(p_hwfn, p_ptt, NIG_REG_TX_LLH_PTP_BUF_SEQID, 0x10000);

	qed_ptt_release(p_hwfn, p_ptt);

	return 0;
}
