#ifndef QEDE_ROCE_H
#define QEDE_ROCE_H

//#include "qede.h"
struct qedr_dev;
struct qed_dev;
struct qede_dev;


/*
struct qedr_dev_info {
	u8 __iomem *db;
	u64 unmapped_db;
	u32 db_page_size;
	u32 db_total_size;
	u64 dpp_unmapped_addr;
	u32 dpp_unmapped_len;
	struct pci_dev *pdev;
	struct net_device *netdev;
	u8 mac_addr[ETH_ALEN];
	u32 dev_family;

	struct {
		int num_vectors;
		int start_vector;
		u32 vector_list[MAX_MSIX_VECTORS];
	} msix;
};
*/

enum qede_roce_event {
	QEDE_UP,
	QEDE_CHANGE_ADDR,
	QEDE_DOWN,
	QEDE_CLOSE
};

struct qedr_driver {
	unsigned char name[32];

	struct qedr_dev *(*add)(struct qed_dev *cdev,
				struct pci_dev *pdev,
				struct net_device *ndev);

	void (*remove) (struct qedr_dev *);
	void (*notify) (struct qedr_dev *, enum qede_roce_event);
};

/* APIs for RoCE driver to register callback handlers,
 * which will be invoked when device is added, removed, ifup, ifdown
 */
int qede_roce_register_driver(struct qedr_driver *drv);
void qede_roce_unregister_driver(struct qedr_driver *drv);

bool qede_roce_supported(struct qede_dev *dev);
void qede_roce_dev_add(struct qede_dev *dev);
void qede_roce_dev_open(struct qede_dev *dev);
void qede_roce_dev_close(struct qede_dev *dev);
void qede_roce_dev_remove(struct qede_dev *dev);
void qede_roce_dev_shutdown(struct qede_dev *dev);
void qede_roce_changeaddr(struct qede_dev *edr);

#endif
