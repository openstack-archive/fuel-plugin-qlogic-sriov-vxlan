#ifndef __QEDE_HSI__
#define __QEDE_HSI__ 
/********************************/
/* Add include to common target */
/********************************/
#include "common_hsi.h"

/************************************************************************/
/* Add include to common eth target for both eCore and protocol driver */
/************************************************************************/
#include "eth_common.h"
#endif /* __QEDE_HSI__ */
