#include <linux/pci.h>
#include <linux/netdevice.h>
#include <linux/list.h>
#include <linux/mutex.h>

#include "qede.h"
#include "qede_roce.h"


static struct qedr_driver *qedr_drv;
/* devices with ROCE support */
static LIST_HEAD(qedr_dev_list);
static DEFINE_MUTEX(qedr_dev_list_lock);

bool qede_roce_supported(struct qede_dev *dev)
{
	return dev->dev_info.common.rdma_supported;
}

static void _qede_roce_dev_add(struct qede_dev *edev)
{
	if (!qedr_drv)
		return;

	edev->qedr_dev = qedr_drv->add(edev->cdev, edev->pdev, edev->ndev);
}

void qede_roce_dev_add(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		INIT_LIST_HEAD(&edev->entry);
		mutex_lock(&qedr_dev_list_lock);
		list_add_tail(&edev->entry, &qedr_dev_list);
		_qede_roce_dev_add(edev);
		mutex_unlock(&qedr_dev_list_lock);
	}
}

static void _qede_roce_dev_remove(struct qede_dev *edev)
{
	if (qedr_drv && qedr_drv->remove && edev->qedr_dev)
		qedr_drv->remove(edev->qedr_dev);
	edev->qedr_dev = NULL;
}

void qede_roce_dev_remove(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		mutex_lock(&qedr_dev_list_lock);
		_qede_roce_dev_remove(edev);
		list_del(&edev->entry);
		mutex_unlock(&qedr_dev_list_lock);
	}
}

static void _qede_roce_dev_open(struct qede_dev *edev)
{
	if (qedr_drv && edev->qedr_dev && qedr_drv->notify)
		qedr_drv->notify(edev->qedr_dev, QEDE_UP);
}

void qede_roce_dev_open(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		mutex_lock(&qedr_dev_list_lock);
		_qede_roce_dev_open(edev);
		mutex_unlock(&qedr_dev_list_lock);
	}
}

static void _qede_roce_dev_close(struct qede_dev *edev)
{
	if (qedr_drv && edev->qedr_dev && qedr_drv->notify)
		qedr_drv->notify(edev->qedr_dev, QEDE_DOWN);
}

void qede_roce_dev_close(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		mutex_lock(&qedr_dev_list_lock);
		_qede_roce_dev_close(edev);
		mutex_unlock(&qedr_dev_list_lock);
	}
}

void qede_roce_dev_shutdown(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		mutex_lock(&qedr_dev_list_lock);
		if (qedr_drv && edev->qedr_dev && qedr_drv->notify)
			qedr_drv->notify(edev->qedr_dev, QEDE_CLOSE);
		mutex_unlock(&qedr_dev_list_lock);
	}
}

int qede_roce_register_driver(struct qedr_driver *drv)
{
	struct qede_dev *edev;
	u8 qedr_counter = 0;

	mutex_lock(&qedr_dev_list_lock);
	if (qedr_drv) {
		mutex_unlock(&qedr_dev_list_lock);
		return -EINVAL;
	}
	qedr_drv = drv;
	list_for_each_entry(edev, &qedr_dev_list, entry) {
		struct net_device *netdev;

		qedr_counter++;
		_qede_roce_dev_add(edev);
		netdev = edev->ndev;
		if (netif_running(netdev) && netif_oper_up(netdev))
			_qede_roce_dev_open(edev);
	}
	mutex_unlock(&qedr_dev_list_lock);

	pr_err("qedr: discovered and registered %d RoCE funcs\n", qedr_counter);

	return 0;
}
EXPORT_SYMBOL(qede_roce_register_driver);

void qede_roce_unregister_driver(struct qedr_driver *drv)
{
	struct qede_dev *edev;

	mutex_lock(&qedr_dev_list_lock);
	list_for_each_entry(edev, &qedr_dev_list, entry) {
		if (edev->qedr_dev)
			_qede_roce_dev_remove(edev);
	}
	qedr_drv = NULL;
	mutex_unlock(&qedr_dev_list_lock);
}
EXPORT_SYMBOL(qede_roce_unregister_driver);

void qede_roce_changeaddr(struct qede_dev *edev)
{
	if (qede_roce_supported(edev)) {
		if (qedr_drv && edev->qedr_dev && qedr_drv->notify)
			qedr_drv->notify(edev->qedr_dev, QEDE_CHANGE_ADDR);
	}
}
