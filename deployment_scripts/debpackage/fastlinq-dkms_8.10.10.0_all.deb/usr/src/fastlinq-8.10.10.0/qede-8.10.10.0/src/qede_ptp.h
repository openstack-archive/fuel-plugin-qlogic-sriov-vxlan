#ifndef _QEDE_PTP_H_
#define _QEDE_PTP_H_

#if (defined(QEDE_PTP_SUPPORT) && \
	(defined(CONFIG_PTP_1588_CLOCK) || \
	defined(CONFIG_PTP_1588_CLOCK_MODULE)))	/* QEDE_UPSTREAM */

#include <linux/ptp_clock_kernel.h>
#include <linux/net_tstamp.h>
#ifndef _DEFINE_CYCLECOUNTER_MASK	/* QEDE_UPSTREAM */
#include <linux/timecounter.h>
#else
#include <linux/clocksource.h>
#endif
#include "qede.h"

void qede_ptp_rx_ts(struct qede_dev *, struct sk_buff *);
void qede_ptp_tx_ts(struct qede_dev *, struct sk_buff *);
int qede_ptp_hw_ts(struct qede_dev *, struct ifreq *);
void qede_ptp_start(struct qede_dev *);
void qede_ptp_stop(struct qede_dev *);
void qede_ptp_remove(struct qede_dev *);
int qede_ptp_register_phc(struct qede_dev *);
int qede_ptp_get_ts_info(struct net_device *, struct ethtool_ts_info *);
bool qede_ptp_vport_enable_ptp_pkt(struct qede_dev *);

static inline void qede_ptp_record_rx_ts(struct qede_dev *edev,
					 union eth_rx_cqe *cqe,
					 struct sk_buff *skb)
{
	/* Check if this packet was timestamped */
	if (unlikely(le16_to_cpu(cqe->fast_path_regular.pars_flags.flags) &
		     (1 << PARSING_AND_ERR_FLAGS_TIMESTAMPRECORDED_SHIFT))) {
		if (cqe->fast_path_regular.pars_flags.flags &
		    (1 << PARSING_AND_ERR_FLAGS_TIMESYNCPKT_SHIFT)) {
			qede_ptp_rx_ts(edev, skb);
		} else {
			DP_INFO(edev,
				"Timestamp recorded for non PTP packets \n");
		}
	}
}

#else

static inline void qede_ptp_rx_ts(struct qede_dev *dev, struct sk_buff *skb)
{
	return;
}

static inline void qede_ptp_tx_ts(struct qede_dev *dev, struct sk_buff *skb)
{
	return;
}

static inline int qede_ptp_hw_ts(struct qede_dev *dev, struct ifreq *req)
{
	return 0;
}

static inline void qede_ptp_start(struct qede_dev *dev)
{
	return;
}

static inline void qede_ptp_stop(struct qede_dev *dev)
{
	return;
}

static inline void qede_ptp_remove(struct qede_dev *dev)
{
	return;
}

static inline int qede_ptp_register_phc(struct qede_dev *dev)
{
	return 0;
}

struct ethtool_ts_info;
static inline int qede_ptp_get_ts_info(struct net_device *dev,
				       struct ethtool_ts_info *info)
{
	return 0;
}

static inline void qede_ptp_record_rx_ts(struct qede_dev *edev,
					 union eth_rx_cqe *cqe,
					 struct sk_buff *skb)
{
}

static inline bool qede_ptp_vport_enable_ptp_pkt(struct qede_dev *edev)
{
	return false;
}

struct qede_ptp {
	int dummy;
};

#endif /* QEDE_PTP_SUPPORT */

#endif /* _QEDE_PTP_H_ */
